
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model Zap
 * 
 */
export type Zap = $Result.DefaultSelection<Prisma.$ZapPayload>
/**
 * Model Trigger
 * 
 */
export type Trigger = $Result.DefaultSelection<Prisma.$TriggerPayload>
/**
 * Model Actions
 * 
 */
export type Actions = $Result.DefaultSelection<Prisma.$ActionsPayload>
/**
 * Model AvalibleActions
 * 
 */
export type AvalibleActions = $Result.DefaultSelection<Prisma.$AvalibleActionsPayload>
/**
 * Model TriggerType
 * 
 */
export type TriggerType = $Result.DefaultSelection<Prisma.$TriggerTypePayload>
/**
 * Model ZapRun
 * 
 */
export type ZapRun = $Result.DefaultSelection<Prisma.$ZapRunPayload>
/**
 * Model ZapRunOutBox
 * 
 */
export type ZapRunOutBox = $Result.DefaultSelection<Prisma.$ZapRunOutBoxPayload>

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Users
 * const users = await prisma.user.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Users
   * const users = await prisma.user.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.zap`: Exposes CRUD operations for the **Zap** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Zaps
    * const zaps = await prisma.zap.findMany()
    * ```
    */
  get zap(): Prisma.ZapDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.trigger`: Exposes CRUD operations for the **Trigger** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Triggers
    * const triggers = await prisma.trigger.findMany()
    * ```
    */
  get trigger(): Prisma.TriggerDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.actions`: Exposes CRUD operations for the **Actions** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Actions
    * const actions = await prisma.actions.findMany()
    * ```
    */
  get actions(): Prisma.ActionsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.avalibleActions`: Exposes CRUD operations for the **AvalibleActions** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more AvalibleActions
    * const avalibleActions = await prisma.avalibleActions.findMany()
    * ```
    */
  get avalibleActions(): Prisma.AvalibleActionsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.triggerType`: Exposes CRUD operations for the **TriggerType** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more TriggerTypes
    * const triggerTypes = await prisma.triggerType.findMany()
    * ```
    */
  get triggerType(): Prisma.TriggerTypeDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.zapRun`: Exposes CRUD operations for the **ZapRun** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ZapRuns
    * const zapRuns = await prisma.zapRun.findMany()
    * ```
    */
  get zapRun(): Prisma.ZapRunDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.zapRunOutBox`: Exposes CRUD operations for the **ZapRunOutBox** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ZapRunOutBoxes
    * const zapRunOutBoxes = await prisma.zapRunOutBox.findMany()
    * ```
    */
  get zapRunOutBox(): Prisma.ZapRunOutBoxDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.9.0
   * Query Engine version: 81e4af48011447c3cc503a190e86995b66d2a28e
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    User: 'User',
    Zap: 'Zap',
    Trigger: 'Trigger',
    Actions: 'Actions',
    AvalibleActions: 'AvalibleActions',
    TriggerType: 'TriggerType',
    ZapRun: 'ZapRun',
    ZapRunOutBox: 'ZapRunOutBox'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "user" | "zap" | "trigger" | "actions" | "avalibleActions" | "triggerType" | "zapRun" | "zapRunOutBox"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.UserCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.UserUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      Zap: {
        payload: Prisma.$ZapPayload<ExtArgs>
        fields: Prisma.ZapFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ZapFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ZapFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapPayload>
          }
          findFirst: {
            args: Prisma.ZapFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ZapFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapPayload>
          }
          findMany: {
            args: Prisma.ZapFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapPayload>[]
          }
          create: {
            args: Prisma.ZapCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapPayload>
          }
          createMany: {
            args: Prisma.ZapCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ZapCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapPayload>[]
          }
          delete: {
            args: Prisma.ZapDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapPayload>
          }
          update: {
            args: Prisma.ZapUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapPayload>
          }
          deleteMany: {
            args: Prisma.ZapDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ZapUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ZapUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapPayload>[]
          }
          upsert: {
            args: Prisma.ZapUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapPayload>
          }
          aggregate: {
            args: Prisma.ZapAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateZap>
          }
          groupBy: {
            args: Prisma.ZapGroupByArgs<ExtArgs>
            result: $Utils.Optional<ZapGroupByOutputType>[]
          }
          count: {
            args: Prisma.ZapCountArgs<ExtArgs>
            result: $Utils.Optional<ZapCountAggregateOutputType> | number
          }
        }
      }
      Trigger: {
        payload: Prisma.$TriggerPayload<ExtArgs>
        fields: Prisma.TriggerFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TriggerFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TriggerFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerPayload>
          }
          findFirst: {
            args: Prisma.TriggerFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TriggerFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerPayload>
          }
          findMany: {
            args: Prisma.TriggerFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerPayload>[]
          }
          create: {
            args: Prisma.TriggerCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerPayload>
          }
          createMany: {
            args: Prisma.TriggerCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.TriggerCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerPayload>[]
          }
          delete: {
            args: Prisma.TriggerDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerPayload>
          }
          update: {
            args: Prisma.TriggerUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerPayload>
          }
          deleteMany: {
            args: Prisma.TriggerDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.TriggerUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.TriggerUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerPayload>[]
          }
          upsert: {
            args: Prisma.TriggerUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerPayload>
          }
          aggregate: {
            args: Prisma.TriggerAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTrigger>
          }
          groupBy: {
            args: Prisma.TriggerGroupByArgs<ExtArgs>
            result: $Utils.Optional<TriggerGroupByOutputType>[]
          }
          count: {
            args: Prisma.TriggerCountArgs<ExtArgs>
            result: $Utils.Optional<TriggerCountAggregateOutputType> | number
          }
        }
      }
      Actions: {
        payload: Prisma.$ActionsPayload<ExtArgs>
        fields: Prisma.ActionsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ActionsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActionsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ActionsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActionsPayload>
          }
          findFirst: {
            args: Prisma.ActionsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActionsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ActionsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActionsPayload>
          }
          findMany: {
            args: Prisma.ActionsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActionsPayload>[]
          }
          create: {
            args: Prisma.ActionsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActionsPayload>
          }
          createMany: {
            args: Prisma.ActionsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ActionsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActionsPayload>[]
          }
          delete: {
            args: Prisma.ActionsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActionsPayload>
          }
          update: {
            args: Prisma.ActionsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActionsPayload>
          }
          deleteMany: {
            args: Prisma.ActionsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ActionsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ActionsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActionsPayload>[]
          }
          upsert: {
            args: Prisma.ActionsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ActionsPayload>
          }
          aggregate: {
            args: Prisma.ActionsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateActions>
          }
          groupBy: {
            args: Prisma.ActionsGroupByArgs<ExtArgs>
            result: $Utils.Optional<ActionsGroupByOutputType>[]
          }
          count: {
            args: Prisma.ActionsCountArgs<ExtArgs>
            result: $Utils.Optional<ActionsCountAggregateOutputType> | number
          }
        }
      }
      AvalibleActions: {
        payload: Prisma.$AvalibleActionsPayload<ExtArgs>
        fields: Prisma.AvalibleActionsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AvalibleActionsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AvalibleActionsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AvalibleActionsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AvalibleActionsPayload>
          }
          findFirst: {
            args: Prisma.AvalibleActionsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AvalibleActionsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AvalibleActionsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AvalibleActionsPayload>
          }
          findMany: {
            args: Prisma.AvalibleActionsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AvalibleActionsPayload>[]
          }
          create: {
            args: Prisma.AvalibleActionsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AvalibleActionsPayload>
          }
          createMany: {
            args: Prisma.AvalibleActionsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.AvalibleActionsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AvalibleActionsPayload>[]
          }
          delete: {
            args: Prisma.AvalibleActionsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AvalibleActionsPayload>
          }
          update: {
            args: Prisma.AvalibleActionsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AvalibleActionsPayload>
          }
          deleteMany: {
            args: Prisma.AvalibleActionsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AvalibleActionsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.AvalibleActionsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AvalibleActionsPayload>[]
          }
          upsert: {
            args: Prisma.AvalibleActionsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AvalibleActionsPayload>
          }
          aggregate: {
            args: Prisma.AvalibleActionsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAvalibleActions>
          }
          groupBy: {
            args: Prisma.AvalibleActionsGroupByArgs<ExtArgs>
            result: $Utils.Optional<AvalibleActionsGroupByOutputType>[]
          }
          count: {
            args: Prisma.AvalibleActionsCountArgs<ExtArgs>
            result: $Utils.Optional<AvalibleActionsCountAggregateOutputType> | number
          }
        }
      }
      TriggerType: {
        payload: Prisma.$TriggerTypePayload<ExtArgs>
        fields: Prisma.TriggerTypeFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TriggerTypeFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerTypePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TriggerTypeFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerTypePayload>
          }
          findFirst: {
            args: Prisma.TriggerTypeFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerTypePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TriggerTypeFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerTypePayload>
          }
          findMany: {
            args: Prisma.TriggerTypeFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerTypePayload>[]
          }
          create: {
            args: Prisma.TriggerTypeCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerTypePayload>
          }
          createMany: {
            args: Prisma.TriggerTypeCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.TriggerTypeCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerTypePayload>[]
          }
          delete: {
            args: Prisma.TriggerTypeDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerTypePayload>
          }
          update: {
            args: Prisma.TriggerTypeUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerTypePayload>
          }
          deleteMany: {
            args: Prisma.TriggerTypeDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.TriggerTypeUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.TriggerTypeUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerTypePayload>[]
          }
          upsert: {
            args: Prisma.TriggerTypeUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TriggerTypePayload>
          }
          aggregate: {
            args: Prisma.TriggerTypeAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTriggerType>
          }
          groupBy: {
            args: Prisma.TriggerTypeGroupByArgs<ExtArgs>
            result: $Utils.Optional<TriggerTypeGroupByOutputType>[]
          }
          count: {
            args: Prisma.TriggerTypeCountArgs<ExtArgs>
            result: $Utils.Optional<TriggerTypeCountAggregateOutputType> | number
          }
        }
      }
      ZapRun: {
        payload: Prisma.$ZapRunPayload<ExtArgs>
        fields: Prisma.ZapRunFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ZapRunFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ZapRunFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunPayload>
          }
          findFirst: {
            args: Prisma.ZapRunFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ZapRunFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunPayload>
          }
          findMany: {
            args: Prisma.ZapRunFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunPayload>[]
          }
          create: {
            args: Prisma.ZapRunCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunPayload>
          }
          createMany: {
            args: Prisma.ZapRunCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ZapRunCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunPayload>[]
          }
          delete: {
            args: Prisma.ZapRunDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunPayload>
          }
          update: {
            args: Prisma.ZapRunUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunPayload>
          }
          deleteMany: {
            args: Prisma.ZapRunDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ZapRunUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ZapRunUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunPayload>[]
          }
          upsert: {
            args: Prisma.ZapRunUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunPayload>
          }
          aggregate: {
            args: Prisma.ZapRunAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateZapRun>
          }
          groupBy: {
            args: Prisma.ZapRunGroupByArgs<ExtArgs>
            result: $Utils.Optional<ZapRunGroupByOutputType>[]
          }
          count: {
            args: Prisma.ZapRunCountArgs<ExtArgs>
            result: $Utils.Optional<ZapRunCountAggregateOutputType> | number
          }
        }
      }
      ZapRunOutBox: {
        payload: Prisma.$ZapRunOutBoxPayload<ExtArgs>
        fields: Prisma.ZapRunOutBoxFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ZapRunOutBoxFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunOutBoxPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ZapRunOutBoxFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunOutBoxPayload>
          }
          findFirst: {
            args: Prisma.ZapRunOutBoxFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunOutBoxPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ZapRunOutBoxFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunOutBoxPayload>
          }
          findMany: {
            args: Prisma.ZapRunOutBoxFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunOutBoxPayload>[]
          }
          create: {
            args: Prisma.ZapRunOutBoxCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunOutBoxPayload>
          }
          createMany: {
            args: Prisma.ZapRunOutBoxCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ZapRunOutBoxCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunOutBoxPayload>[]
          }
          delete: {
            args: Prisma.ZapRunOutBoxDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunOutBoxPayload>
          }
          update: {
            args: Prisma.ZapRunOutBoxUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunOutBoxPayload>
          }
          deleteMany: {
            args: Prisma.ZapRunOutBoxDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ZapRunOutBoxUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ZapRunOutBoxUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunOutBoxPayload>[]
          }
          upsert: {
            args: Prisma.ZapRunOutBoxUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ZapRunOutBoxPayload>
          }
          aggregate: {
            args: Prisma.ZapRunOutBoxAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateZapRunOutBox>
          }
          groupBy: {
            args: Prisma.ZapRunOutBoxGroupByArgs<ExtArgs>
            result: $Utils.Optional<ZapRunOutBoxGroupByOutputType>[]
          }
          count: {
            args: Prisma.ZapRunOutBoxCountArgs<ExtArgs>
            result: $Utils.Optional<ZapRunOutBoxCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    user?: UserOmit
    zap?: ZapOmit
    trigger?: TriggerOmit
    actions?: ActionsOmit
    avalibleActions?: AvalibleActionsOmit
    triggerType?: TriggerTypeOmit
    zapRun?: ZapRunOmit
    zapRunOutBox?: ZapRunOutBoxOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type ZapCountOutputType
   */

  export type ZapCountOutputType = {
    actions: number
    zaprun: number
  }

  export type ZapCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    actions?: boolean | ZapCountOutputTypeCountActionsArgs
    zaprun?: boolean | ZapCountOutputTypeCountZaprunArgs
  }

  // Custom InputTypes
  /**
   * ZapCountOutputType without action
   */
  export type ZapCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapCountOutputType
     */
    select?: ZapCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * ZapCountOutputType without action
   */
  export type ZapCountOutputTypeCountActionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ActionsWhereInput
  }

  /**
   * ZapCountOutputType without action
   */
  export type ZapCountOutputTypeCountZaprunArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ZapRunWhereInput
  }


  /**
   * Count Type AvalibleActionsCountOutputType
   */

  export type AvalibleActionsCountOutputType = {
    action: number
  }

  export type AvalibleActionsCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    action?: boolean | AvalibleActionsCountOutputTypeCountActionArgs
  }

  // Custom InputTypes
  /**
   * AvalibleActionsCountOutputType without action
   */
  export type AvalibleActionsCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AvalibleActionsCountOutputType
     */
    select?: AvalibleActionsCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * AvalibleActionsCountOutputType without action
   */
  export type AvalibleActionsCountOutputTypeCountActionArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ActionsWhereInput
  }


  /**
   * Count Type TriggerTypeCountOutputType
   */

  export type TriggerTypeCountOutputType = {
    triggr: number
  }

  export type TriggerTypeCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    triggr?: boolean | TriggerTypeCountOutputTypeCountTriggrArgs
  }

  // Custom InputTypes
  /**
   * TriggerTypeCountOutputType without action
   */
  export type TriggerTypeCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TriggerTypeCountOutputType
     */
    select?: TriggerTypeCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * TriggerTypeCountOutputType without action
   */
  export type TriggerTypeCountOutputTypeCountTriggrArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TriggerWhereInput
  }


  /**
   * Models
   */

  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _avg: UserAvgAggregateOutputType | null
    _sum: UserSumAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserAvgAggregateOutputType = {
    id: number | null
  }

  export type UserSumAggregateOutputType = {
    id: number | null
  }

  export type UserMinAggregateOutputType = {
    id: number | null
    email: string | null
    name: string | null
    password: string | null
  }

  export type UserMaxAggregateOutputType = {
    id: number | null
    email: string | null
    name: string | null
    password: string | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    email: number
    name: number
    password: number
    _all: number
  }


  export type UserAvgAggregateInputType = {
    id?: true
  }

  export type UserSumAggregateInputType = {
    id?: true
  }

  export type UserMinAggregateInputType = {
    id?: true
    email?: true
    name?: true
    password?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    email?: true
    name?: true
    password?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    email?: true
    name?: true
    password?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UserAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UserSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _avg?: UserAvgAggregateInputType
    _sum?: UserSumAggregateInputType
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: number
    email: string
    name: string
    password: string
    _count: UserCountAggregateOutputType | null
    _avg: UserAvgAggregateOutputType | null
    _sum: UserSumAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    name?: boolean
    password?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    name?: boolean
    password?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    name?: boolean
    password?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectScalar = {
    id?: boolean
    email?: boolean
    name?: boolean
    password?: boolean
  }

  export type UserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "email" | "name" | "password", ExtArgs["result"]["user"]>

  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      email: string
      name: string
      password: string
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserFindUniqueArgs>(args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserFindFirstArgs>(args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserFindManyArgs>(args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends UserCreateArgs>(args: SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {UserCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserCreateManyArgs>(args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Users and returns the data saved in the database.
     * @param {UserCreateManyAndReturnArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Users and only return the `id`
     * const userWithIdOnly = await prisma.user.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends UserCreateManyAndReturnArgs>(args?: SelectSubset<T, UserCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends UserDeleteArgs>(args: SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserUpdateArgs>(args: SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserDeleteManyArgs>(args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserUpdateManyArgs>(args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users and returns the data updated in the database.
     * @param {UserUpdateManyAndReturnArgs} args - Arguments to update many Users.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Users and only return the `id`
     * const userWithIdOnly = await prisma.user.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends UserUpdateManyAndReturnArgs>(args: SelectSubset<T, UserUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends UserUpsertArgs>(args: SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the User model
   */
  interface UserFieldRefs {
    readonly id: FieldRef<"User", 'Int'>
    readonly email: FieldRef<"User", 'String'>
    readonly name: FieldRef<"User", 'String'>
    readonly password: FieldRef<"User", 'String'>
  }
    

  // Custom InputTypes
  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }

  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User createManyAndReturn
   */
  export type UserCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User updateManyAndReturn
   */
  export type UserUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }

  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to delete.
     */
    limit?: number
  }

  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
  }


  /**
   * Model Zap
   */

  export type AggregateZap = {
    _count: ZapCountAggregateOutputType | null
    _min: ZapMinAggregateOutputType | null
    _max: ZapMaxAggregateOutputType | null
  }

  export type ZapMinAggregateOutputType = {
    id: string | null
  }

  export type ZapMaxAggregateOutputType = {
    id: string | null
  }

  export type ZapCountAggregateOutputType = {
    id: number
    _all: number
  }


  export type ZapMinAggregateInputType = {
    id?: true
  }

  export type ZapMaxAggregateInputType = {
    id?: true
  }

  export type ZapCountAggregateInputType = {
    id?: true
    _all?: true
  }

  export type ZapAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Zap to aggregate.
     */
    where?: ZapWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Zaps to fetch.
     */
    orderBy?: ZapOrderByWithRelationInput | ZapOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ZapWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Zaps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Zaps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Zaps
    **/
    _count?: true | ZapCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ZapMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ZapMaxAggregateInputType
  }

  export type GetZapAggregateType<T extends ZapAggregateArgs> = {
        [P in keyof T & keyof AggregateZap]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateZap[P]>
      : GetScalarType<T[P], AggregateZap[P]>
  }




  export type ZapGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ZapWhereInput
    orderBy?: ZapOrderByWithAggregationInput | ZapOrderByWithAggregationInput[]
    by: ZapScalarFieldEnum[] | ZapScalarFieldEnum
    having?: ZapScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ZapCountAggregateInputType | true
    _min?: ZapMinAggregateInputType
    _max?: ZapMaxAggregateInputType
  }

  export type ZapGroupByOutputType = {
    id: string
    _count: ZapCountAggregateOutputType | null
    _min: ZapMinAggregateOutputType | null
    _max: ZapMaxAggregateOutputType | null
  }

  type GetZapGroupByPayload<T extends ZapGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ZapGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ZapGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ZapGroupByOutputType[P]>
            : GetScalarType<T[P], ZapGroupByOutputType[P]>
        }
      >
    >


  export type ZapSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    trigger?: boolean | Zap$triggerArgs<ExtArgs>
    actions?: boolean | Zap$actionsArgs<ExtArgs>
    zaprun?: boolean | Zap$zaprunArgs<ExtArgs>
    _count?: boolean | ZapCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["zap"]>

  export type ZapSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
  }, ExtArgs["result"]["zap"]>

  export type ZapSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
  }, ExtArgs["result"]["zap"]>

  export type ZapSelectScalar = {
    id?: boolean
  }

  export type ZapOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id", ExtArgs["result"]["zap"]>
  export type ZapInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    trigger?: boolean | Zap$triggerArgs<ExtArgs>
    actions?: boolean | Zap$actionsArgs<ExtArgs>
    zaprun?: boolean | Zap$zaprunArgs<ExtArgs>
    _count?: boolean | ZapCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type ZapIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type ZapIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $ZapPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Zap"
    objects: {
      trigger: Prisma.$TriggerPayload<ExtArgs> | null
      actions: Prisma.$ActionsPayload<ExtArgs>[]
      zaprun: Prisma.$ZapRunPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
    }, ExtArgs["result"]["zap"]>
    composites: {}
  }

  type ZapGetPayload<S extends boolean | null | undefined | ZapDefaultArgs> = $Result.GetResult<Prisma.$ZapPayload, S>

  type ZapCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ZapFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ZapCountAggregateInputType | true
    }

  export interface ZapDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Zap'], meta: { name: 'Zap' } }
    /**
     * Find zero or one Zap that matches the filter.
     * @param {ZapFindUniqueArgs} args - Arguments to find a Zap
     * @example
     * // Get one Zap
     * const zap = await prisma.zap.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ZapFindUniqueArgs>(args: SelectSubset<T, ZapFindUniqueArgs<ExtArgs>>): Prisma__ZapClient<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Zap that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ZapFindUniqueOrThrowArgs} args - Arguments to find a Zap
     * @example
     * // Get one Zap
     * const zap = await prisma.zap.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ZapFindUniqueOrThrowArgs>(args: SelectSubset<T, ZapFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ZapClient<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Zap that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapFindFirstArgs} args - Arguments to find a Zap
     * @example
     * // Get one Zap
     * const zap = await prisma.zap.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ZapFindFirstArgs>(args?: SelectSubset<T, ZapFindFirstArgs<ExtArgs>>): Prisma__ZapClient<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Zap that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapFindFirstOrThrowArgs} args - Arguments to find a Zap
     * @example
     * // Get one Zap
     * const zap = await prisma.zap.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ZapFindFirstOrThrowArgs>(args?: SelectSubset<T, ZapFindFirstOrThrowArgs<ExtArgs>>): Prisma__ZapClient<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Zaps that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Zaps
     * const zaps = await prisma.zap.findMany()
     * 
     * // Get first 10 Zaps
     * const zaps = await prisma.zap.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const zapWithIdOnly = await prisma.zap.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ZapFindManyArgs>(args?: SelectSubset<T, ZapFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Zap.
     * @param {ZapCreateArgs} args - Arguments to create a Zap.
     * @example
     * // Create one Zap
     * const Zap = await prisma.zap.create({
     *   data: {
     *     // ... data to create a Zap
     *   }
     * })
     * 
     */
    create<T extends ZapCreateArgs>(args: SelectSubset<T, ZapCreateArgs<ExtArgs>>): Prisma__ZapClient<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Zaps.
     * @param {ZapCreateManyArgs} args - Arguments to create many Zaps.
     * @example
     * // Create many Zaps
     * const zap = await prisma.zap.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ZapCreateManyArgs>(args?: SelectSubset<T, ZapCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Zaps and returns the data saved in the database.
     * @param {ZapCreateManyAndReturnArgs} args - Arguments to create many Zaps.
     * @example
     * // Create many Zaps
     * const zap = await prisma.zap.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Zaps and only return the `id`
     * const zapWithIdOnly = await prisma.zap.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ZapCreateManyAndReturnArgs>(args?: SelectSubset<T, ZapCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Zap.
     * @param {ZapDeleteArgs} args - Arguments to delete one Zap.
     * @example
     * // Delete one Zap
     * const Zap = await prisma.zap.delete({
     *   where: {
     *     // ... filter to delete one Zap
     *   }
     * })
     * 
     */
    delete<T extends ZapDeleteArgs>(args: SelectSubset<T, ZapDeleteArgs<ExtArgs>>): Prisma__ZapClient<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Zap.
     * @param {ZapUpdateArgs} args - Arguments to update one Zap.
     * @example
     * // Update one Zap
     * const zap = await prisma.zap.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ZapUpdateArgs>(args: SelectSubset<T, ZapUpdateArgs<ExtArgs>>): Prisma__ZapClient<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Zaps.
     * @param {ZapDeleteManyArgs} args - Arguments to filter Zaps to delete.
     * @example
     * // Delete a few Zaps
     * const { count } = await prisma.zap.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ZapDeleteManyArgs>(args?: SelectSubset<T, ZapDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Zaps.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Zaps
     * const zap = await prisma.zap.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ZapUpdateManyArgs>(args: SelectSubset<T, ZapUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Zaps and returns the data updated in the database.
     * @param {ZapUpdateManyAndReturnArgs} args - Arguments to update many Zaps.
     * @example
     * // Update many Zaps
     * const zap = await prisma.zap.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Zaps and only return the `id`
     * const zapWithIdOnly = await prisma.zap.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ZapUpdateManyAndReturnArgs>(args: SelectSubset<T, ZapUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Zap.
     * @param {ZapUpsertArgs} args - Arguments to update or create a Zap.
     * @example
     * // Update or create a Zap
     * const zap = await prisma.zap.upsert({
     *   create: {
     *     // ... data to create a Zap
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Zap we want to update
     *   }
     * })
     */
    upsert<T extends ZapUpsertArgs>(args: SelectSubset<T, ZapUpsertArgs<ExtArgs>>): Prisma__ZapClient<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Zaps.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapCountArgs} args - Arguments to filter Zaps to count.
     * @example
     * // Count the number of Zaps
     * const count = await prisma.zap.count({
     *   where: {
     *     // ... the filter for the Zaps we want to count
     *   }
     * })
    **/
    count<T extends ZapCountArgs>(
      args?: Subset<T, ZapCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ZapCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Zap.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ZapAggregateArgs>(args: Subset<T, ZapAggregateArgs>): Prisma.PrismaPromise<GetZapAggregateType<T>>

    /**
     * Group by Zap.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ZapGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ZapGroupByArgs['orderBy'] }
        : { orderBy?: ZapGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ZapGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetZapGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Zap model
   */
  readonly fields: ZapFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Zap.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ZapClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    trigger<T extends Zap$triggerArgs<ExtArgs> = {}>(args?: Subset<T, Zap$triggerArgs<ExtArgs>>): Prisma__TriggerClient<$Result.GetResult<Prisma.$TriggerPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    actions<T extends Zap$actionsArgs<ExtArgs> = {}>(args?: Subset<T, Zap$actionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ActionsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    zaprun<T extends Zap$zaprunArgs<ExtArgs> = {}>(args?: Subset<T, Zap$zaprunArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ZapRunPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Zap model
   */
  interface ZapFieldRefs {
    readonly id: FieldRef<"Zap", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Zap findUnique
   */
  export type ZapFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Zap
     */
    select?: ZapSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Zap
     */
    omit?: ZapOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapInclude<ExtArgs> | null
    /**
     * Filter, which Zap to fetch.
     */
    where: ZapWhereUniqueInput
  }

  /**
   * Zap findUniqueOrThrow
   */
  export type ZapFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Zap
     */
    select?: ZapSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Zap
     */
    omit?: ZapOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapInclude<ExtArgs> | null
    /**
     * Filter, which Zap to fetch.
     */
    where: ZapWhereUniqueInput
  }

  /**
   * Zap findFirst
   */
  export type ZapFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Zap
     */
    select?: ZapSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Zap
     */
    omit?: ZapOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapInclude<ExtArgs> | null
    /**
     * Filter, which Zap to fetch.
     */
    where?: ZapWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Zaps to fetch.
     */
    orderBy?: ZapOrderByWithRelationInput | ZapOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Zaps.
     */
    cursor?: ZapWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Zaps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Zaps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Zaps.
     */
    distinct?: ZapScalarFieldEnum | ZapScalarFieldEnum[]
  }

  /**
   * Zap findFirstOrThrow
   */
  export type ZapFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Zap
     */
    select?: ZapSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Zap
     */
    omit?: ZapOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapInclude<ExtArgs> | null
    /**
     * Filter, which Zap to fetch.
     */
    where?: ZapWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Zaps to fetch.
     */
    orderBy?: ZapOrderByWithRelationInput | ZapOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Zaps.
     */
    cursor?: ZapWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Zaps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Zaps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Zaps.
     */
    distinct?: ZapScalarFieldEnum | ZapScalarFieldEnum[]
  }

  /**
   * Zap findMany
   */
  export type ZapFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Zap
     */
    select?: ZapSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Zap
     */
    omit?: ZapOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapInclude<ExtArgs> | null
    /**
     * Filter, which Zaps to fetch.
     */
    where?: ZapWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Zaps to fetch.
     */
    orderBy?: ZapOrderByWithRelationInput | ZapOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Zaps.
     */
    cursor?: ZapWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Zaps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Zaps.
     */
    skip?: number
    distinct?: ZapScalarFieldEnum | ZapScalarFieldEnum[]
  }

  /**
   * Zap create
   */
  export type ZapCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Zap
     */
    select?: ZapSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Zap
     */
    omit?: ZapOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapInclude<ExtArgs> | null
    /**
     * The data needed to create a Zap.
     */
    data?: XOR<ZapCreateInput, ZapUncheckedCreateInput>
  }

  /**
   * Zap createMany
   */
  export type ZapCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Zaps.
     */
    data: ZapCreateManyInput | ZapCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Zap createManyAndReturn
   */
  export type ZapCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Zap
     */
    select?: ZapSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Zap
     */
    omit?: ZapOmit<ExtArgs> | null
    /**
     * The data used to create many Zaps.
     */
    data: ZapCreateManyInput | ZapCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Zap update
   */
  export type ZapUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Zap
     */
    select?: ZapSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Zap
     */
    omit?: ZapOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapInclude<ExtArgs> | null
    /**
     * The data needed to update a Zap.
     */
    data: XOR<ZapUpdateInput, ZapUncheckedUpdateInput>
    /**
     * Choose, which Zap to update.
     */
    where: ZapWhereUniqueInput
  }

  /**
   * Zap updateMany
   */
  export type ZapUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Zaps.
     */
    data: XOR<ZapUpdateManyMutationInput, ZapUncheckedUpdateManyInput>
    /**
     * Filter which Zaps to update
     */
    where?: ZapWhereInput
    /**
     * Limit how many Zaps to update.
     */
    limit?: number
  }

  /**
   * Zap updateManyAndReturn
   */
  export type ZapUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Zap
     */
    select?: ZapSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Zap
     */
    omit?: ZapOmit<ExtArgs> | null
    /**
     * The data used to update Zaps.
     */
    data: XOR<ZapUpdateManyMutationInput, ZapUncheckedUpdateManyInput>
    /**
     * Filter which Zaps to update
     */
    where?: ZapWhereInput
    /**
     * Limit how many Zaps to update.
     */
    limit?: number
  }

  /**
   * Zap upsert
   */
  export type ZapUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Zap
     */
    select?: ZapSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Zap
     */
    omit?: ZapOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapInclude<ExtArgs> | null
    /**
     * The filter to search for the Zap to update in case it exists.
     */
    where: ZapWhereUniqueInput
    /**
     * In case the Zap found by the `where` argument doesn't exist, create a new Zap with this data.
     */
    create: XOR<ZapCreateInput, ZapUncheckedCreateInput>
    /**
     * In case the Zap was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ZapUpdateInput, ZapUncheckedUpdateInput>
  }

  /**
   * Zap delete
   */
  export type ZapDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Zap
     */
    select?: ZapSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Zap
     */
    omit?: ZapOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapInclude<ExtArgs> | null
    /**
     * Filter which Zap to delete.
     */
    where: ZapWhereUniqueInput
  }

  /**
   * Zap deleteMany
   */
  export type ZapDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Zaps to delete
     */
    where?: ZapWhereInput
    /**
     * Limit how many Zaps to delete.
     */
    limit?: number
  }

  /**
   * Zap.trigger
   */
  export type Zap$triggerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerInclude<ExtArgs> | null
    where?: TriggerWhereInput
  }

  /**
   * Zap.actions
   */
  export type Zap$actionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsInclude<ExtArgs> | null
    where?: ActionsWhereInput
    orderBy?: ActionsOrderByWithRelationInput | ActionsOrderByWithRelationInput[]
    cursor?: ActionsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ActionsScalarFieldEnum | ActionsScalarFieldEnum[]
  }

  /**
   * Zap.zaprun
   */
  export type Zap$zaprunArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRun
     */
    select?: ZapRunSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRun
     */
    omit?: ZapRunOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunInclude<ExtArgs> | null
    where?: ZapRunWhereInput
    orderBy?: ZapRunOrderByWithRelationInput | ZapRunOrderByWithRelationInput[]
    cursor?: ZapRunWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ZapRunScalarFieldEnum | ZapRunScalarFieldEnum[]
  }

  /**
   * Zap without action
   */
  export type ZapDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Zap
     */
    select?: ZapSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Zap
     */
    omit?: ZapOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapInclude<ExtArgs> | null
  }


  /**
   * Model Trigger
   */

  export type AggregateTrigger = {
    _count: TriggerCountAggregateOutputType | null
    _min: TriggerMinAggregateOutputType | null
    _max: TriggerMaxAggregateOutputType | null
  }

  export type TriggerMinAggregateOutputType = {
    id: string | null
    ZapID: string | null
    tiggerID: string | null
  }

  export type TriggerMaxAggregateOutputType = {
    id: string | null
    ZapID: string | null
    tiggerID: string | null
  }

  export type TriggerCountAggregateOutputType = {
    id: number
    ZapID: number
    tiggerID: number
    _all: number
  }


  export type TriggerMinAggregateInputType = {
    id?: true
    ZapID?: true
    tiggerID?: true
  }

  export type TriggerMaxAggregateInputType = {
    id?: true
    ZapID?: true
    tiggerID?: true
  }

  export type TriggerCountAggregateInputType = {
    id?: true
    ZapID?: true
    tiggerID?: true
    _all?: true
  }

  export type TriggerAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Trigger to aggregate.
     */
    where?: TriggerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Triggers to fetch.
     */
    orderBy?: TriggerOrderByWithRelationInput | TriggerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TriggerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Triggers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Triggers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Triggers
    **/
    _count?: true | TriggerCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TriggerMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TriggerMaxAggregateInputType
  }

  export type GetTriggerAggregateType<T extends TriggerAggregateArgs> = {
        [P in keyof T & keyof AggregateTrigger]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTrigger[P]>
      : GetScalarType<T[P], AggregateTrigger[P]>
  }




  export type TriggerGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TriggerWhereInput
    orderBy?: TriggerOrderByWithAggregationInput | TriggerOrderByWithAggregationInput[]
    by: TriggerScalarFieldEnum[] | TriggerScalarFieldEnum
    having?: TriggerScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TriggerCountAggregateInputType | true
    _min?: TriggerMinAggregateInputType
    _max?: TriggerMaxAggregateInputType
  }

  export type TriggerGroupByOutputType = {
    id: string
    ZapID: string
    tiggerID: string
    _count: TriggerCountAggregateOutputType | null
    _min: TriggerMinAggregateOutputType | null
    _max: TriggerMaxAggregateOutputType | null
  }

  type GetTriggerGroupByPayload<T extends TriggerGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TriggerGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TriggerGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TriggerGroupByOutputType[P]>
            : GetScalarType<T[P], TriggerGroupByOutputType[P]>
        }
      >
    >


  export type TriggerSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    ZapID?: boolean
    tiggerID?: boolean
    type?: boolean | TriggerTypeDefaultArgs<ExtArgs>
    zap?: boolean | ZapDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["trigger"]>

  export type TriggerSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    ZapID?: boolean
    tiggerID?: boolean
    type?: boolean | TriggerTypeDefaultArgs<ExtArgs>
    zap?: boolean | ZapDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["trigger"]>

  export type TriggerSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    ZapID?: boolean
    tiggerID?: boolean
    type?: boolean | TriggerTypeDefaultArgs<ExtArgs>
    zap?: boolean | ZapDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["trigger"]>

  export type TriggerSelectScalar = {
    id?: boolean
    ZapID?: boolean
    tiggerID?: boolean
  }

  export type TriggerOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "ZapID" | "tiggerID", ExtArgs["result"]["trigger"]>
  export type TriggerInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    type?: boolean | TriggerTypeDefaultArgs<ExtArgs>
    zap?: boolean | ZapDefaultArgs<ExtArgs>
  }
  export type TriggerIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    type?: boolean | TriggerTypeDefaultArgs<ExtArgs>
    zap?: boolean | ZapDefaultArgs<ExtArgs>
  }
  export type TriggerIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    type?: boolean | TriggerTypeDefaultArgs<ExtArgs>
    zap?: boolean | ZapDefaultArgs<ExtArgs>
  }

  export type $TriggerPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Trigger"
    objects: {
      type: Prisma.$TriggerTypePayload<ExtArgs>
      zap: Prisma.$ZapPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      ZapID: string
      tiggerID: string
    }, ExtArgs["result"]["trigger"]>
    composites: {}
  }

  type TriggerGetPayload<S extends boolean | null | undefined | TriggerDefaultArgs> = $Result.GetResult<Prisma.$TriggerPayload, S>

  type TriggerCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<TriggerFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: TriggerCountAggregateInputType | true
    }

  export interface TriggerDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Trigger'], meta: { name: 'Trigger' } }
    /**
     * Find zero or one Trigger that matches the filter.
     * @param {TriggerFindUniqueArgs} args - Arguments to find a Trigger
     * @example
     * // Get one Trigger
     * const trigger = await prisma.trigger.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends TriggerFindUniqueArgs>(args: SelectSubset<T, TriggerFindUniqueArgs<ExtArgs>>): Prisma__TriggerClient<$Result.GetResult<Prisma.$TriggerPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Trigger that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {TriggerFindUniqueOrThrowArgs} args - Arguments to find a Trigger
     * @example
     * // Get one Trigger
     * const trigger = await prisma.trigger.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends TriggerFindUniqueOrThrowArgs>(args: SelectSubset<T, TriggerFindUniqueOrThrowArgs<ExtArgs>>): Prisma__TriggerClient<$Result.GetResult<Prisma.$TriggerPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Trigger that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerFindFirstArgs} args - Arguments to find a Trigger
     * @example
     * // Get one Trigger
     * const trigger = await prisma.trigger.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends TriggerFindFirstArgs>(args?: SelectSubset<T, TriggerFindFirstArgs<ExtArgs>>): Prisma__TriggerClient<$Result.GetResult<Prisma.$TriggerPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Trigger that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerFindFirstOrThrowArgs} args - Arguments to find a Trigger
     * @example
     * // Get one Trigger
     * const trigger = await prisma.trigger.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends TriggerFindFirstOrThrowArgs>(args?: SelectSubset<T, TriggerFindFirstOrThrowArgs<ExtArgs>>): Prisma__TriggerClient<$Result.GetResult<Prisma.$TriggerPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Triggers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Triggers
     * const triggers = await prisma.trigger.findMany()
     * 
     * // Get first 10 Triggers
     * const triggers = await prisma.trigger.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const triggerWithIdOnly = await prisma.trigger.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends TriggerFindManyArgs>(args?: SelectSubset<T, TriggerFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TriggerPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Trigger.
     * @param {TriggerCreateArgs} args - Arguments to create a Trigger.
     * @example
     * // Create one Trigger
     * const Trigger = await prisma.trigger.create({
     *   data: {
     *     // ... data to create a Trigger
     *   }
     * })
     * 
     */
    create<T extends TriggerCreateArgs>(args: SelectSubset<T, TriggerCreateArgs<ExtArgs>>): Prisma__TriggerClient<$Result.GetResult<Prisma.$TriggerPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Triggers.
     * @param {TriggerCreateManyArgs} args - Arguments to create many Triggers.
     * @example
     * // Create many Triggers
     * const trigger = await prisma.trigger.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends TriggerCreateManyArgs>(args?: SelectSubset<T, TriggerCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Triggers and returns the data saved in the database.
     * @param {TriggerCreateManyAndReturnArgs} args - Arguments to create many Triggers.
     * @example
     * // Create many Triggers
     * const trigger = await prisma.trigger.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Triggers and only return the `id`
     * const triggerWithIdOnly = await prisma.trigger.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends TriggerCreateManyAndReturnArgs>(args?: SelectSubset<T, TriggerCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TriggerPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Trigger.
     * @param {TriggerDeleteArgs} args - Arguments to delete one Trigger.
     * @example
     * // Delete one Trigger
     * const Trigger = await prisma.trigger.delete({
     *   where: {
     *     // ... filter to delete one Trigger
     *   }
     * })
     * 
     */
    delete<T extends TriggerDeleteArgs>(args: SelectSubset<T, TriggerDeleteArgs<ExtArgs>>): Prisma__TriggerClient<$Result.GetResult<Prisma.$TriggerPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Trigger.
     * @param {TriggerUpdateArgs} args - Arguments to update one Trigger.
     * @example
     * // Update one Trigger
     * const trigger = await prisma.trigger.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends TriggerUpdateArgs>(args: SelectSubset<T, TriggerUpdateArgs<ExtArgs>>): Prisma__TriggerClient<$Result.GetResult<Prisma.$TriggerPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Triggers.
     * @param {TriggerDeleteManyArgs} args - Arguments to filter Triggers to delete.
     * @example
     * // Delete a few Triggers
     * const { count } = await prisma.trigger.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends TriggerDeleteManyArgs>(args?: SelectSubset<T, TriggerDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Triggers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Triggers
     * const trigger = await prisma.trigger.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends TriggerUpdateManyArgs>(args: SelectSubset<T, TriggerUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Triggers and returns the data updated in the database.
     * @param {TriggerUpdateManyAndReturnArgs} args - Arguments to update many Triggers.
     * @example
     * // Update many Triggers
     * const trigger = await prisma.trigger.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Triggers and only return the `id`
     * const triggerWithIdOnly = await prisma.trigger.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends TriggerUpdateManyAndReturnArgs>(args: SelectSubset<T, TriggerUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TriggerPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Trigger.
     * @param {TriggerUpsertArgs} args - Arguments to update or create a Trigger.
     * @example
     * // Update or create a Trigger
     * const trigger = await prisma.trigger.upsert({
     *   create: {
     *     // ... data to create a Trigger
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Trigger we want to update
     *   }
     * })
     */
    upsert<T extends TriggerUpsertArgs>(args: SelectSubset<T, TriggerUpsertArgs<ExtArgs>>): Prisma__TriggerClient<$Result.GetResult<Prisma.$TriggerPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Triggers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerCountArgs} args - Arguments to filter Triggers to count.
     * @example
     * // Count the number of Triggers
     * const count = await prisma.trigger.count({
     *   where: {
     *     // ... the filter for the Triggers we want to count
     *   }
     * })
    **/
    count<T extends TriggerCountArgs>(
      args?: Subset<T, TriggerCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TriggerCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Trigger.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TriggerAggregateArgs>(args: Subset<T, TriggerAggregateArgs>): Prisma.PrismaPromise<GetTriggerAggregateType<T>>

    /**
     * Group by Trigger.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TriggerGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TriggerGroupByArgs['orderBy'] }
        : { orderBy?: TriggerGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TriggerGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTriggerGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Trigger model
   */
  readonly fields: TriggerFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Trigger.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TriggerClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    type<T extends TriggerTypeDefaultArgs<ExtArgs> = {}>(args?: Subset<T, TriggerTypeDefaultArgs<ExtArgs>>): Prisma__TriggerTypeClient<$Result.GetResult<Prisma.$TriggerTypePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    zap<T extends ZapDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ZapDefaultArgs<ExtArgs>>): Prisma__ZapClient<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Trigger model
   */
  interface TriggerFieldRefs {
    readonly id: FieldRef<"Trigger", 'String'>
    readonly ZapID: FieldRef<"Trigger", 'String'>
    readonly tiggerID: FieldRef<"Trigger", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Trigger findUnique
   */
  export type TriggerFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerInclude<ExtArgs> | null
    /**
     * Filter, which Trigger to fetch.
     */
    where: TriggerWhereUniqueInput
  }

  /**
   * Trigger findUniqueOrThrow
   */
  export type TriggerFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerInclude<ExtArgs> | null
    /**
     * Filter, which Trigger to fetch.
     */
    where: TriggerWhereUniqueInput
  }

  /**
   * Trigger findFirst
   */
  export type TriggerFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerInclude<ExtArgs> | null
    /**
     * Filter, which Trigger to fetch.
     */
    where?: TriggerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Triggers to fetch.
     */
    orderBy?: TriggerOrderByWithRelationInput | TriggerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Triggers.
     */
    cursor?: TriggerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Triggers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Triggers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Triggers.
     */
    distinct?: TriggerScalarFieldEnum | TriggerScalarFieldEnum[]
  }

  /**
   * Trigger findFirstOrThrow
   */
  export type TriggerFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerInclude<ExtArgs> | null
    /**
     * Filter, which Trigger to fetch.
     */
    where?: TriggerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Triggers to fetch.
     */
    orderBy?: TriggerOrderByWithRelationInput | TriggerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Triggers.
     */
    cursor?: TriggerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Triggers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Triggers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Triggers.
     */
    distinct?: TriggerScalarFieldEnum | TriggerScalarFieldEnum[]
  }

  /**
   * Trigger findMany
   */
  export type TriggerFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerInclude<ExtArgs> | null
    /**
     * Filter, which Triggers to fetch.
     */
    where?: TriggerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Triggers to fetch.
     */
    orderBy?: TriggerOrderByWithRelationInput | TriggerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Triggers.
     */
    cursor?: TriggerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Triggers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Triggers.
     */
    skip?: number
    distinct?: TriggerScalarFieldEnum | TriggerScalarFieldEnum[]
  }

  /**
   * Trigger create
   */
  export type TriggerCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerInclude<ExtArgs> | null
    /**
     * The data needed to create a Trigger.
     */
    data: XOR<TriggerCreateInput, TriggerUncheckedCreateInput>
  }

  /**
   * Trigger createMany
   */
  export type TriggerCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Triggers.
     */
    data: TriggerCreateManyInput | TriggerCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Trigger createManyAndReturn
   */
  export type TriggerCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * The data used to create many Triggers.
     */
    data: TriggerCreateManyInput | TriggerCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Trigger update
   */
  export type TriggerUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerInclude<ExtArgs> | null
    /**
     * The data needed to update a Trigger.
     */
    data: XOR<TriggerUpdateInput, TriggerUncheckedUpdateInput>
    /**
     * Choose, which Trigger to update.
     */
    where: TriggerWhereUniqueInput
  }

  /**
   * Trigger updateMany
   */
  export type TriggerUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Triggers.
     */
    data: XOR<TriggerUpdateManyMutationInput, TriggerUncheckedUpdateManyInput>
    /**
     * Filter which Triggers to update
     */
    where?: TriggerWhereInput
    /**
     * Limit how many Triggers to update.
     */
    limit?: number
  }

  /**
   * Trigger updateManyAndReturn
   */
  export type TriggerUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * The data used to update Triggers.
     */
    data: XOR<TriggerUpdateManyMutationInput, TriggerUncheckedUpdateManyInput>
    /**
     * Filter which Triggers to update
     */
    where?: TriggerWhereInput
    /**
     * Limit how many Triggers to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Trigger upsert
   */
  export type TriggerUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerInclude<ExtArgs> | null
    /**
     * The filter to search for the Trigger to update in case it exists.
     */
    where: TriggerWhereUniqueInput
    /**
     * In case the Trigger found by the `where` argument doesn't exist, create a new Trigger with this data.
     */
    create: XOR<TriggerCreateInput, TriggerUncheckedCreateInput>
    /**
     * In case the Trigger was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TriggerUpdateInput, TriggerUncheckedUpdateInput>
  }

  /**
   * Trigger delete
   */
  export type TriggerDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerInclude<ExtArgs> | null
    /**
     * Filter which Trigger to delete.
     */
    where: TriggerWhereUniqueInput
  }

  /**
   * Trigger deleteMany
   */
  export type TriggerDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Triggers to delete
     */
    where?: TriggerWhereInput
    /**
     * Limit how many Triggers to delete.
     */
    limit?: number
  }

  /**
   * Trigger without action
   */
  export type TriggerDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerInclude<ExtArgs> | null
  }


  /**
   * Model Actions
   */

  export type AggregateActions = {
    _count: ActionsCountAggregateOutputType | null
    _min: ActionsMinAggregateOutputType | null
    _max: ActionsMaxAggregateOutputType | null
  }

  export type ActionsMinAggregateOutputType = {
    id: string | null
    ZapID: string | null
    actionID: string | null
  }

  export type ActionsMaxAggregateOutputType = {
    id: string | null
    ZapID: string | null
    actionID: string | null
  }

  export type ActionsCountAggregateOutputType = {
    id: number
    ZapID: number
    actionID: number
    _all: number
  }


  export type ActionsMinAggregateInputType = {
    id?: true
    ZapID?: true
    actionID?: true
  }

  export type ActionsMaxAggregateInputType = {
    id?: true
    ZapID?: true
    actionID?: true
  }

  export type ActionsCountAggregateInputType = {
    id?: true
    ZapID?: true
    actionID?: true
    _all?: true
  }

  export type ActionsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Actions to aggregate.
     */
    where?: ActionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Actions to fetch.
     */
    orderBy?: ActionsOrderByWithRelationInput | ActionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ActionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Actions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Actions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Actions
    **/
    _count?: true | ActionsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ActionsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ActionsMaxAggregateInputType
  }

  export type GetActionsAggregateType<T extends ActionsAggregateArgs> = {
        [P in keyof T & keyof AggregateActions]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateActions[P]>
      : GetScalarType<T[P], AggregateActions[P]>
  }




  export type ActionsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ActionsWhereInput
    orderBy?: ActionsOrderByWithAggregationInput | ActionsOrderByWithAggregationInput[]
    by: ActionsScalarFieldEnum[] | ActionsScalarFieldEnum
    having?: ActionsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ActionsCountAggregateInputType | true
    _min?: ActionsMinAggregateInputType
    _max?: ActionsMaxAggregateInputType
  }

  export type ActionsGroupByOutputType = {
    id: string
    ZapID: string
    actionID: string
    _count: ActionsCountAggregateOutputType | null
    _min: ActionsMinAggregateOutputType | null
    _max: ActionsMaxAggregateOutputType | null
  }

  type GetActionsGroupByPayload<T extends ActionsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ActionsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ActionsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ActionsGroupByOutputType[P]>
            : GetScalarType<T[P], ActionsGroupByOutputType[P]>
        }
      >
    >


  export type ActionsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    ZapID?: boolean
    actionID?: boolean
    zap?: boolean | ZapDefaultArgs<ExtArgs>
    ActionType?: boolean | AvalibleActionsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["actions"]>

  export type ActionsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    ZapID?: boolean
    actionID?: boolean
    zap?: boolean | ZapDefaultArgs<ExtArgs>
    ActionType?: boolean | AvalibleActionsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["actions"]>

  export type ActionsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    ZapID?: boolean
    actionID?: boolean
    zap?: boolean | ZapDefaultArgs<ExtArgs>
    ActionType?: boolean | AvalibleActionsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["actions"]>

  export type ActionsSelectScalar = {
    id?: boolean
    ZapID?: boolean
    actionID?: boolean
  }

  export type ActionsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "ZapID" | "actionID", ExtArgs["result"]["actions"]>
  export type ActionsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    zap?: boolean | ZapDefaultArgs<ExtArgs>
    ActionType?: boolean | AvalibleActionsDefaultArgs<ExtArgs>
  }
  export type ActionsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    zap?: boolean | ZapDefaultArgs<ExtArgs>
    ActionType?: boolean | AvalibleActionsDefaultArgs<ExtArgs>
  }
  export type ActionsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    zap?: boolean | ZapDefaultArgs<ExtArgs>
    ActionType?: boolean | AvalibleActionsDefaultArgs<ExtArgs>
  }

  export type $ActionsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Actions"
    objects: {
      zap: Prisma.$ZapPayload<ExtArgs>
      ActionType: Prisma.$AvalibleActionsPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      ZapID: string
      actionID: string
    }, ExtArgs["result"]["actions"]>
    composites: {}
  }

  type ActionsGetPayload<S extends boolean | null | undefined | ActionsDefaultArgs> = $Result.GetResult<Prisma.$ActionsPayload, S>

  type ActionsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ActionsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ActionsCountAggregateInputType | true
    }

  export interface ActionsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Actions'], meta: { name: 'Actions' } }
    /**
     * Find zero or one Actions that matches the filter.
     * @param {ActionsFindUniqueArgs} args - Arguments to find a Actions
     * @example
     * // Get one Actions
     * const actions = await prisma.actions.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ActionsFindUniqueArgs>(args: SelectSubset<T, ActionsFindUniqueArgs<ExtArgs>>): Prisma__ActionsClient<$Result.GetResult<Prisma.$ActionsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Actions that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ActionsFindUniqueOrThrowArgs} args - Arguments to find a Actions
     * @example
     * // Get one Actions
     * const actions = await prisma.actions.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ActionsFindUniqueOrThrowArgs>(args: SelectSubset<T, ActionsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ActionsClient<$Result.GetResult<Prisma.$ActionsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Actions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActionsFindFirstArgs} args - Arguments to find a Actions
     * @example
     * // Get one Actions
     * const actions = await prisma.actions.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ActionsFindFirstArgs>(args?: SelectSubset<T, ActionsFindFirstArgs<ExtArgs>>): Prisma__ActionsClient<$Result.GetResult<Prisma.$ActionsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Actions that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActionsFindFirstOrThrowArgs} args - Arguments to find a Actions
     * @example
     * // Get one Actions
     * const actions = await prisma.actions.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ActionsFindFirstOrThrowArgs>(args?: SelectSubset<T, ActionsFindFirstOrThrowArgs<ExtArgs>>): Prisma__ActionsClient<$Result.GetResult<Prisma.$ActionsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Actions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActionsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Actions
     * const actions = await prisma.actions.findMany()
     * 
     * // Get first 10 Actions
     * const actions = await prisma.actions.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const actionsWithIdOnly = await prisma.actions.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ActionsFindManyArgs>(args?: SelectSubset<T, ActionsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ActionsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Actions.
     * @param {ActionsCreateArgs} args - Arguments to create a Actions.
     * @example
     * // Create one Actions
     * const Actions = await prisma.actions.create({
     *   data: {
     *     // ... data to create a Actions
     *   }
     * })
     * 
     */
    create<T extends ActionsCreateArgs>(args: SelectSubset<T, ActionsCreateArgs<ExtArgs>>): Prisma__ActionsClient<$Result.GetResult<Prisma.$ActionsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Actions.
     * @param {ActionsCreateManyArgs} args - Arguments to create many Actions.
     * @example
     * // Create many Actions
     * const actions = await prisma.actions.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ActionsCreateManyArgs>(args?: SelectSubset<T, ActionsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Actions and returns the data saved in the database.
     * @param {ActionsCreateManyAndReturnArgs} args - Arguments to create many Actions.
     * @example
     * // Create many Actions
     * const actions = await prisma.actions.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Actions and only return the `id`
     * const actionsWithIdOnly = await prisma.actions.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ActionsCreateManyAndReturnArgs>(args?: SelectSubset<T, ActionsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ActionsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Actions.
     * @param {ActionsDeleteArgs} args - Arguments to delete one Actions.
     * @example
     * // Delete one Actions
     * const Actions = await prisma.actions.delete({
     *   where: {
     *     // ... filter to delete one Actions
     *   }
     * })
     * 
     */
    delete<T extends ActionsDeleteArgs>(args: SelectSubset<T, ActionsDeleteArgs<ExtArgs>>): Prisma__ActionsClient<$Result.GetResult<Prisma.$ActionsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Actions.
     * @param {ActionsUpdateArgs} args - Arguments to update one Actions.
     * @example
     * // Update one Actions
     * const actions = await prisma.actions.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ActionsUpdateArgs>(args: SelectSubset<T, ActionsUpdateArgs<ExtArgs>>): Prisma__ActionsClient<$Result.GetResult<Prisma.$ActionsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Actions.
     * @param {ActionsDeleteManyArgs} args - Arguments to filter Actions to delete.
     * @example
     * // Delete a few Actions
     * const { count } = await prisma.actions.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ActionsDeleteManyArgs>(args?: SelectSubset<T, ActionsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Actions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActionsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Actions
     * const actions = await prisma.actions.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ActionsUpdateManyArgs>(args: SelectSubset<T, ActionsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Actions and returns the data updated in the database.
     * @param {ActionsUpdateManyAndReturnArgs} args - Arguments to update many Actions.
     * @example
     * // Update many Actions
     * const actions = await prisma.actions.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Actions and only return the `id`
     * const actionsWithIdOnly = await prisma.actions.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ActionsUpdateManyAndReturnArgs>(args: SelectSubset<T, ActionsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ActionsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Actions.
     * @param {ActionsUpsertArgs} args - Arguments to update or create a Actions.
     * @example
     * // Update or create a Actions
     * const actions = await prisma.actions.upsert({
     *   create: {
     *     // ... data to create a Actions
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Actions we want to update
     *   }
     * })
     */
    upsert<T extends ActionsUpsertArgs>(args: SelectSubset<T, ActionsUpsertArgs<ExtArgs>>): Prisma__ActionsClient<$Result.GetResult<Prisma.$ActionsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Actions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActionsCountArgs} args - Arguments to filter Actions to count.
     * @example
     * // Count the number of Actions
     * const count = await prisma.actions.count({
     *   where: {
     *     // ... the filter for the Actions we want to count
     *   }
     * })
    **/
    count<T extends ActionsCountArgs>(
      args?: Subset<T, ActionsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ActionsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Actions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActionsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ActionsAggregateArgs>(args: Subset<T, ActionsAggregateArgs>): Prisma.PrismaPromise<GetActionsAggregateType<T>>

    /**
     * Group by Actions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ActionsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ActionsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ActionsGroupByArgs['orderBy'] }
        : { orderBy?: ActionsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ActionsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetActionsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Actions model
   */
  readonly fields: ActionsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Actions.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ActionsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    zap<T extends ZapDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ZapDefaultArgs<ExtArgs>>): Prisma__ZapClient<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    ActionType<T extends AvalibleActionsDefaultArgs<ExtArgs> = {}>(args?: Subset<T, AvalibleActionsDefaultArgs<ExtArgs>>): Prisma__AvalibleActionsClient<$Result.GetResult<Prisma.$AvalibleActionsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Actions model
   */
  interface ActionsFieldRefs {
    readonly id: FieldRef<"Actions", 'String'>
    readonly ZapID: FieldRef<"Actions", 'String'>
    readonly actionID: FieldRef<"Actions", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Actions findUnique
   */
  export type ActionsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsInclude<ExtArgs> | null
    /**
     * Filter, which Actions to fetch.
     */
    where: ActionsWhereUniqueInput
  }

  /**
   * Actions findUniqueOrThrow
   */
  export type ActionsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsInclude<ExtArgs> | null
    /**
     * Filter, which Actions to fetch.
     */
    where: ActionsWhereUniqueInput
  }

  /**
   * Actions findFirst
   */
  export type ActionsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsInclude<ExtArgs> | null
    /**
     * Filter, which Actions to fetch.
     */
    where?: ActionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Actions to fetch.
     */
    orderBy?: ActionsOrderByWithRelationInput | ActionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Actions.
     */
    cursor?: ActionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Actions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Actions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Actions.
     */
    distinct?: ActionsScalarFieldEnum | ActionsScalarFieldEnum[]
  }

  /**
   * Actions findFirstOrThrow
   */
  export type ActionsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsInclude<ExtArgs> | null
    /**
     * Filter, which Actions to fetch.
     */
    where?: ActionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Actions to fetch.
     */
    orderBy?: ActionsOrderByWithRelationInput | ActionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Actions.
     */
    cursor?: ActionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Actions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Actions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Actions.
     */
    distinct?: ActionsScalarFieldEnum | ActionsScalarFieldEnum[]
  }

  /**
   * Actions findMany
   */
  export type ActionsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsInclude<ExtArgs> | null
    /**
     * Filter, which Actions to fetch.
     */
    where?: ActionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Actions to fetch.
     */
    orderBy?: ActionsOrderByWithRelationInput | ActionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Actions.
     */
    cursor?: ActionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Actions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Actions.
     */
    skip?: number
    distinct?: ActionsScalarFieldEnum | ActionsScalarFieldEnum[]
  }

  /**
   * Actions create
   */
  export type ActionsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsInclude<ExtArgs> | null
    /**
     * The data needed to create a Actions.
     */
    data: XOR<ActionsCreateInput, ActionsUncheckedCreateInput>
  }

  /**
   * Actions createMany
   */
  export type ActionsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Actions.
     */
    data: ActionsCreateManyInput | ActionsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Actions createManyAndReturn
   */
  export type ActionsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * The data used to create many Actions.
     */
    data: ActionsCreateManyInput | ActionsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Actions update
   */
  export type ActionsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsInclude<ExtArgs> | null
    /**
     * The data needed to update a Actions.
     */
    data: XOR<ActionsUpdateInput, ActionsUncheckedUpdateInput>
    /**
     * Choose, which Actions to update.
     */
    where: ActionsWhereUniqueInput
  }

  /**
   * Actions updateMany
   */
  export type ActionsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Actions.
     */
    data: XOR<ActionsUpdateManyMutationInput, ActionsUncheckedUpdateManyInput>
    /**
     * Filter which Actions to update
     */
    where?: ActionsWhereInput
    /**
     * Limit how many Actions to update.
     */
    limit?: number
  }

  /**
   * Actions updateManyAndReturn
   */
  export type ActionsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * The data used to update Actions.
     */
    data: XOR<ActionsUpdateManyMutationInput, ActionsUncheckedUpdateManyInput>
    /**
     * Filter which Actions to update
     */
    where?: ActionsWhereInput
    /**
     * Limit how many Actions to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Actions upsert
   */
  export type ActionsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsInclude<ExtArgs> | null
    /**
     * The filter to search for the Actions to update in case it exists.
     */
    where: ActionsWhereUniqueInput
    /**
     * In case the Actions found by the `where` argument doesn't exist, create a new Actions with this data.
     */
    create: XOR<ActionsCreateInput, ActionsUncheckedCreateInput>
    /**
     * In case the Actions was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ActionsUpdateInput, ActionsUncheckedUpdateInput>
  }

  /**
   * Actions delete
   */
  export type ActionsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsInclude<ExtArgs> | null
    /**
     * Filter which Actions to delete.
     */
    where: ActionsWhereUniqueInput
  }

  /**
   * Actions deleteMany
   */
  export type ActionsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Actions to delete
     */
    where?: ActionsWhereInput
    /**
     * Limit how many Actions to delete.
     */
    limit?: number
  }

  /**
   * Actions without action
   */
  export type ActionsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsInclude<ExtArgs> | null
  }


  /**
   * Model AvalibleActions
   */

  export type AggregateAvalibleActions = {
    _count: AvalibleActionsCountAggregateOutputType | null
    _min: AvalibleActionsMinAggregateOutputType | null
    _max: AvalibleActionsMaxAggregateOutputType | null
  }

  export type AvalibleActionsMinAggregateOutputType = {
    id: string | null
    name: string | null
  }

  export type AvalibleActionsMaxAggregateOutputType = {
    id: string | null
    name: string | null
  }

  export type AvalibleActionsCountAggregateOutputType = {
    id: number
    name: number
    _all: number
  }


  export type AvalibleActionsMinAggregateInputType = {
    id?: true
    name?: true
  }

  export type AvalibleActionsMaxAggregateInputType = {
    id?: true
    name?: true
  }

  export type AvalibleActionsCountAggregateInputType = {
    id?: true
    name?: true
    _all?: true
  }

  export type AvalibleActionsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AvalibleActions to aggregate.
     */
    where?: AvalibleActionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AvalibleActions to fetch.
     */
    orderBy?: AvalibleActionsOrderByWithRelationInput | AvalibleActionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AvalibleActionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AvalibleActions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AvalibleActions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned AvalibleActions
    **/
    _count?: true | AvalibleActionsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AvalibleActionsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AvalibleActionsMaxAggregateInputType
  }

  export type GetAvalibleActionsAggregateType<T extends AvalibleActionsAggregateArgs> = {
        [P in keyof T & keyof AggregateAvalibleActions]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAvalibleActions[P]>
      : GetScalarType<T[P], AggregateAvalibleActions[P]>
  }




  export type AvalibleActionsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AvalibleActionsWhereInput
    orderBy?: AvalibleActionsOrderByWithAggregationInput | AvalibleActionsOrderByWithAggregationInput[]
    by: AvalibleActionsScalarFieldEnum[] | AvalibleActionsScalarFieldEnum
    having?: AvalibleActionsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AvalibleActionsCountAggregateInputType | true
    _min?: AvalibleActionsMinAggregateInputType
    _max?: AvalibleActionsMaxAggregateInputType
  }

  export type AvalibleActionsGroupByOutputType = {
    id: string
    name: string
    _count: AvalibleActionsCountAggregateOutputType | null
    _min: AvalibleActionsMinAggregateOutputType | null
    _max: AvalibleActionsMaxAggregateOutputType | null
  }

  type GetAvalibleActionsGroupByPayload<T extends AvalibleActionsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AvalibleActionsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AvalibleActionsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AvalibleActionsGroupByOutputType[P]>
            : GetScalarType<T[P], AvalibleActionsGroupByOutputType[P]>
        }
      >
    >


  export type AvalibleActionsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    action?: boolean | AvalibleActions$actionArgs<ExtArgs>
    _count?: boolean | AvalibleActionsCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["avalibleActions"]>

  export type AvalibleActionsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
  }, ExtArgs["result"]["avalibleActions"]>

  export type AvalibleActionsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
  }, ExtArgs["result"]["avalibleActions"]>

  export type AvalibleActionsSelectScalar = {
    id?: boolean
    name?: boolean
  }

  export type AvalibleActionsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name", ExtArgs["result"]["avalibleActions"]>
  export type AvalibleActionsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    action?: boolean | AvalibleActions$actionArgs<ExtArgs>
    _count?: boolean | AvalibleActionsCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type AvalibleActionsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type AvalibleActionsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $AvalibleActionsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "AvalibleActions"
    objects: {
      action: Prisma.$ActionsPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
    }, ExtArgs["result"]["avalibleActions"]>
    composites: {}
  }

  type AvalibleActionsGetPayload<S extends boolean | null | undefined | AvalibleActionsDefaultArgs> = $Result.GetResult<Prisma.$AvalibleActionsPayload, S>

  type AvalibleActionsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<AvalibleActionsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AvalibleActionsCountAggregateInputType | true
    }

  export interface AvalibleActionsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['AvalibleActions'], meta: { name: 'AvalibleActions' } }
    /**
     * Find zero or one AvalibleActions that matches the filter.
     * @param {AvalibleActionsFindUniqueArgs} args - Arguments to find a AvalibleActions
     * @example
     * // Get one AvalibleActions
     * const avalibleActions = await prisma.avalibleActions.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AvalibleActionsFindUniqueArgs>(args: SelectSubset<T, AvalibleActionsFindUniqueArgs<ExtArgs>>): Prisma__AvalibleActionsClient<$Result.GetResult<Prisma.$AvalibleActionsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one AvalibleActions that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {AvalibleActionsFindUniqueOrThrowArgs} args - Arguments to find a AvalibleActions
     * @example
     * // Get one AvalibleActions
     * const avalibleActions = await prisma.avalibleActions.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AvalibleActionsFindUniqueOrThrowArgs>(args: SelectSubset<T, AvalibleActionsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AvalibleActionsClient<$Result.GetResult<Prisma.$AvalibleActionsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AvalibleActions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AvalibleActionsFindFirstArgs} args - Arguments to find a AvalibleActions
     * @example
     * // Get one AvalibleActions
     * const avalibleActions = await prisma.avalibleActions.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AvalibleActionsFindFirstArgs>(args?: SelectSubset<T, AvalibleActionsFindFirstArgs<ExtArgs>>): Prisma__AvalibleActionsClient<$Result.GetResult<Prisma.$AvalibleActionsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AvalibleActions that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AvalibleActionsFindFirstOrThrowArgs} args - Arguments to find a AvalibleActions
     * @example
     * // Get one AvalibleActions
     * const avalibleActions = await prisma.avalibleActions.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AvalibleActionsFindFirstOrThrowArgs>(args?: SelectSubset<T, AvalibleActionsFindFirstOrThrowArgs<ExtArgs>>): Prisma__AvalibleActionsClient<$Result.GetResult<Prisma.$AvalibleActionsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more AvalibleActions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AvalibleActionsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all AvalibleActions
     * const avalibleActions = await prisma.avalibleActions.findMany()
     * 
     * // Get first 10 AvalibleActions
     * const avalibleActions = await prisma.avalibleActions.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const avalibleActionsWithIdOnly = await prisma.avalibleActions.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends AvalibleActionsFindManyArgs>(args?: SelectSubset<T, AvalibleActionsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AvalibleActionsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a AvalibleActions.
     * @param {AvalibleActionsCreateArgs} args - Arguments to create a AvalibleActions.
     * @example
     * // Create one AvalibleActions
     * const AvalibleActions = await prisma.avalibleActions.create({
     *   data: {
     *     // ... data to create a AvalibleActions
     *   }
     * })
     * 
     */
    create<T extends AvalibleActionsCreateArgs>(args: SelectSubset<T, AvalibleActionsCreateArgs<ExtArgs>>): Prisma__AvalibleActionsClient<$Result.GetResult<Prisma.$AvalibleActionsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many AvalibleActions.
     * @param {AvalibleActionsCreateManyArgs} args - Arguments to create many AvalibleActions.
     * @example
     * // Create many AvalibleActions
     * const avalibleActions = await prisma.avalibleActions.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AvalibleActionsCreateManyArgs>(args?: SelectSubset<T, AvalibleActionsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many AvalibleActions and returns the data saved in the database.
     * @param {AvalibleActionsCreateManyAndReturnArgs} args - Arguments to create many AvalibleActions.
     * @example
     * // Create many AvalibleActions
     * const avalibleActions = await prisma.avalibleActions.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many AvalibleActions and only return the `id`
     * const avalibleActionsWithIdOnly = await prisma.avalibleActions.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends AvalibleActionsCreateManyAndReturnArgs>(args?: SelectSubset<T, AvalibleActionsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AvalibleActionsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a AvalibleActions.
     * @param {AvalibleActionsDeleteArgs} args - Arguments to delete one AvalibleActions.
     * @example
     * // Delete one AvalibleActions
     * const AvalibleActions = await prisma.avalibleActions.delete({
     *   where: {
     *     // ... filter to delete one AvalibleActions
     *   }
     * })
     * 
     */
    delete<T extends AvalibleActionsDeleteArgs>(args: SelectSubset<T, AvalibleActionsDeleteArgs<ExtArgs>>): Prisma__AvalibleActionsClient<$Result.GetResult<Prisma.$AvalibleActionsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one AvalibleActions.
     * @param {AvalibleActionsUpdateArgs} args - Arguments to update one AvalibleActions.
     * @example
     * // Update one AvalibleActions
     * const avalibleActions = await prisma.avalibleActions.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AvalibleActionsUpdateArgs>(args: SelectSubset<T, AvalibleActionsUpdateArgs<ExtArgs>>): Prisma__AvalibleActionsClient<$Result.GetResult<Prisma.$AvalibleActionsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more AvalibleActions.
     * @param {AvalibleActionsDeleteManyArgs} args - Arguments to filter AvalibleActions to delete.
     * @example
     * // Delete a few AvalibleActions
     * const { count } = await prisma.avalibleActions.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AvalibleActionsDeleteManyArgs>(args?: SelectSubset<T, AvalibleActionsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AvalibleActions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AvalibleActionsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many AvalibleActions
     * const avalibleActions = await prisma.avalibleActions.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AvalibleActionsUpdateManyArgs>(args: SelectSubset<T, AvalibleActionsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AvalibleActions and returns the data updated in the database.
     * @param {AvalibleActionsUpdateManyAndReturnArgs} args - Arguments to update many AvalibleActions.
     * @example
     * // Update many AvalibleActions
     * const avalibleActions = await prisma.avalibleActions.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more AvalibleActions and only return the `id`
     * const avalibleActionsWithIdOnly = await prisma.avalibleActions.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends AvalibleActionsUpdateManyAndReturnArgs>(args: SelectSubset<T, AvalibleActionsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AvalibleActionsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one AvalibleActions.
     * @param {AvalibleActionsUpsertArgs} args - Arguments to update or create a AvalibleActions.
     * @example
     * // Update or create a AvalibleActions
     * const avalibleActions = await prisma.avalibleActions.upsert({
     *   create: {
     *     // ... data to create a AvalibleActions
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the AvalibleActions we want to update
     *   }
     * })
     */
    upsert<T extends AvalibleActionsUpsertArgs>(args: SelectSubset<T, AvalibleActionsUpsertArgs<ExtArgs>>): Prisma__AvalibleActionsClient<$Result.GetResult<Prisma.$AvalibleActionsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of AvalibleActions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AvalibleActionsCountArgs} args - Arguments to filter AvalibleActions to count.
     * @example
     * // Count the number of AvalibleActions
     * const count = await prisma.avalibleActions.count({
     *   where: {
     *     // ... the filter for the AvalibleActions we want to count
     *   }
     * })
    **/
    count<T extends AvalibleActionsCountArgs>(
      args?: Subset<T, AvalibleActionsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AvalibleActionsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a AvalibleActions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AvalibleActionsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AvalibleActionsAggregateArgs>(args: Subset<T, AvalibleActionsAggregateArgs>): Prisma.PrismaPromise<GetAvalibleActionsAggregateType<T>>

    /**
     * Group by AvalibleActions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AvalibleActionsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AvalibleActionsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AvalibleActionsGroupByArgs['orderBy'] }
        : { orderBy?: AvalibleActionsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AvalibleActionsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAvalibleActionsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the AvalibleActions model
   */
  readonly fields: AvalibleActionsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for AvalibleActions.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AvalibleActionsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    action<T extends AvalibleActions$actionArgs<ExtArgs> = {}>(args?: Subset<T, AvalibleActions$actionArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ActionsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the AvalibleActions model
   */
  interface AvalibleActionsFieldRefs {
    readonly id: FieldRef<"AvalibleActions", 'String'>
    readonly name: FieldRef<"AvalibleActions", 'String'>
  }
    

  // Custom InputTypes
  /**
   * AvalibleActions findUnique
   */
  export type AvalibleActionsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AvalibleActions
     */
    select?: AvalibleActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AvalibleActions
     */
    omit?: AvalibleActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AvalibleActionsInclude<ExtArgs> | null
    /**
     * Filter, which AvalibleActions to fetch.
     */
    where: AvalibleActionsWhereUniqueInput
  }

  /**
   * AvalibleActions findUniqueOrThrow
   */
  export type AvalibleActionsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AvalibleActions
     */
    select?: AvalibleActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AvalibleActions
     */
    omit?: AvalibleActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AvalibleActionsInclude<ExtArgs> | null
    /**
     * Filter, which AvalibleActions to fetch.
     */
    where: AvalibleActionsWhereUniqueInput
  }

  /**
   * AvalibleActions findFirst
   */
  export type AvalibleActionsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AvalibleActions
     */
    select?: AvalibleActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AvalibleActions
     */
    omit?: AvalibleActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AvalibleActionsInclude<ExtArgs> | null
    /**
     * Filter, which AvalibleActions to fetch.
     */
    where?: AvalibleActionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AvalibleActions to fetch.
     */
    orderBy?: AvalibleActionsOrderByWithRelationInput | AvalibleActionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AvalibleActions.
     */
    cursor?: AvalibleActionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AvalibleActions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AvalibleActions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AvalibleActions.
     */
    distinct?: AvalibleActionsScalarFieldEnum | AvalibleActionsScalarFieldEnum[]
  }

  /**
   * AvalibleActions findFirstOrThrow
   */
  export type AvalibleActionsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AvalibleActions
     */
    select?: AvalibleActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AvalibleActions
     */
    omit?: AvalibleActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AvalibleActionsInclude<ExtArgs> | null
    /**
     * Filter, which AvalibleActions to fetch.
     */
    where?: AvalibleActionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AvalibleActions to fetch.
     */
    orderBy?: AvalibleActionsOrderByWithRelationInput | AvalibleActionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AvalibleActions.
     */
    cursor?: AvalibleActionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AvalibleActions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AvalibleActions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AvalibleActions.
     */
    distinct?: AvalibleActionsScalarFieldEnum | AvalibleActionsScalarFieldEnum[]
  }

  /**
   * AvalibleActions findMany
   */
  export type AvalibleActionsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AvalibleActions
     */
    select?: AvalibleActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AvalibleActions
     */
    omit?: AvalibleActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AvalibleActionsInclude<ExtArgs> | null
    /**
     * Filter, which AvalibleActions to fetch.
     */
    where?: AvalibleActionsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AvalibleActions to fetch.
     */
    orderBy?: AvalibleActionsOrderByWithRelationInput | AvalibleActionsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing AvalibleActions.
     */
    cursor?: AvalibleActionsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AvalibleActions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AvalibleActions.
     */
    skip?: number
    distinct?: AvalibleActionsScalarFieldEnum | AvalibleActionsScalarFieldEnum[]
  }

  /**
   * AvalibleActions create
   */
  export type AvalibleActionsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AvalibleActions
     */
    select?: AvalibleActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AvalibleActions
     */
    omit?: AvalibleActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AvalibleActionsInclude<ExtArgs> | null
    /**
     * The data needed to create a AvalibleActions.
     */
    data: XOR<AvalibleActionsCreateInput, AvalibleActionsUncheckedCreateInput>
  }

  /**
   * AvalibleActions createMany
   */
  export type AvalibleActionsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many AvalibleActions.
     */
    data: AvalibleActionsCreateManyInput | AvalibleActionsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AvalibleActions createManyAndReturn
   */
  export type AvalibleActionsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AvalibleActions
     */
    select?: AvalibleActionsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AvalibleActions
     */
    omit?: AvalibleActionsOmit<ExtArgs> | null
    /**
     * The data used to create many AvalibleActions.
     */
    data: AvalibleActionsCreateManyInput | AvalibleActionsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AvalibleActions update
   */
  export type AvalibleActionsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AvalibleActions
     */
    select?: AvalibleActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AvalibleActions
     */
    omit?: AvalibleActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AvalibleActionsInclude<ExtArgs> | null
    /**
     * The data needed to update a AvalibleActions.
     */
    data: XOR<AvalibleActionsUpdateInput, AvalibleActionsUncheckedUpdateInput>
    /**
     * Choose, which AvalibleActions to update.
     */
    where: AvalibleActionsWhereUniqueInput
  }

  /**
   * AvalibleActions updateMany
   */
  export type AvalibleActionsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update AvalibleActions.
     */
    data: XOR<AvalibleActionsUpdateManyMutationInput, AvalibleActionsUncheckedUpdateManyInput>
    /**
     * Filter which AvalibleActions to update
     */
    where?: AvalibleActionsWhereInput
    /**
     * Limit how many AvalibleActions to update.
     */
    limit?: number
  }

  /**
   * AvalibleActions updateManyAndReturn
   */
  export type AvalibleActionsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AvalibleActions
     */
    select?: AvalibleActionsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AvalibleActions
     */
    omit?: AvalibleActionsOmit<ExtArgs> | null
    /**
     * The data used to update AvalibleActions.
     */
    data: XOR<AvalibleActionsUpdateManyMutationInput, AvalibleActionsUncheckedUpdateManyInput>
    /**
     * Filter which AvalibleActions to update
     */
    where?: AvalibleActionsWhereInput
    /**
     * Limit how many AvalibleActions to update.
     */
    limit?: number
  }

  /**
   * AvalibleActions upsert
   */
  export type AvalibleActionsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AvalibleActions
     */
    select?: AvalibleActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AvalibleActions
     */
    omit?: AvalibleActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AvalibleActionsInclude<ExtArgs> | null
    /**
     * The filter to search for the AvalibleActions to update in case it exists.
     */
    where: AvalibleActionsWhereUniqueInput
    /**
     * In case the AvalibleActions found by the `where` argument doesn't exist, create a new AvalibleActions with this data.
     */
    create: XOR<AvalibleActionsCreateInput, AvalibleActionsUncheckedCreateInput>
    /**
     * In case the AvalibleActions was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AvalibleActionsUpdateInput, AvalibleActionsUncheckedUpdateInput>
  }

  /**
   * AvalibleActions delete
   */
  export type AvalibleActionsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AvalibleActions
     */
    select?: AvalibleActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AvalibleActions
     */
    omit?: AvalibleActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AvalibleActionsInclude<ExtArgs> | null
    /**
     * Filter which AvalibleActions to delete.
     */
    where: AvalibleActionsWhereUniqueInput
  }

  /**
   * AvalibleActions deleteMany
   */
  export type AvalibleActionsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AvalibleActions to delete
     */
    where?: AvalibleActionsWhereInput
    /**
     * Limit how many AvalibleActions to delete.
     */
    limit?: number
  }

  /**
   * AvalibleActions.action
   */
  export type AvalibleActions$actionArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Actions
     */
    select?: ActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Actions
     */
    omit?: ActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ActionsInclude<ExtArgs> | null
    where?: ActionsWhereInput
    orderBy?: ActionsOrderByWithRelationInput | ActionsOrderByWithRelationInput[]
    cursor?: ActionsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ActionsScalarFieldEnum | ActionsScalarFieldEnum[]
  }

  /**
   * AvalibleActions without action
   */
  export type AvalibleActionsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AvalibleActions
     */
    select?: AvalibleActionsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AvalibleActions
     */
    omit?: AvalibleActionsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AvalibleActionsInclude<ExtArgs> | null
  }


  /**
   * Model TriggerType
   */

  export type AggregateTriggerType = {
    _count: TriggerTypeCountAggregateOutputType | null
    _min: TriggerTypeMinAggregateOutputType | null
    _max: TriggerTypeMaxAggregateOutputType | null
  }

  export type TriggerTypeMinAggregateOutputType = {
    id: string | null
    name: string | null
  }

  export type TriggerTypeMaxAggregateOutputType = {
    id: string | null
    name: string | null
  }

  export type TriggerTypeCountAggregateOutputType = {
    id: number
    name: number
    _all: number
  }


  export type TriggerTypeMinAggregateInputType = {
    id?: true
    name?: true
  }

  export type TriggerTypeMaxAggregateInputType = {
    id?: true
    name?: true
  }

  export type TriggerTypeCountAggregateInputType = {
    id?: true
    name?: true
    _all?: true
  }

  export type TriggerTypeAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TriggerType to aggregate.
     */
    where?: TriggerTypeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TriggerTypes to fetch.
     */
    orderBy?: TriggerTypeOrderByWithRelationInput | TriggerTypeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TriggerTypeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TriggerTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TriggerTypes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned TriggerTypes
    **/
    _count?: true | TriggerTypeCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TriggerTypeMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TriggerTypeMaxAggregateInputType
  }

  export type GetTriggerTypeAggregateType<T extends TriggerTypeAggregateArgs> = {
        [P in keyof T & keyof AggregateTriggerType]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTriggerType[P]>
      : GetScalarType<T[P], AggregateTriggerType[P]>
  }




  export type TriggerTypeGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TriggerTypeWhereInput
    orderBy?: TriggerTypeOrderByWithAggregationInput | TriggerTypeOrderByWithAggregationInput[]
    by: TriggerTypeScalarFieldEnum[] | TriggerTypeScalarFieldEnum
    having?: TriggerTypeScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TriggerTypeCountAggregateInputType | true
    _min?: TriggerTypeMinAggregateInputType
    _max?: TriggerTypeMaxAggregateInputType
  }

  export type TriggerTypeGroupByOutputType = {
    id: string
    name: string
    _count: TriggerTypeCountAggregateOutputType | null
    _min: TriggerTypeMinAggregateOutputType | null
    _max: TriggerTypeMaxAggregateOutputType | null
  }

  type GetTriggerTypeGroupByPayload<T extends TriggerTypeGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TriggerTypeGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TriggerTypeGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TriggerTypeGroupByOutputType[P]>
            : GetScalarType<T[P], TriggerTypeGroupByOutputType[P]>
        }
      >
    >


  export type TriggerTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    triggr?: boolean | TriggerType$triggrArgs<ExtArgs>
    _count?: boolean | TriggerTypeCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["triggerType"]>

  export type TriggerTypeSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
  }, ExtArgs["result"]["triggerType"]>

  export type TriggerTypeSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
  }, ExtArgs["result"]["triggerType"]>

  export type TriggerTypeSelectScalar = {
    id?: boolean
    name?: boolean
  }

  export type TriggerTypeOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name", ExtArgs["result"]["triggerType"]>
  export type TriggerTypeInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    triggr?: boolean | TriggerType$triggrArgs<ExtArgs>
    _count?: boolean | TriggerTypeCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type TriggerTypeIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type TriggerTypeIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $TriggerTypePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "TriggerType"
    objects: {
      triggr: Prisma.$TriggerPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
    }, ExtArgs["result"]["triggerType"]>
    composites: {}
  }

  type TriggerTypeGetPayload<S extends boolean | null | undefined | TriggerTypeDefaultArgs> = $Result.GetResult<Prisma.$TriggerTypePayload, S>

  type TriggerTypeCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<TriggerTypeFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: TriggerTypeCountAggregateInputType | true
    }

  export interface TriggerTypeDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['TriggerType'], meta: { name: 'TriggerType' } }
    /**
     * Find zero or one TriggerType that matches the filter.
     * @param {TriggerTypeFindUniqueArgs} args - Arguments to find a TriggerType
     * @example
     * // Get one TriggerType
     * const triggerType = await prisma.triggerType.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends TriggerTypeFindUniqueArgs>(args: SelectSubset<T, TriggerTypeFindUniqueArgs<ExtArgs>>): Prisma__TriggerTypeClient<$Result.GetResult<Prisma.$TriggerTypePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one TriggerType that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {TriggerTypeFindUniqueOrThrowArgs} args - Arguments to find a TriggerType
     * @example
     * // Get one TriggerType
     * const triggerType = await prisma.triggerType.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends TriggerTypeFindUniqueOrThrowArgs>(args: SelectSubset<T, TriggerTypeFindUniqueOrThrowArgs<ExtArgs>>): Prisma__TriggerTypeClient<$Result.GetResult<Prisma.$TriggerTypePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TriggerType that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerTypeFindFirstArgs} args - Arguments to find a TriggerType
     * @example
     * // Get one TriggerType
     * const triggerType = await prisma.triggerType.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends TriggerTypeFindFirstArgs>(args?: SelectSubset<T, TriggerTypeFindFirstArgs<ExtArgs>>): Prisma__TriggerTypeClient<$Result.GetResult<Prisma.$TriggerTypePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TriggerType that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerTypeFindFirstOrThrowArgs} args - Arguments to find a TriggerType
     * @example
     * // Get one TriggerType
     * const triggerType = await prisma.triggerType.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends TriggerTypeFindFirstOrThrowArgs>(args?: SelectSubset<T, TriggerTypeFindFirstOrThrowArgs<ExtArgs>>): Prisma__TriggerTypeClient<$Result.GetResult<Prisma.$TriggerTypePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more TriggerTypes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerTypeFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all TriggerTypes
     * const triggerTypes = await prisma.triggerType.findMany()
     * 
     * // Get first 10 TriggerTypes
     * const triggerTypes = await prisma.triggerType.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const triggerTypeWithIdOnly = await prisma.triggerType.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends TriggerTypeFindManyArgs>(args?: SelectSubset<T, TriggerTypeFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TriggerTypePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a TriggerType.
     * @param {TriggerTypeCreateArgs} args - Arguments to create a TriggerType.
     * @example
     * // Create one TriggerType
     * const TriggerType = await prisma.triggerType.create({
     *   data: {
     *     // ... data to create a TriggerType
     *   }
     * })
     * 
     */
    create<T extends TriggerTypeCreateArgs>(args: SelectSubset<T, TriggerTypeCreateArgs<ExtArgs>>): Prisma__TriggerTypeClient<$Result.GetResult<Prisma.$TriggerTypePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many TriggerTypes.
     * @param {TriggerTypeCreateManyArgs} args - Arguments to create many TriggerTypes.
     * @example
     * // Create many TriggerTypes
     * const triggerType = await prisma.triggerType.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends TriggerTypeCreateManyArgs>(args?: SelectSubset<T, TriggerTypeCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many TriggerTypes and returns the data saved in the database.
     * @param {TriggerTypeCreateManyAndReturnArgs} args - Arguments to create many TriggerTypes.
     * @example
     * // Create many TriggerTypes
     * const triggerType = await prisma.triggerType.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many TriggerTypes and only return the `id`
     * const triggerTypeWithIdOnly = await prisma.triggerType.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends TriggerTypeCreateManyAndReturnArgs>(args?: SelectSubset<T, TriggerTypeCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TriggerTypePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a TriggerType.
     * @param {TriggerTypeDeleteArgs} args - Arguments to delete one TriggerType.
     * @example
     * // Delete one TriggerType
     * const TriggerType = await prisma.triggerType.delete({
     *   where: {
     *     // ... filter to delete one TriggerType
     *   }
     * })
     * 
     */
    delete<T extends TriggerTypeDeleteArgs>(args: SelectSubset<T, TriggerTypeDeleteArgs<ExtArgs>>): Prisma__TriggerTypeClient<$Result.GetResult<Prisma.$TriggerTypePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one TriggerType.
     * @param {TriggerTypeUpdateArgs} args - Arguments to update one TriggerType.
     * @example
     * // Update one TriggerType
     * const triggerType = await prisma.triggerType.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends TriggerTypeUpdateArgs>(args: SelectSubset<T, TriggerTypeUpdateArgs<ExtArgs>>): Prisma__TriggerTypeClient<$Result.GetResult<Prisma.$TriggerTypePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more TriggerTypes.
     * @param {TriggerTypeDeleteManyArgs} args - Arguments to filter TriggerTypes to delete.
     * @example
     * // Delete a few TriggerTypes
     * const { count } = await prisma.triggerType.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends TriggerTypeDeleteManyArgs>(args?: SelectSubset<T, TriggerTypeDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TriggerTypes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerTypeUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many TriggerTypes
     * const triggerType = await prisma.triggerType.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends TriggerTypeUpdateManyArgs>(args: SelectSubset<T, TriggerTypeUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TriggerTypes and returns the data updated in the database.
     * @param {TriggerTypeUpdateManyAndReturnArgs} args - Arguments to update many TriggerTypes.
     * @example
     * // Update many TriggerTypes
     * const triggerType = await prisma.triggerType.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more TriggerTypes and only return the `id`
     * const triggerTypeWithIdOnly = await prisma.triggerType.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends TriggerTypeUpdateManyAndReturnArgs>(args: SelectSubset<T, TriggerTypeUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TriggerTypePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one TriggerType.
     * @param {TriggerTypeUpsertArgs} args - Arguments to update or create a TriggerType.
     * @example
     * // Update or create a TriggerType
     * const triggerType = await prisma.triggerType.upsert({
     *   create: {
     *     // ... data to create a TriggerType
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the TriggerType we want to update
     *   }
     * })
     */
    upsert<T extends TriggerTypeUpsertArgs>(args: SelectSubset<T, TriggerTypeUpsertArgs<ExtArgs>>): Prisma__TriggerTypeClient<$Result.GetResult<Prisma.$TriggerTypePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of TriggerTypes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerTypeCountArgs} args - Arguments to filter TriggerTypes to count.
     * @example
     * // Count the number of TriggerTypes
     * const count = await prisma.triggerType.count({
     *   where: {
     *     // ... the filter for the TriggerTypes we want to count
     *   }
     * })
    **/
    count<T extends TriggerTypeCountArgs>(
      args?: Subset<T, TriggerTypeCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TriggerTypeCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a TriggerType.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerTypeAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TriggerTypeAggregateArgs>(args: Subset<T, TriggerTypeAggregateArgs>): Prisma.PrismaPromise<GetTriggerTypeAggregateType<T>>

    /**
     * Group by TriggerType.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TriggerTypeGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TriggerTypeGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TriggerTypeGroupByArgs['orderBy'] }
        : { orderBy?: TriggerTypeGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TriggerTypeGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTriggerTypeGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the TriggerType model
   */
  readonly fields: TriggerTypeFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for TriggerType.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TriggerTypeClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    triggr<T extends TriggerType$triggrArgs<ExtArgs> = {}>(args?: Subset<T, TriggerType$triggrArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TriggerPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the TriggerType model
   */
  interface TriggerTypeFieldRefs {
    readonly id: FieldRef<"TriggerType", 'String'>
    readonly name: FieldRef<"TriggerType", 'String'>
  }
    

  // Custom InputTypes
  /**
   * TriggerType findUnique
   */
  export type TriggerTypeFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TriggerType
     */
    select?: TriggerTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TriggerType
     */
    omit?: TriggerTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerTypeInclude<ExtArgs> | null
    /**
     * Filter, which TriggerType to fetch.
     */
    where: TriggerTypeWhereUniqueInput
  }

  /**
   * TriggerType findUniqueOrThrow
   */
  export type TriggerTypeFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TriggerType
     */
    select?: TriggerTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TriggerType
     */
    omit?: TriggerTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerTypeInclude<ExtArgs> | null
    /**
     * Filter, which TriggerType to fetch.
     */
    where: TriggerTypeWhereUniqueInput
  }

  /**
   * TriggerType findFirst
   */
  export type TriggerTypeFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TriggerType
     */
    select?: TriggerTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TriggerType
     */
    omit?: TriggerTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerTypeInclude<ExtArgs> | null
    /**
     * Filter, which TriggerType to fetch.
     */
    where?: TriggerTypeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TriggerTypes to fetch.
     */
    orderBy?: TriggerTypeOrderByWithRelationInput | TriggerTypeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TriggerTypes.
     */
    cursor?: TriggerTypeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TriggerTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TriggerTypes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TriggerTypes.
     */
    distinct?: TriggerTypeScalarFieldEnum | TriggerTypeScalarFieldEnum[]
  }

  /**
   * TriggerType findFirstOrThrow
   */
  export type TriggerTypeFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TriggerType
     */
    select?: TriggerTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TriggerType
     */
    omit?: TriggerTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerTypeInclude<ExtArgs> | null
    /**
     * Filter, which TriggerType to fetch.
     */
    where?: TriggerTypeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TriggerTypes to fetch.
     */
    orderBy?: TriggerTypeOrderByWithRelationInput | TriggerTypeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TriggerTypes.
     */
    cursor?: TriggerTypeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TriggerTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TriggerTypes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TriggerTypes.
     */
    distinct?: TriggerTypeScalarFieldEnum | TriggerTypeScalarFieldEnum[]
  }

  /**
   * TriggerType findMany
   */
  export type TriggerTypeFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TriggerType
     */
    select?: TriggerTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TriggerType
     */
    omit?: TriggerTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerTypeInclude<ExtArgs> | null
    /**
     * Filter, which TriggerTypes to fetch.
     */
    where?: TriggerTypeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TriggerTypes to fetch.
     */
    orderBy?: TriggerTypeOrderByWithRelationInput | TriggerTypeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing TriggerTypes.
     */
    cursor?: TriggerTypeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TriggerTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TriggerTypes.
     */
    skip?: number
    distinct?: TriggerTypeScalarFieldEnum | TriggerTypeScalarFieldEnum[]
  }

  /**
   * TriggerType create
   */
  export type TriggerTypeCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TriggerType
     */
    select?: TriggerTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TriggerType
     */
    omit?: TriggerTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerTypeInclude<ExtArgs> | null
    /**
     * The data needed to create a TriggerType.
     */
    data: XOR<TriggerTypeCreateInput, TriggerTypeUncheckedCreateInput>
  }

  /**
   * TriggerType createMany
   */
  export type TriggerTypeCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many TriggerTypes.
     */
    data: TriggerTypeCreateManyInput | TriggerTypeCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * TriggerType createManyAndReturn
   */
  export type TriggerTypeCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TriggerType
     */
    select?: TriggerTypeSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the TriggerType
     */
    omit?: TriggerTypeOmit<ExtArgs> | null
    /**
     * The data used to create many TriggerTypes.
     */
    data: TriggerTypeCreateManyInput | TriggerTypeCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * TriggerType update
   */
  export type TriggerTypeUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TriggerType
     */
    select?: TriggerTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TriggerType
     */
    omit?: TriggerTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerTypeInclude<ExtArgs> | null
    /**
     * The data needed to update a TriggerType.
     */
    data: XOR<TriggerTypeUpdateInput, TriggerTypeUncheckedUpdateInput>
    /**
     * Choose, which TriggerType to update.
     */
    where: TriggerTypeWhereUniqueInput
  }

  /**
   * TriggerType updateMany
   */
  export type TriggerTypeUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update TriggerTypes.
     */
    data: XOR<TriggerTypeUpdateManyMutationInput, TriggerTypeUncheckedUpdateManyInput>
    /**
     * Filter which TriggerTypes to update
     */
    where?: TriggerTypeWhereInput
    /**
     * Limit how many TriggerTypes to update.
     */
    limit?: number
  }

  /**
   * TriggerType updateManyAndReturn
   */
  export type TriggerTypeUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TriggerType
     */
    select?: TriggerTypeSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the TriggerType
     */
    omit?: TriggerTypeOmit<ExtArgs> | null
    /**
     * The data used to update TriggerTypes.
     */
    data: XOR<TriggerTypeUpdateManyMutationInput, TriggerTypeUncheckedUpdateManyInput>
    /**
     * Filter which TriggerTypes to update
     */
    where?: TriggerTypeWhereInput
    /**
     * Limit how many TriggerTypes to update.
     */
    limit?: number
  }

  /**
   * TriggerType upsert
   */
  export type TriggerTypeUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TriggerType
     */
    select?: TriggerTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TriggerType
     */
    omit?: TriggerTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerTypeInclude<ExtArgs> | null
    /**
     * The filter to search for the TriggerType to update in case it exists.
     */
    where: TriggerTypeWhereUniqueInput
    /**
     * In case the TriggerType found by the `where` argument doesn't exist, create a new TriggerType with this data.
     */
    create: XOR<TriggerTypeCreateInput, TriggerTypeUncheckedCreateInput>
    /**
     * In case the TriggerType was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TriggerTypeUpdateInput, TriggerTypeUncheckedUpdateInput>
  }

  /**
   * TriggerType delete
   */
  export type TriggerTypeDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TriggerType
     */
    select?: TriggerTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TriggerType
     */
    omit?: TriggerTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerTypeInclude<ExtArgs> | null
    /**
     * Filter which TriggerType to delete.
     */
    where: TriggerTypeWhereUniqueInput
  }

  /**
   * TriggerType deleteMany
   */
  export type TriggerTypeDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TriggerTypes to delete
     */
    where?: TriggerTypeWhereInput
    /**
     * Limit how many TriggerTypes to delete.
     */
    limit?: number
  }

  /**
   * TriggerType.triggr
   */
  export type TriggerType$triggrArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Trigger
     */
    select?: TriggerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Trigger
     */
    omit?: TriggerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerInclude<ExtArgs> | null
    where?: TriggerWhereInput
    orderBy?: TriggerOrderByWithRelationInput | TriggerOrderByWithRelationInput[]
    cursor?: TriggerWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TriggerScalarFieldEnum | TriggerScalarFieldEnum[]
  }

  /**
   * TriggerType without action
   */
  export type TriggerTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TriggerType
     */
    select?: TriggerTypeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TriggerType
     */
    omit?: TriggerTypeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TriggerTypeInclude<ExtArgs> | null
  }


  /**
   * Model ZapRun
   */

  export type AggregateZapRun = {
    _count: ZapRunCountAggregateOutputType | null
    _min: ZapRunMinAggregateOutputType | null
    _max: ZapRunMaxAggregateOutputType | null
  }

  export type ZapRunMinAggregateOutputType = {
    id: string | null
    zapId: string | null
  }

  export type ZapRunMaxAggregateOutputType = {
    id: string | null
    zapId: string | null
  }

  export type ZapRunCountAggregateOutputType = {
    id: number
    zapId: number
    meatdata: number
    _all: number
  }


  export type ZapRunMinAggregateInputType = {
    id?: true
    zapId?: true
  }

  export type ZapRunMaxAggregateInputType = {
    id?: true
    zapId?: true
  }

  export type ZapRunCountAggregateInputType = {
    id?: true
    zapId?: true
    meatdata?: true
    _all?: true
  }

  export type ZapRunAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ZapRun to aggregate.
     */
    where?: ZapRunWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ZapRuns to fetch.
     */
    orderBy?: ZapRunOrderByWithRelationInput | ZapRunOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ZapRunWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ZapRuns from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ZapRuns.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ZapRuns
    **/
    _count?: true | ZapRunCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ZapRunMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ZapRunMaxAggregateInputType
  }

  export type GetZapRunAggregateType<T extends ZapRunAggregateArgs> = {
        [P in keyof T & keyof AggregateZapRun]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateZapRun[P]>
      : GetScalarType<T[P], AggregateZapRun[P]>
  }




  export type ZapRunGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ZapRunWhereInput
    orderBy?: ZapRunOrderByWithAggregationInput | ZapRunOrderByWithAggregationInput[]
    by: ZapRunScalarFieldEnum[] | ZapRunScalarFieldEnum
    having?: ZapRunScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ZapRunCountAggregateInputType | true
    _min?: ZapRunMinAggregateInputType
    _max?: ZapRunMaxAggregateInputType
  }

  export type ZapRunGroupByOutputType = {
    id: string
    zapId: string
    meatdata: JsonValue
    _count: ZapRunCountAggregateOutputType | null
    _min: ZapRunMinAggregateOutputType | null
    _max: ZapRunMaxAggregateOutputType | null
  }

  type GetZapRunGroupByPayload<T extends ZapRunGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ZapRunGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ZapRunGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ZapRunGroupByOutputType[P]>
            : GetScalarType<T[P], ZapRunGroupByOutputType[P]>
        }
      >
    >


  export type ZapRunSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    zapId?: boolean
    meatdata?: boolean
    zap?: boolean | ZapDefaultArgs<ExtArgs>
    zaprunoutbox?: boolean | ZapRun$zaprunoutboxArgs<ExtArgs>
  }, ExtArgs["result"]["zapRun"]>

  export type ZapRunSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    zapId?: boolean
    meatdata?: boolean
    zap?: boolean | ZapDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["zapRun"]>

  export type ZapRunSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    zapId?: boolean
    meatdata?: boolean
    zap?: boolean | ZapDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["zapRun"]>

  export type ZapRunSelectScalar = {
    id?: boolean
    zapId?: boolean
    meatdata?: boolean
  }

  export type ZapRunOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "zapId" | "meatdata", ExtArgs["result"]["zapRun"]>
  export type ZapRunInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    zap?: boolean | ZapDefaultArgs<ExtArgs>
    zaprunoutbox?: boolean | ZapRun$zaprunoutboxArgs<ExtArgs>
  }
  export type ZapRunIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    zap?: boolean | ZapDefaultArgs<ExtArgs>
  }
  export type ZapRunIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    zap?: boolean | ZapDefaultArgs<ExtArgs>
  }

  export type $ZapRunPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ZapRun"
    objects: {
      zap: Prisma.$ZapPayload<ExtArgs>
      zaprunoutbox: Prisma.$ZapRunOutBoxPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      zapId: string
      meatdata: Prisma.JsonValue
    }, ExtArgs["result"]["zapRun"]>
    composites: {}
  }

  type ZapRunGetPayload<S extends boolean | null | undefined | ZapRunDefaultArgs> = $Result.GetResult<Prisma.$ZapRunPayload, S>

  type ZapRunCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ZapRunFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ZapRunCountAggregateInputType | true
    }

  export interface ZapRunDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ZapRun'], meta: { name: 'ZapRun' } }
    /**
     * Find zero or one ZapRun that matches the filter.
     * @param {ZapRunFindUniqueArgs} args - Arguments to find a ZapRun
     * @example
     * // Get one ZapRun
     * const zapRun = await prisma.zapRun.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ZapRunFindUniqueArgs>(args: SelectSubset<T, ZapRunFindUniqueArgs<ExtArgs>>): Prisma__ZapRunClient<$Result.GetResult<Prisma.$ZapRunPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one ZapRun that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ZapRunFindUniqueOrThrowArgs} args - Arguments to find a ZapRun
     * @example
     * // Get one ZapRun
     * const zapRun = await prisma.zapRun.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ZapRunFindUniqueOrThrowArgs>(args: SelectSubset<T, ZapRunFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ZapRunClient<$Result.GetResult<Prisma.$ZapRunPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ZapRun that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunFindFirstArgs} args - Arguments to find a ZapRun
     * @example
     * // Get one ZapRun
     * const zapRun = await prisma.zapRun.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ZapRunFindFirstArgs>(args?: SelectSubset<T, ZapRunFindFirstArgs<ExtArgs>>): Prisma__ZapRunClient<$Result.GetResult<Prisma.$ZapRunPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ZapRun that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunFindFirstOrThrowArgs} args - Arguments to find a ZapRun
     * @example
     * // Get one ZapRun
     * const zapRun = await prisma.zapRun.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ZapRunFindFirstOrThrowArgs>(args?: SelectSubset<T, ZapRunFindFirstOrThrowArgs<ExtArgs>>): Prisma__ZapRunClient<$Result.GetResult<Prisma.$ZapRunPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more ZapRuns that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ZapRuns
     * const zapRuns = await prisma.zapRun.findMany()
     * 
     * // Get first 10 ZapRuns
     * const zapRuns = await prisma.zapRun.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const zapRunWithIdOnly = await prisma.zapRun.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ZapRunFindManyArgs>(args?: SelectSubset<T, ZapRunFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ZapRunPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a ZapRun.
     * @param {ZapRunCreateArgs} args - Arguments to create a ZapRun.
     * @example
     * // Create one ZapRun
     * const ZapRun = await prisma.zapRun.create({
     *   data: {
     *     // ... data to create a ZapRun
     *   }
     * })
     * 
     */
    create<T extends ZapRunCreateArgs>(args: SelectSubset<T, ZapRunCreateArgs<ExtArgs>>): Prisma__ZapRunClient<$Result.GetResult<Prisma.$ZapRunPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many ZapRuns.
     * @param {ZapRunCreateManyArgs} args - Arguments to create many ZapRuns.
     * @example
     * // Create many ZapRuns
     * const zapRun = await prisma.zapRun.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ZapRunCreateManyArgs>(args?: SelectSubset<T, ZapRunCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many ZapRuns and returns the data saved in the database.
     * @param {ZapRunCreateManyAndReturnArgs} args - Arguments to create many ZapRuns.
     * @example
     * // Create many ZapRuns
     * const zapRun = await prisma.zapRun.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many ZapRuns and only return the `id`
     * const zapRunWithIdOnly = await prisma.zapRun.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ZapRunCreateManyAndReturnArgs>(args?: SelectSubset<T, ZapRunCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ZapRunPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a ZapRun.
     * @param {ZapRunDeleteArgs} args - Arguments to delete one ZapRun.
     * @example
     * // Delete one ZapRun
     * const ZapRun = await prisma.zapRun.delete({
     *   where: {
     *     // ... filter to delete one ZapRun
     *   }
     * })
     * 
     */
    delete<T extends ZapRunDeleteArgs>(args: SelectSubset<T, ZapRunDeleteArgs<ExtArgs>>): Prisma__ZapRunClient<$Result.GetResult<Prisma.$ZapRunPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one ZapRun.
     * @param {ZapRunUpdateArgs} args - Arguments to update one ZapRun.
     * @example
     * // Update one ZapRun
     * const zapRun = await prisma.zapRun.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ZapRunUpdateArgs>(args: SelectSubset<T, ZapRunUpdateArgs<ExtArgs>>): Prisma__ZapRunClient<$Result.GetResult<Prisma.$ZapRunPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more ZapRuns.
     * @param {ZapRunDeleteManyArgs} args - Arguments to filter ZapRuns to delete.
     * @example
     * // Delete a few ZapRuns
     * const { count } = await prisma.zapRun.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ZapRunDeleteManyArgs>(args?: SelectSubset<T, ZapRunDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ZapRuns.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ZapRuns
     * const zapRun = await prisma.zapRun.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ZapRunUpdateManyArgs>(args: SelectSubset<T, ZapRunUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ZapRuns and returns the data updated in the database.
     * @param {ZapRunUpdateManyAndReturnArgs} args - Arguments to update many ZapRuns.
     * @example
     * // Update many ZapRuns
     * const zapRun = await prisma.zapRun.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more ZapRuns and only return the `id`
     * const zapRunWithIdOnly = await prisma.zapRun.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ZapRunUpdateManyAndReturnArgs>(args: SelectSubset<T, ZapRunUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ZapRunPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one ZapRun.
     * @param {ZapRunUpsertArgs} args - Arguments to update or create a ZapRun.
     * @example
     * // Update or create a ZapRun
     * const zapRun = await prisma.zapRun.upsert({
     *   create: {
     *     // ... data to create a ZapRun
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ZapRun we want to update
     *   }
     * })
     */
    upsert<T extends ZapRunUpsertArgs>(args: SelectSubset<T, ZapRunUpsertArgs<ExtArgs>>): Prisma__ZapRunClient<$Result.GetResult<Prisma.$ZapRunPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of ZapRuns.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunCountArgs} args - Arguments to filter ZapRuns to count.
     * @example
     * // Count the number of ZapRuns
     * const count = await prisma.zapRun.count({
     *   where: {
     *     // ... the filter for the ZapRuns we want to count
     *   }
     * })
    **/
    count<T extends ZapRunCountArgs>(
      args?: Subset<T, ZapRunCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ZapRunCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ZapRun.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ZapRunAggregateArgs>(args: Subset<T, ZapRunAggregateArgs>): Prisma.PrismaPromise<GetZapRunAggregateType<T>>

    /**
     * Group by ZapRun.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ZapRunGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ZapRunGroupByArgs['orderBy'] }
        : { orderBy?: ZapRunGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ZapRunGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetZapRunGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ZapRun model
   */
  readonly fields: ZapRunFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ZapRun.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ZapRunClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    zap<T extends ZapDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ZapDefaultArgs<ExtArgs>>): Prisma__ZapClient<$Result.GetResult<Prisma.$ZapPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    zaprunoutbox<T extends ZapRun$zaprunoutboxArgs<ExtArgs> = {}>(args?: Subset<T, ZapRun$zaprunoutboxArgs<ExtArgs>>): Prisma__ZapRunOutBoxClient<$Result.GetResult<Prisma.$ZapRunOutBoxPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the ZapRun model
   */
  interface ZapRunFieldRefs {
    readonly id: FieldRef<"ZapRun", 'String'>
    readonly zapId: FieldRef<"ZapRun", 'String'>
    readonly meatdata: FieldRef<"ZapRun", 'Json'>
  }
    

  // Custom InputTypes
  /**
   * ZapRun findUnique
   */
  export type ZapRunFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRun
     */
    select?: ZapRunSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRun
     */
    omit?: ZapRunOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunInclude<ExtArgs> | null
    /**
     * Filter, which ZapRun to fetch.
     */
    where: ZapRunWhereUniqueInput
  }

  /**
   * ZapRun findUniqueOrThrow
   */
  export type ZapRunFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRun
     */
    select?: ZapRunSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRun
     */
    omit?: ZapRunOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunInclude<ExtArgs> | null
    /**
     * Filter, which ZapRun to fetch.
     */
    where: ZapRunWhereUniqueInput
  }

  /**
   * ZapRun findFirst
   */
  export type ZapRunFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRun
     */
    select?: ZapRunSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRun
     */
    omit?: ZapRunOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunInclude<ExtArgs> | null
    /**
     * Filter, which ZapRun to fetch.
     */
    where?: ZapRunWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ZapRuns to fetch.
     */
    orderBy?: ZapRunOrderByWithRelationInput | ZapRunOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ZapRuns.
     */
    cursor?: ZapRunWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ZapRuns from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ZapRuns.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ZapRuns.
     */
    distinct?: ZapRunScalarFieldEnum | ZapRunScalarFieldEnum[]
  }

  /**
   * ZapRun findFirstOrThrow
   */
  export type ZapRunFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRun
     */
    select?: ZapRunSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRun
     */
    omit?: ZapRunOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunInclude<ExtArgs> | null
    /**
     * Filter, which ZapRun to fetch.
     */
    where?: ZapRunWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ZapRuns to fetch.
     */
    orderBy?: ZapRunOrderByWithRelationInput | ZapRunOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ZapRuns.
     */
    cursor?: ZapRunWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ZapRuns from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ZapRuns.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ZapRuns.
     */
    distinct?: ZapRunScalarFieldEnum | ZapRunScalarFieldEnum[]
  }

  /**
   * ZapRun findMany
   */
  export type ZapRunFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRun
     */
    select?: ZapRunSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRun
     */
    omit?: ZapRunOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunInclude<ExtArgs> | null
    /**
     * Filter, which ZapRuns to fetch.
     */
    where?: ZapRunWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ZapRuns to fetch.
     */
    orderBy?: ZapRunOrderByWithRelationInput | ZapRunOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ZapRuns.
     */
    cursor?: ZapRunWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ZapRuns from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ZapRuns.
     */
    skip?: number
    distinct?: ZapRunScalarFieldEnum | ZapRunScalarFieldEnum[]
  }

  /**
   * ZapRun create
   */
  export type ZapRunCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRun
     */
    select?: ZapRunSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRun
     */
    omit?: ZapRunOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunInclude<ExtArgs> | null
    /**
     * The data needed to create a ZapRun.
     */
    data: XOR<ZapRunCreateInput, ZapRunUncheckedCreateInput>
  }

  /**
   * ZapRun createMany
   */
  export type ZapRunCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ZapRuns.
     */
    data: ZapRunCreateManyInput | ZapRunCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * ZapRun createManyAndReturn
   */
  export type ZapRunCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRun
     */
    select?: ZapRunSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRun
     */
    omit?: ZapRunOmit<ExtArgs> | null
    /**
     * The data used to create many ZapRuns.
     */
    data: ZapRunCreateManyInput | ZapRunCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * ZapRun update
   */
  export type ZapRunUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRun
     */
    select?: ZapRunSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRun
     */
    omit?: ZapRunOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunInclude<ExtArgs> | null
    /**
     * The data needed to update a ZapRun.
     */
    data: XOR<ZapRunUpdateInput, ZapRunUncheckedUpdateInput>
    /**
     * Choose, which ZapRun to update.
     */
    where: ZapRunWhereUniqueInput
  }

  /**
   * ZapRun updateMany
   */
  export type ZapRunUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ZapRuns.
     */
    data: XOR<ZapRunUpdateManyMutationInput, ZapRunUncheckedUpdateManyInput>
    /**
     * Filter which ZapRuns to update
     */
    where?: ZapRunWhereInput
    /**
     * Limit how many ZapRuns to update.
     */
    limit?: number
  }

  /**
   * ZapRun updateManyAndReturn
   */
  export type ZapRunUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRun
     */
    select?: ZapRunSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRun
     */
    omit?: ZapRunOmit<ExtArgs> | null
    /**
     * The data used to update ZapRuns.
     */
    data: XOR<ZapRunUpdateManyMutationInput, ZapRunUncheckedUpdateManyInput>
    /**
     * Filter which ZapRuns to update
     */
    where?: ZapRunWhereInput
    /**
     * Limit how many ZapRuns to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * ZapRun upsert
   */
  export type ZapRunUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRun
     */
    select?: ZapRunSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRun
     */
    omit?: ZapRunOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunInclude<ExtArgs> | null
    /**
     * The filter to search for the ZapRun to update in case it exists.
     */
    where: ZapRunWhereUniqueInput
    /**
     * In case the ZapRun found by the `where` argument doesn't exist, create a new ZapRun with this data.
     */
    create: XOR<ZapRunCreateInput, ZapRunUncheckedCreateInput>
    /**
     * In case the ZapRun was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ZapRunUpdateInput, ZapRunUncheckedUpdateInput>
  }

  /**
   * ZapRun delete
   */
  export type ZapRunDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRun
     */
    select?: ZapRunSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRun
     */
    omit?: ZapRunOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunInclude<ExtArgs> | null
    /**
     * Filter which ZapRun to delete.
     */
    where: ZapRunWhereUniqueInput
  }

  /**
   * ZapRun deleteMany
   */
  export type ZapRunDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ZapRuns to delete
     */
    where?: ZapRunWhereInput
    /**
     * Limit how many ZapRuns to delete.
     */
    limit?: number
  }

  /**
   * ZapRun.zaprunoutbox
   */
  export type ZapRun$zaprunoutboxArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRunOutBox
     */
    select?: ZapRunOutBoxSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRunOutBox
     */
    omit?: ZapRunOutBoxOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunOutBoxInclude<ExtArgs> | null
    where?: ZapRunOutBoxWhereInput
  }

  /**
   * ZapRun without action
   */
  export type ZapRunDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRun
     */
    select?: ZapRunSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRun
     */
    omit?: ZapRunOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunInclude<ExtArgs> | null
  }


  /**
   * Model ZapRunOutBox
   */

  export type AggregateZapRunOutBox = {
    _count: ZapRunOutBoxCountAggregateOutputType | null
    _min: ZapRunOutBoxMinAggregateOutputType | null
    _max: ZapRunOutBoxMaxAggregateOutputType | null
  }

  export type ZapRunOutBoxMinAggregateOutputType = {
    id: string | null
    zaprunid: string | null
  }

  export type ZapRunOutBoxMaxAggregateOutputType = {
    id: string | null
    zaprunid: string | null
  }

  export type ZapRunOutBoxCountAggregateOutputType = {
    id: number
    zaprunid: number
    _all: number
  }


  export type ZapRunOutBoxMinAggregateInputType = {
    id?: true
    zaprunid?: true
  }

  export type ZapRunOutBoxMaxAggregateInputType = {
    id?: true
    zaprunid?: true
  }

  export type ZapRunOutBoxCountAggregateInputType = {
    id?: true
    zaprunid?: true
    _all?: true
  }

  export type ZapRunOutBoxAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ZapRunOutBox to aggregate.
     */
    where?: ZapRunOutBoxWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ZapRunOutBoxes to fetch.
     */
    orderBy?: ZapRunOutBoxOrderByWithRelationInput | ZapRunOutBoxOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ZapRunOutBoxWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ZapRunOutBoxes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ZapRunOutBoxes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ZapRunOutBoxes
    **/
    _count?: true | ZapRunOutBoxCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ZapRunOutBoxMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ZapRunOutBoxMaxAggregateInputType
  }

  export type GetZapRunOutBoxAggregateType<T extends ZapRunOutBoxAggregateArgs> = {
        [P in keyof T & keyof AggregateZapRunOutBox]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateZapRunOutBox[P]>
      : GetScalarType<T[P], AggregateZapRunOutBox[P]>
  }




  export type ZapRunOutBoxGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ZapRunOutBoxWhereInput
    orderBy?: ZapRunOutBoxOrderByWithAggregationInput | ZapRunOutBoxOrderByWithAggregationInput[]
    by: ZapRunOutBoxScalarFieldEnum[] | ZapRunOutBoxScalarFieldEnum
    having?: ZapRunOutBoxScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ZapRunOutBoxCountAggregateInputType | true
    _min?: ZapRunOutBoxMinAggregateInputType
    _max?: ZapRunOutBoxMaxAggregateInputType
  }

  export type ZapRunOutBoxGroupByOutputType = {
    id: string
    zaprunid: string
    _count: ZapRunOutBoxCountAggregateOutputType | null
    _min: ZapRunOutBoxMinAggregateOutputType | null
    _max: ZapRunOutBoxMaxAggregateOutputType | null
  }

  type GetZapRunOutBoxGroupByPayload<T extends ZapRunOutBoxGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ZapRunOutBoxGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ZapRunOutBoxGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ZapRunOutBoxGroupByOutputType[P]>
            : GetScalarType<T[P], ZapRunOutBoxGroupByOutputType[P]>
        }
      >
    >


  export type ZapRunOutBoxSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    zaprunid?: boolean
    zaprun?: boolean | ZapRunDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["zapRunOutBox"]>

  export type ZapRunOutBoxSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    zaprunid?: boolean
    zaprun?: boolean | ZapRunDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["zapRunOutBox"]>

  export type ZapRunOutBoxSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    zaprunid?: boolean
    zaprun?: boolean | ZapRunDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["zapRunOutBox"]>

  export type ZapRunOutBoxSelectScalar = {
    id?: boolean
    zaprunid?: boolean
  }

  export type ZapRunOutBoxOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "zaprunid", ExtArgs["result"]["zapRunOutBox"]>
  export type ZapRunOutBoxInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    zaprun?: boolean | ZapRunDefaultArgs<ExtArgs>
  }
  export type ZapRunOutBoxIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    zaprun?: boolean | ZapRunDefaultArgs<ExtArgs>
  }
  export type ZapRunOutBoxIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    zaprun?: boolean | ZapRunDefaultArgs<ExtArgs>
  }

  export type $ZapRunOutBoxPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ZapRunOutBox"
    objects: {
      zaprun: Prisma.$ZapRunPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      zaprunid: string
    }, ExtArgs["result"]["zapRunOutBox"]>
    composites: {}
  }

  type ZapRunOutBoxGetPayload<S extends boolean | null | undefined | ZapRunOutBoxDefaultArgs> = $Result.GetResult<Prisma.$ZapRunOutBoxPayload, S>

  type ZapRunOutBoxCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ZapRunOutBoxFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ZapRunOutBoxCountAggregateInputType | true
    }

  export interface ZapRunOutBoxDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ZapRunOutBox'], meta: { name: 'ZapRunOutBox' } }
    /**
     * Find zero or one ZapRunOutBox that matches the filter.
     * @param {ZapRunOutBoxFindUniqueArgs} args - Arguments to find a ZapRunOutBox
     * @example
     * // Get one ZapRunOutBox
     * const zapRunOutBox = await prisma.zapRunOutBox.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ZapRunOutBoxFindUniqueArgs>(args: SelectSubset<T, ZapRunOutBoxFindUniqueArgs<ExtArgs>>): Prisma__ZapRunOutBoxClient<$Result.GetResult<Prisma.$ZapRunOutBoxPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one ZapRunOutBox that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ZapRunOutBoxFindUniqueOrThrowArgs} args - Arguments to find a ZapRunOutBox
     * @example
     * // Get one ZapRunOutBox
     * const zapRunOutBox = await prisma.zapRunOutBox.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ZapRunOutBoxFindUniqueOrThrowArgs>(args: SelectSubset<T, ZapRunOutBoxFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ZapRunOutBoxClient<$Result.GetResult<Prisma.$ZapRunOutBoxPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ZapRunOutBox that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunOutBoxFindFirstArgs} args - Arguments to find a ZapRunOutBox
     * @example
     * // Get one ZapRunOutBox
     * const zapRunOutBox = await prisma.zapRunOutBox.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ZapRunOutBoxFindFirstArgs>(args?: SelectSubset<T, ZapRunOutBoxFindFirstArgs<ExtArgs>>): Prisma__ZapRunOutBoxClient<$Result.GetResult<Prisma.$ZapRunOutBoxPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ZapRunOutBox that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunOutBoxFindFirstOrThrowArgs} args - Arguments to find a ZapRunOutBox
     * @example
     * // Get one ZapRunOutBox
     * const zapRunOutBox = await prisma.zapRunOutBox.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ZapRunOutBoxFindFirstOrThrowArgs>(args?: SelectSubset<T, ZapRunOutBoxFindFirstOrThrowArgs<ExtArgs>>): Prisma__ZapRunOutBoxClient<$Result.GetResult<Prisma.$ZapRunOutBoxPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more ZapRunOutBoxes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunOutBoxFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ZapRunOutBoxes
     * const zapRunOutBoxes = await prisma.zapRunOutBox.findMany()
     * 
     * // Get first 10 ZapRunOutBoxes
     * const zapRunOutBoxes = await prisma.zapRunOutBox.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const zapRunOutBoxWithIdOnly = await prisma.zapRunOutBox.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ZapRunOutBoxFindManyArgs>(args?: SelectSubset<T, ZapRunOutBoxFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ZapRunOutBoxPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a ZapRunOutBox.
     * @param {ZapRunOutBoxCreateArgs} args - Arguments to create a ZapRunOutBox.
     * @example
     * // Create one ZapRunOutBox
     * const ZapRunOutBox = await prisma.zapRunOutBox.create({
     *   data: {
     *     // ... data to create a ZapRunOutBox
     *   }
     * })
     * 
     */
    create<T extends ZapRunOutBoxCreateArgs>(args: SelectSubset<T, ZapRunOutBoxCreateArgs<ExtArgs>>): Prisma__ZapRunOutBoxClient<$Result.GetResult<Prisma.$ZapRunOutBoxPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many ZapRunOutBoxes.
     * @param {ZapRunOutBoxCreateManyArgs} args - Arguments to create many ZapRunOutBoxes.
     * @example
     * // Create many ZapRunOutBoxes
     * const zapRunOutBox = await prisma.zapRunOutBox.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ZapRunOutBoxCreateManyArgs>(args?: SelectSubset<T, ZapRunOutBoxCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many ZapRunOutBoxes and returns the data saved in the database.
     * @param {ZapRunOutBoxCreateManyAndReturnArgs} args - Arguments to create many ZapRunOutBoxes.
     * @example
     * // Create many ZapRunOutBoxes
     * const zapRunOutBox = await prisma.zapRunOutBox.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many ZapRunOutBoxes and only return the `id`
     * const zapRunOutBoxWithIdOnly = await prisma.zapRunOutBox.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ZapRunOutBoxCreateManyAndReturnArgs>(args?: SelectSubset<T, ZapRunOutBoxCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ZapRunOutBoxPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a ZapRunOutBox.
     * @param {ZapRunOutBoxDeleteArgs} args - Arguments to delete one ZapRunOutBox.
     * @example
     * // Delete one ZapRunOutBox
     * const ZapRunOutBox = await prisma.zapRunOutBox.delete({
     *   where: {
     *     // ... filter to delete one ZapRunOutBox
     *   }
     * })
     * 
     */
    delete<T extends ZapRunOutBoxDeleteArgs>(args: SelectSubset<T, ZapRunOutBoxDeleteArgs<ExtArgs>>): Prisma__ZapRunOutBoxClient<$Result.GetResult<Prisma.$ZapRunOutBoxPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one ZapRunOutBox.
     * @param {ZapRunOutBoxUpdateArgs} args - Arguments to update one ZapRunOutBox.
     * @example
     * // Update one ZapRunOutBox
     * const zapRunOutBox = await prisma.zapRunOutBox.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ZapRunOutBoxUpdateArgs>(args: SelectSubset<T, ZapRunOutBoxUpdateArgs<ExtArgs>>): Prisma__ZapRunOutBoxClient<$Result.GetResult<Prisma.$ZapRunOutBoxPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more ZapRunOutBoxes.
     * @param {ZapRunOutBoxDeleteManyArgs} args - Arguments to filter ZapRunOutBoxes to delete.
     * @example
     * // Delete a few ZapRunOutBoxes
     * const { count } = await prisma.zapRunOutBox.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ZapRunOutBoxDeleteManyArgs>(args?: SelectSubset<T, ZapRunOutBoxDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ZapRunOutBoxes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunOutBoxUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ZapRunOutBoxes
     * const zapRunOutBox = await prisma.zapRunOutBox.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ZapRunOutBoxUpdateManyArgs>(args: SelectSubset<T, ZapRunOutBoxUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ZapRunOutBoxes and returns the data updated in the database.
     * @param {ZapRunOutBoxUpdateManyAndReturnArgs} args - Arguments to update many ZapRunOutBoxes.
     * @example
     * // Update many ZapRunOutBoxes
     * const zapRunOutBox = await prisma.zapRunOutBox.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more ZapRunOutBoxes and only return the `id`
     * const zapRunOutBoxWithIdOnly = await prisma.zapRunOutBox.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ZapRunOutBoxUpdateManyAndReturnArgs>(args: SelectSubset<T, ZapRunOutBoxUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ZapRunOutBoxPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one ZapRunOutBox.
     * @param {ZapRunOutBoxUpsertArgs} args - Arguments to update or create a ZapRunOutBox.
     * @example
     * // Update or create a ZapRunOutBox
     * const zapRunOutBox = await prisma.zapRunOutBox.upsert({
     *   create: {
     *     // ... data to create a ZapRunOutBox
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ZapRunOutBox we want to update
     *   }
     * })
     */
    upsert<T extends ZapRunOutBoxUpsertArgs>(args: SelectSubset<T, ZapRunOutBoxUpsertArgs<ExtArgs>>): Prisma__ZapRunOutBoxClient<$Result.GetResult<Prisma.$ZapRunOutBoxPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of ZapRunOutBoxes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunOutBoxCountArgs} args - Arguments to filter ZapRunOutBoxes to count.
     * @example
     * // Count the number of ZapRunOutBoxes
     * const count = await prisma.zapRunOutBox.count({
     *   where: {
     *     // ... the filter for the ZapRunOutBoxes we want to count
     *   }
     * })
    **/
    count<T extends ZapRunOutBoxCountArgs>(
      args?: Subset<T, ZapRunOutBoxCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ZapRunOutBoxCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ZapRunOutBox.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunOutBoxAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ZapRunOutBoxAggregateArgs>(args: Subset<T, ZapRunOutBoxAggregateArgs>): Prisma.PrismaPromise<GetZapRunOutBoxAggregateType<T>>

    /**
     * Group by ZapRunOutBox.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ZapRunOutBoxGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ZapRunOutBoxGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ZapRunOutBoxGroupByArgs['orderBy'] }
        : { orderBy?: ZapRunOutBoxGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ZapRunOutBoxGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetZapRunOutBoxGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ZapRunOutBox model
   */
  readonly fields: ZapRunOutBoxFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ZapRunOutBox.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ZapRunOutBoxClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    zaprun<T extends ZapRunDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ZapRunDefaultArgs<ExtArgs>>): Prisma__ZapRunClient<$Result.GetResult<Prisma.$ZapRunPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the ZapRunOutBox model
   */
  interface ZapRunOutBoxFieldRefs {
    readonly id: FieldRef<"ZapRunOutBox", 'String'>
    readonly zaprunid: FieldRef<"ZapRunOutBox", 'String'>
  }
    

  // Custom InputTypes
  /**
   * ZapRunOutBox findUnique
   */
  export type ZapRunOutBoxFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRunOutBox
     */
    select?: ZapRunOutBoxSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRunOutBox
     */
    omit?: ZapRunOutBoxOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunOutBoxInclude<ExtArgs> | null
    /**
     * Filter, which ZapRunOutBox to fetch.
     */
    where: ZapRunOutBoxWhereUniqueInput
  }

  /**
   * ZapRunOutBox findUniqueOrThrow
   */
  export type ZapRunOutBoxFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRunOutBox
     */
    select?: ZapRunOutBoxSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRunOutBox
     */
    omit?: ZapRunOutBoxOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunOutBoxInclude<ExtArgs> | null
    /**
     * Filter, which ZapRunOutBox to fetch.
     */
    where: ZapRunOutBoxWhereUniqueInput
  }

  /**
   * ZapRunOutBox findFirst
   */
  export type ZapRunOutBoxFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRunOutBox
     */
    select?: ZapRunOutBoxSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRunOutBox
     */
    omit?: ZapRunOutBoxOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunOutBoxInclude<ExtArgs> | null
    /**
     * Filter, which ZapRunOutBox to fetch.
     */
    where?: ZapRunOutBoxWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ZapRunOutBoxes to fetch.
     */
    orderBy?: ZapRunOutBoxOrderByWithRelationInput | ZapRunOutBoxOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ZapRunOutBoxes.
     */
    cursor?: ZapRunOutBoxWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ZapRunOutBoxes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ZapRunOutBoxes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ZapRunOutBoxes.
     */
    distinct?: ZapRunOutBoxScalarFieldEnum | ZapRunOutBoxScalarFieldEnum[]
  }

  /**
   * ZapRunOutBox findFirstOrThrow
   */
  export type ZapRunOutBoxFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRunOutBox
     */
    select?: ZapRunOutBoxSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRunOutBox
     */
    omit?: ZapRunOutBoxOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunOutBoxInclude<ExtArgs> | null
    /**
     * Filter, which ZapRunOutBox to fetch.
     */
    where?: ZapRunOutBoxWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ZapRunOutBoxes to fetch.
     */
    orderBy?: ZapRunOutBoxOrderByWithRelationInput | ZapRunOutBoxOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ZapRunOutBoxes.
     */
    cursor?: ZapRunOutBoxWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ZapRunOutBoxes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ZapRunOutBoxes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ZapRunOutBoxes.
     */
    distinct?: ZapRunOutBoxScalarFieldEnum | ZapRunOutBoxScalarFieldEnum[]
  }

  /**
   * ZapRunOutBox findMany
   */
  export type ZapRunOutBoxFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRunOutBox
     */
    select?: ZapRunOutBoxSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRunOutBox
     */
    omit?: ZapRunOutBoxOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunOutBoxInclude<ExtArgs> | null
    /**
     * Filter, which ZapRunOutBoxes to fetch.
     */
    where?: ZapRunOutBoxWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ZapRunOutBoxes to fetch.
     */
    orderBy?: ZapRunOutBoxOrderByWithRelationInput | ZapRunOutBoxOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ZapRunOutBoxes.
     */
    cursor?: ZapRunOutBoxWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ZapRunOutBoxes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ZapRunOutBoxes.
     */
    skip?: number
    distinct?: ZapRunOutBoxScalarFieldEnum | ZapRunOutBoxScalarFieldEnum[]
  }

  /**
   * ZapRunOutBox create
   */
  export type ZapRunOutBoxCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRunOutBox
     */
    select?: ZapRunOutBoxSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRunOutBox
     */
    omit?: ZapRunOutBoxOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunOutBoxInclude<ExtArgs> | null
    /**
     * The data needed to create a ZapRunOutBox.
     */
    data: XOR<ZapRunOutBoxCreateInput, ZapRunOutBoxUncheckedCreateInput>
  }

  /**
   * ZapRunOutBox createMany
   */
  export type ZapRunOutBoxCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ZapRunOutBoxes.
     */
    data: ZapRunOutBoxCreateManyInput | ZapRunOutBoxCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * ZapRunOutBox createManyAndReturn
   */
  export type ZapRunOutBoxCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRunOutBox
     */
    select?: ZapRunOutBoxSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRunOutBox
     */
    omit?: ZapRunOutBoxOmit<ExtArgs> | null
    /**
     * The data used to create many ZapRunOutBoxes.
     */
    data: ZapRunOutBoxCreateManyInput | ZapRunOutBoxCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunOutBoxIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * ZapRunOutBox update
   */
  export type ZapRunOutBoxUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRunOutBox
     */
    select?: ZapRunOutBoxSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRunOutBox
     */
    omit?: ZapRunOutBoxOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunOutBoxInclude<ExtArgs> | null
    /**
     * The data needed to update a ZapRunOutBox.
     */
    data: XOR<ZapRunOutBoxUpdateInput, ZapRunOutBoxUncheckedUpdateInput>
    /**
     * Choose, which ZapRunOutBox to update.
     */
    where: ZapRunOutBoxWhereUniqueInput
  }

  /**
   * ZapRunOutBox updateMany
   */
  export type ZapRunOutBoxUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ZapRunOutBoxes.
     */
    data: XOR<ZapRunOutBoxUpdateManyMutationInput, ZapRunOutBoxUncheckedUpdateManyInput>
    /**
     * Filter which ZapRunOutBoxes to update
     */
    where?: ZapRunOutBoxWhereInput
    /**
     * Limit how many ZapRunOutBoxes to update.
     */
    limit?: number
  }

  /**
   * ZapRunOutBox updateManyAndReturn
   */
  export type ZapRunOutBoxUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRunOutBox
     */
    select?: ZapRunOutBoxSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRunOutBox
     */
    omit?: ZapRunOutBoxOmit<ExtArgs> | null
    /**
     * The data used to update ZapRunOutBoxes.
     */
    data: XOR<ZapRunOutBoxUpdateManyMutationInput, ZapRunOutBoxUncheckedUpdateManyInput>
    /**
     * Filter which ZapRunOutBoxes to update
     */
    where?: ZapRunOutBoxWhereInput
    /**
     * Limit how many ZapRunOutBoxes to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunOutBoxIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * ZapRunOutBox upsert
   */
  export type ZapRunOutBoxUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRunOutBox
     */
    select?: ZapRunOutBoxSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRunOutBox
     */
    omit?: ZapRunOutBoxOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunOutBoxInclude<ExtArgs> | null
    /**
     * The filter to search for the ZapRunOutBox to update in case it exists.
     */
    where: ZapRunOutBoxWhereUniqueInput
    /**
     * In case the ZapRunOutBox found by the `where` argument doesn't exist, create a new ZapRunOutBox with this data.
     */
    create: XOR<ZapRunOutBoxCreateInput, ZapRunOutBoxUncheckedCreateInput>
    /**
     * In case the ZapRunOutBox was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ZapRunOutBoxUpdateInput, ZapRunOutBoxUncheckedUpdateInput>
  }

  /**
   * ZapRunOutBox delete
   */
  export type ZapRunOutBoxDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRunOutBox
     */
    select?: ZapRunOutBoxSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRunOutBox
     */
    omit?: ZapRunOutBoxOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunOutBoxInclude<ExtArgs> | null
    /**
     * Filter which ZapRunOutBox to delete.
     */
    where: ZapRunOutBoxWhereUniqueInput
  }

  /**
   * ZapRunOutBox deleteMany
   */
  export type ZapRunOutBoxDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ZapRunOutBoxes to delete
     */
    where?: ZapRunOutBoxWhereInput
    /**
     * Limit how many ZapRunOutBoxes to delete.
     */
    limit?: number
  }

  /**
   * ZapRunOutBox without action
   */
  export type ZapRunOutBoxDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ZapRunOutBox
     */
    select?: ZapRunOutBoxSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ZapRunOutBox
     */
    omit?: ZapRunOutBoxOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ZapRunOutBoxInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UserScalarFieldEnum: {
    id: 'id',
    email: 'email',
    name: 'name',
    password: 'password'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const ZapScalarFieldEnum: {
    id: 'id'
  };

  export type ZapScalarFieldEnum = (typeof ZapScalarFieldEnum)[keyof typeof ZapScalarFieldEnum]


  export const TriggerScalarFieldEnum: {
    id: 'id',
    ZapID: 'ZapID',
    tiggerID: 'tiggerID'
  };

  export type TriggerScalarFieldEnum = (typeof TriggerScalarFieldEnum)[keyof typeof TriggerScalarFieldEnum]


  export const ActionsScalarFieldEnum: {
    id: 'id',
    ZapID: 'ZapID',
    actionID: 'actionID'
  };

  export type ActionsScalarFieldEnum = (typeof ActionsScalarFieldEnum)[keyof typeof ActionsScalarFieldEnum]


  export const AvalibleActionsScalarFieldEnum: {
    id: 'id',
    name: 'name'
  };

  export type AvalibleActionsScalarFieldEnum = (typeof AvalibleActionsScalarFieldEnum)[keyof typeof AvalibleActionsScalarFieldEnum]


  export const TriggerTypeScalarFieldEnum: {
    id: 'id',
    name: 'name'
  };

  export type TriggerTypeScalarFieldEnum = (typeof TriggerTypeScalarFieldEnum)[keyof typeof TriggerTypeScalarFieldEnum]


  export const ZapRunScalarFieldEnum: {
    id: 'id',
    zapId: 'zapId',
    meatdata: 'meatdata'
  };

  export type ZapRunScalarFieldEnum = (typeof ZapRunScalarFieldEnum)[keyof typeof ZapRunScalarFieldEnum]


  export const ZapRunOutBoxScalarFieldEnum: {
    id: 'id',
    zaprunid: 'zaprunid'
  };

  export type ZapRunOutBoxScalarFieldEnum = (typeof ZapRunOutBoxScalarFieldEnum)[keyof typeof ZapRunOutBoxScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const JsonNullValueInput: {
    JsonNull: typeof JsonNull
  };

  export type JsonNullValueInput = (typeof JsonNullValueInput)[keyof typeof JsonNullValueInput]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const JsonNullValueFilter: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull,
    AnyNull: typeof AnyNull
  };

  export type JsonNullValueFilter = (typeof JsonNullValueFilter)[keyof typeof JsonNullValueFilter]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'Json'
   */
  export type JsonFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Json'>
    


  /**
   * Reference to a field of type 'QueryMode'
   */
  export type EnumQueryModeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'QueryMode'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    id?: IntFilter<"User"> | number
    email?: StringFilter<"User"> | string
    name?: StringFilter<"User"> | string
    password?: StringFilter<"User"> | string
  }

  export type UserOrderByWithRelationInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    password?: SortOrder
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    email?: string
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    name?: StringFilter<"User"> | string
    password?: StringFilter<"User"> | string
  }, "id" | "email">

  export type UserOrderByWithAggregationInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    password?: SortOrder
    _count?: UserCountOrderByAggregateInput
    _avg?: UserAvgOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
    _sum?: UserSumOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"User"> | number
    email?: StringWithAggregatesFilter<"User"> | string
    name?: StringWithAggregatesFilter<"User"> | string
    password?: StringWithAggregatesFilter<"User"> | string
  }

  export type ZapWhereInput = {
    AND?: ZapWhereInput | ZapWhereInput[]
    OR?: ZapWhereInput[]
    NOT?: ZapWhereInput | ZapWhereInput[]
    id?: StringFilter<"Zap"> | string
    trigger?: XOR<TriggerNullableScalarRelationFilter, TriggerWhereInput> | null
    actions?: ActionsListRelationFilter
    zaprun?: ZapRunListRelationFilter
  }

  export type ZapOrderByWithRelationInput = {
    id?: SortOrder
    trigger?: TriggerOrderByWithRelationInput
    actions?: ActionsOrderByRelationAggregateInput
    zaprun?: ZapRunOrderByRelationAggregateInput
  }

  export type ZapWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: ZapWhereInput | ZapWhereInput[]
    OR?: ZapWhereInput[]
    NOT?: ZapWhereInput | ZapWhereInput[]
    trigger?: XOR<TriggerNullableScalarRelationFilter, TriggerWhereInput> | null
    actions?: ActionsListRelationFilter
    zaprun?: ZapRunListRelationFilter
  }, "id">

  export type ZapOrderByWithAggregationInput = {
    id?: SortOrder
    _count?: ZapCountOrderByAggregateInput
    _max?: ZapMaxOrderByAggregateInput
    _min?: ZapMinOrderByAggregateInput
  }

  export type ZapScalarWhereWithAggregatesInput = {
    AND?: ZapScalarWhereWithAggregatesInput | ZapScalarWhereWithAggregatesInput[]
    OR?: ZapScalarWhereWithAggregatesInput[]
    NOT?: ZapScalarWhereWithAggregatesInput | ZapScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Zap"> | string
  }

  export type TriggerWhereInput = {
    AND?: TriggerWhereInput | TriggerWhereInput[]
    OR?: TriggerWhereInput[]
    NOT?: TriggerWhereInput | TriggerWhereInput[]
    id?: StringFilter<"Trigger"> | string
    ZapID?: StringFilter<"Trigger"> | string
    tiggerID?: StringFilter<"Trigger"> | string
    type?: XOR<TriggerTypeScalarRelationFilter, TriggerTypeWhereInput>
    zap?: XOR<ZapScalarRelationFilter, ZapWhereInput>
  }

  export type TriggerOrderByWithRelationInput = {
    id?: SortOrder
    ZapID?: SortOrder
    tiggerID?: SortOrder
    type?: TriggerTypeOrderByWithRelationInput
    zap?: ZapOrderByWithRelationInput
  }

  export type TriggerWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    ZapID?: string
    AND?: TriggerWhereInput | TriggerWhereInput[]
    OR?: TriggerWhereInput[]
    NOT?: TriggerWhereInput | TriggerWhereInput[]
    tiggerID?: StringFilter<"Trigger"> | string
    type?: XOR<TriggerTypeScalarRelationFilter, TriggerTypeWhereInput>
    zap?: XOR<ZapScalarRelationFilter, ZapWhereInput>
  }, "id" | "ZapID">

  export type TriggerOrderByWithAggregationInput = {
    id?: SortOrder
    ZapID?: SortOrder
    tiggerID?: SortOrder
    _count?: TriggerCountOrderByAggregateInput
    _max?: TriggerMaxOrderByAggregateInput
    _min?: TriggerMinOrderByAggregateInput
  }

  export type TriggerScalarWhereWithAggregatesInput = {
    AND?: TriggerScalarWhereWithAggregatesInput | TriggerScalarWhereWithAggregatesInput[]
    OR?: TriggerScalarWhereWithAggregatesInput[]
    NOT?: TriggerScalarWhereWithAggregatesInput | TriggerScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Trigger"> | string
    ZapID?: StringWithAggregatesFilter<"Trigger"> | string
    tiggerID?: StringWithAggregatesFilter<"Trigger"> | string
  }

  export type ActionsWhereInput = {
    AND?: ActionsWhereInput | ActionsWhereInput[]
    OR?: ActionsWhereInput[]
    NOT?: ActionsWhereInput | ActionsWhereInput[]
    id?: StringFilter<"Actions"> | string
    ZapID?: StringFilter<"Actions"> | string
    actionID?: StringFilter<"Actions"> | string
    zap?: XOR<ZapScalarRelationFilter, ZapWhereInput>
    ActionType?: XOR<AvalibleActionsScalarRelationFilter, AvalibleActionsWhereInput>
  }

  export type ActionsOrderByWithRelationInput = {
    id?: SortOrder
    ZapID?: SortOrder
    actionID?: SortOrder
    zap?: ZapOrderByWithRelationInput
    ActionType?: AvalibleActionsOrderByWithRelationInput
  }

  export type ActionsWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: ActionsWhereInput | ActionsWhereInput[]
    OR?: ActionsWhereInput[]
    NOT?: ActionsWhereInput | ActionsWhereInput[]
    ZapID?: StringFilter<"Actions"> | string
    actionID?: StringFilter<"Actions"> | string
    zap?: XOR<ZapScalarRelationFilter, ZapWhereInput>
    ActionType?: XOR<AvalibleActionsScalarRelationFilter, AvalibleActionsWhereInput>
  }, "id">

  export type ActionsOrderByWithAggregationInput = {
    id?: SortOrder
    ZapID?: SortOrder
    actionID?: SortOrder
    _count?: ActionsCountOrderByAggregateInput
    _max?: ActionsMaxOrderByAggregateInput
    _min?: ActionsMinOrderByAggregateInput
  }

  export type ActionsScalarWhereWithAggregatesInput = {
    AND?: ActionsScalarWhereWithAggregatesInput | ActionsScalarWhereWithAggregatesInput[]
    OR?: ActionsScalarWhereWithAggregatesInput[]
    NOT?: ActionsScalarWhereWithAggregatesInput | ActionsScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Actions"> | string
    ZapID?: StringWithAggregatesFilter<"Actions"> | string
    actionID?: StringWithAggregatesFilter<"Actions"> | string
  }

  export type AvalibleActionsWhereInput = {
    AND?: AvalibleActionsWhereInput | AvalibleActionsWhereInput[]
    OR?: AvalibleActionsWhereInput[]
    NOT?: AvalibleActionsWhereInput | AvalibleActionsWhereInput[]
    id?: StringFilter<"AvalibleActions"> | string
    name?: StringFilter<"AvalibleActions"> | string
    action?: ActionsListRelationFilter
  }

  export type AvalibleActionsOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    action?: ActionsOrderByRelationAggregateInput
  }

  export type AvalibleActionsWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: AvalibleActionsWhereInput | AvalibleActionsWhereInput[]
    OR?: AvalibleActionsWhereInput[]
    NOT?: AvalibleActionsWhereInput | AvalibleActionsWhereInput[]
    name?: StringFilter<"AvalibleActions"> | string
    action?: ActionsListRelationFilter
  }, "id">

  export type AvalibleActionsOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    _count?: AvalibleActionsCountOrderByAggregateInput
    _max?: AvalibleActionsMaxOrderByAggregateInput
    _min?: AvalibleActionsMinOrderByAggregateInput
  }

  export type AvalibleActionsScalarWhereWithAggregatesInput = {
    AND?: AvalibleActionsScalarWhereWithAggregatesInput | AvalibleActionsScalarWhereWithAggregatesInput[]
    OR?: AvalibleActionsScalarWhereWithAggregatesInput[]
    NOT?: AvalibleActionsScalarWhereWithAggregatesInput | AvalibleActionsScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"AvalibleActions"> | string
    name?: StringWithAggregatesFilter<"AvalibleActions"> | string
  }

  export type TriggerTypeWhereInput = {
    AND?: TriggerTypeWhereInput | TriggerTypeWhereInput[]
    OR?: TriggerTypeWhereInput[]
    NOT?: TriggerTypeWhereInput | TriggerTypeWhereInput[]
    id?: StringFilter<"TriggerType"> | string
    name?: StringFilter<"TriggerType"> | string
    triggr?: TriggerListRelationFilter
  }

  export type TriggerTypeOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    triggr?: TriggerOrderByRelationAggregateInput
  }

  export type TriggerTypeWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: TriggerTypeWhereInput | TriggerTypeWhereInput[]
    OR?: TriggerTypeWhereInput[]
    NOT?: TriggerTypeWhereInput | TriggerTypeWhereInput[]
    name?: StringFilter<"TriggerType"> | string
    triggr?: TriggerListRelationFilter
  }, "id">

  export type TriggerTypeOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    _count?: TriggerTypeCountOrderByAggregateInput
    _max?: TriggerTypeMaxOrderByAggregateInput
    _min?: TriggerTypeMinOrderByAggregateInput
  }

  export type TriggerTypeScalarWhereWithAggregatesInput = {
    AND?: TriggerTypeScalarWhereWithAggregatesInput | TriggerTypeScalarWhereWithAggregatesInput[]
    OR?: TriggerTypeScalarWhereWithAggregatesInput[]
    NOT?: TriggerTypeScalarWhereWithAggregatesInput | TriggerTypeScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"TriggerType"> | string
    name?: StringWithAggregatesFilter<"TriggerType"> | string
  }

  export type ZapRunWhereInput = {
    AND?: ZapRunWhereInput | ZapRunWhereInput[]
    OR?: ZapRunWhereInput[]
    NOT?: ZapRunWhereInput | ZapRunWhereInput[]
    id?: StringFilter<"ZapRun"> | string
    zapId?: StringFilter<"ZapRun"> | string
    meatdata?: JsonFilter<"ZapRun">
    zap?: XOR<ZapScalarRelationFilter, ZapWhereInput>
    zaprunoutbox?: XOR<ZapRunOutBoxNullableScalarRelationFilter, ZapRunOutBoxWhereInput> | null
  }

  export type ZapRunOrderByWithRelationInput = {
    id?: SortOrder
    zapId?: SortOrder
    meatdata?: SortOrder
    zap?: ZapOrderByWithRelationInput
    zaprunoutbox?: ZapRunOutBoxOrderByWithRelationInput
  }

  export type ZapRunWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: ZapRunWhereInput | ZapRunWhereInput[]
    OR?: ZapRunWhereInput[]
    NOT?: ZapRunWhereInput | ZapRunWhereInput[]
    zapId?: StringFilter<"ZapRun"> | string
    meatdata?: JsonFilter<"ZapRun">
    zap?: XOR<ZapScalarRelationFilter, ZapWhereInput>
    zaprunoutbox?: XOR<ZapRunOutBoxNullableScalarRelationFilter, ZapRunOutBoxWhereInput> | null
  }, "id">

  export type ZapRunOrderByWithAggregationInput = {
    id?: SortOrder
    zapId?: SortOrder
    meatdata?: SortOrder
    _count?: ZapRunCountOrderByAggregateInput
    _max?: ZapRunMaxOrderByAggregateInput
    _min?: ZapRunMinOrderByAggregateInput
  }

  export type ZapRunScalarWhereWithAggregatesInput = {
    AND?: ZapRunScalarWhereWithAggregatesInput | ZapRunScalarWhereWithAggregatesInput[]
    OR?: ZapRunScalarWhereWithAggregatesInput[]
    NOT?: ZapRunScalarWhereWithAggregatesInput | ZapRunScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"ZapRun"> | string
    zapId?: StringWithAggregatesFilter<"ZapRun"> | string
    meatdata?: JsonWithAggregatesFilter<"ZapRun">
  }

  export type ZapRunOutBoxWhereInput = {
    AND?: ZapRunOutBoxWhereInput | ZapRunOutBoxWhereInput[]
    OR?: ZapRunOutBoxWhereInput[]
    NOT?: ZapRunOutBoxWhereInput | ZapRunOutBoxWhereInput[]
    id?: StringFilter<"ZapRunOutBox"> | string
    zaprunid?: StringFilter<"ZapRunOutBox"> | string
    zaprun?: XOR<ZapRunScalarRelationFilter, ZapRunWhereInput>
  }

  export type ZapRunOutBoxOrderByWithRelationInput = {
    id?: SortOrder
    zaprunid?: SortOrder
    zaprun?: ZapRunOrderByWithRelationInput
  }

  export type ZapRunOutBoxWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    zaprunid?: string
    AND?: ZapRunOutBoxWhereInput | ZapRunOutBoxWhereInput[]
    OR?: ZapRunOutBoxWhereInput[]
    NOT?: ZapRunOutBoxWhereInput | ZapRunOutBoxWhereInput[]
    zaprun?: XOR<ZapRunScalarRelationFilter, ZapRunWhereInput>
  }, "id" | "zaprunid">

  export type ZapRunOutBoxOrderByWithAggregationInput = {
    id?: SortOrder
    zaprunid?: SortOrder
    _count?: ZapRunOutBoxCountOrderByAggregateInput
    _max?: ZapRunOutBoxMaxOrderByAggregateInput
    _min?: ZapRunOutBoxMinOrderByAggregateInput
  }

  export type ZapRunOutBoxScalarWhereWithAggregatesInput = {
    AND?: ZapRunOutBoxScalarWhereWithAggregatesInput | ZapRunOutBoxScalarWhereWithAggregatesInput[]
    OR?: ZapRunOutBoxScalarWhereWithAggregatesInput[]
    NOT?: ZapRunOutBoxScalarWhereWithAggregatesInput | ZapRunOutBoxScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"ZapRunOutBox"> | string
    zaprunid?: StringWithAggregatesFilter<"ZapRunOutBox"> | string
  }

  export type UserCreateInput = {
    email: string
    name: string
    password: string
  }

  export type UserUncheckedCreateInput = {
    id?: number
    email: string
    name: string
    password: string
  }

  export type UserUpdateInput = {
    email?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
  }

  export type UserUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    email?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
  }

  export type UserCreateManyInput = {
    id?: number
    email: string
    name: string
    password: string
  }

  export type UserUpdateManyMutationInput = {
    email?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
  }

  export type UserUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    email?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
  }

  export type ZapCreateInput = {
    id?: string
    trigger?: TriggerCreateNestedOneWithoutZapInput
    actions?: ActionsCreateNestedManyWithoutZapInput
    zaprun?: ZapRunCreateNestedManyWithoutZapInput
  }

  export type ZapUncheckedCreateInput = {
    id?: string
    trigger?: TriggerUncheckedCreateNestedOneWithoutZapInput
    actions?: ActionsUncheckedCreateNestedManyWithoutZapInput
    zaprun?: ZapRunUncheckedCreateNestedManyWithoutZapInput
  }

  export type ZapUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    trigger?: TriggerUpdateOneWithoutZapNestedInput
    actions?: ActionsUpdateManyWithoutZapNestedInput
    zaprun?: ZapRunUpdateManyWithoutZapNestedInput
  }

  export type ZapUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    trigger?: TriggerUncheckedUpdateOneWithoutZapNestedInput
    actions?: ActionsUncheckedUpdateManyWithoutZapNestedInput
    zaprun?: ZapRunUncheckedUpdateManyWithoutZapNestedInput
  }

  export type ZapCreateManyInput = {
    id?: string
  }

  export type ZapUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
  }

  export type ZapUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
  }

  export type TriggerCreateInput = {
    id?: string
    type: TriggerTypeCreateNestedOneWithoutTriggrInput
    zap: ZapCreateNestedOneWithoutTriggerInput
  }

  export type TriggerUncheckedCreateInput = {
    id?: string
    ZapID: string
    tiggerID: string
  }

  export type TriggerUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    type?: TriggerTypeUpdateOneRequiredWithoutTriggrNestedInput
    zap?: ZapUpdateOneRequiredWithoutTriggerNestedInput
  }

  export type TriggerUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    ZapID?: StringFieldUpdateOperationsInput | string
    tiggerID?: StringFieldUpdateOperationsInput | string
  }

  export type TriggerCreateManyInput = {
    id?: string
    ZapID: string
    tiggerID: string
  }

  export type TriggerUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
  }

  export type TriggerUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    ZapID?: StringFieldUpdateOperationsInput | string
    tiggerID?: StringFieldUpdateOperationsInput | string
  }

  export type ActionsCreateInput = {
    id?: string
    zap: ZapCreateNestedOneWithoutActionsInput
    ActionType: AvalibleActionsCreateNestedOneWithoutActionInput
  }

  export type ActionsUncheckedCreateInput = {
    id?: string
    ZapID: string
    actionID: string
  }

  export type ActionsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    zap?: ZapUpdateOneRequiredWithoutActionsNestedInput
    ActionType?: AvalibleActionsUpdateOneRequiredWithoutActionNestedInput
  }

  export type ActionsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    ZapID?: StringFieldUpdateOperationsInput | string
    actionID?: StringFieldUpdateOperationsInput | string
  }

  export type ActionsCreateManyInput = {
    id?: string
    ZapID: string
    actionID: string
  }

  export type ActionsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
  }

  export type ActionsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    ZapID?: StringFieldUpdateOperationsInput | string
    actionID?: StringFieldUpdateOperationsInput | string
  }

  export type AvalibleActionsCreateInput = {
    id?: string
    name: string
    action?: ActionsCreateNestedManyWithoutActionTypeInput
  }

  export type AvalibleActionsUncheckedCreateInput = {
    id?: string
    name: string
    action?: ActionsUncheckedCreateNestedManyWithoutActionTypeInput
  }

  export type AvalibleActionsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    action?: ActionsUpdateManyWithoutActionTypeNestedInput
  }

  export type AvalibleActionsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    action?: ActionsUncheckedUpdateManyWithoutActionTypeNestedInput
  }

  export type AvalibleActionsCreateManyInput = {
    id?: string
    name: string
  }

  export type AvalibleActionsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
  }

  export type AvalibleActionsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
  }

  export type TriggerTypeCreateInput = {
    id?: string
    name: string
    triggr?: TriggerCreateNestedManyWithoutTypeInput
  }

  export type TriggerTypeUncheckedCreateInput = {
    id?: string
    name: string
    triggr?: TriggerUncheckedCreateNestedManyWithoutTypeInput
  }

  export type TriggerTypeUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    triggr?: TriggerUpdateManyWithoutTypeNestedInput
  }

  export type TriggerTypeUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    triggr?: TriggerUncheckedUpdateManyWithoutTypeNestedInput
  }

  export type TriggerTypeCreateManyInput = {
    id?: string
    name: string
  }

  export type TriggerTypeUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
  }

  export type TriggerTypeUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
  }

  export type ZapRunCreateInput = {
    id?: string
    meatdata: JsonNullValueInput | InputJsonValue
    zap: ZapCreateNestedOneWithoutZaprunInput
    zaprunoutbox?: ZapRunOutBoxCreateNestedOneWithoutZaprunInput
  }

  export type ZapRunUncheckedCreateInput = {
    id?: string
    zapId: string
    meatdata: JsonNullValueInput | InputJsonValue
    zaprunoutbox?: ZapRunOutBoxUncheckedCreateNestedOneWithoutZaprunInput
  }

  export type ZapRunUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    meatdata?: JsonNullValueInput | InputJsonValue
    zap?: ZapUpdateOneRequiredWithoutZaprunNestedInput
    zaprunoutbox?: ZapRunOutBoxUpdateOneWithoutZaprunNestedInput
  }

  export type ZapRunUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    zapId?: StringFieldUpdateOperationsInput | string
    meatdata?: JsonNullValueInput | InputJsonValue
    zaprunoutbox?: ZapRunOutBoxUncheckedUpdateOneWithoutZaprunNestedInput
  }

  export type ZapRunCreateManyInput = {
    id?: string
    zapId: string
    meatdata: JsonNullValueInput | InputJsonValue
  }

  export type ZapRunUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    meatdata?: JsonNullValueInput | InputJsonValue
  }

  export type ZapRunUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    zapId?: StringFieldUpdateOperationsInput | string
    meatdata?: JsonNullValueInput | InputJsonValue
  }

  export type ZapRunOutBoxCreateInput = {
    id?: string
    zaprun: ZapRunCreateNestedOneWithoutZaprunoutboxInput
  }

  export type ZapRunOutBoxUncheckedCreateInput = {
    id?: string
    zaprunid: string
  }

  export type ZapRunOutBoxUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    zaprun?: ZapRunUpdateOneRequiredWithoutZaprunoutboxNestedInput
  }

  export type ZapRunOutBoxUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    zaprunid?: StringFieldUpdateOperationsInput | string
  }

  export type ZapRunOutBoxCreateManyInput = {
    id?: string
    zaprunid: string
  }

  export type ZapRunOutBoxUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
  }

  export type ZapRunOutBoxUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    zaprunid?: StringFieldUpdateOperationsInput | string
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type UserCountOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    password?: SortOrder
  }

  export type UserAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    password?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    password?: SortOrder
  }

  export type UserSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type TriggerNullableScalarRelationFilter = {
    is?: TriggerWhereInput | null
    isNot?: TriggerWhereInput | null
  }

  export type ActionsListRelationFilter = {
    every?: ActionsWhereInput
    some?: ActionsWhereInput
    none?: ActionsWhereInput
  }

  export type ZapRunListRelationFilter = {
    every?: ZapRunWhereInput
    some?: ZapRunWhereInput
    none?: ZapRunWhereInput
  }

  export type ActionsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ZapRunOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ZapCountOrderByAggregateInput = {
    id?: SortOrder
  }

  export type ZapMaxOrderByAggregateInput = {
    id?: SortOrder
  }

  export type ZapMinOrderByAggregateInput = {
    id?: SortOrder
  }

  export type TriggerTypeScalarRelationFilter = {
    is?: TriggerTypeWhereInput
    isNot?: TriggerTypeWhereInput
  }

  export type ZapScalarRelationFilter = {
    is?: ZapWhereInput
    isNot?: ZapWhereInput
  }

  export type TriggerCountOrderByAggregateInput = {
    id?: SortOrder
    ZapID?: SortOrder
    tiggerID?: SortOrder
  }

  export type TriggerMaxOrderByAggregateInput = {
    id?: SortOrder
    ZapID?: SortOrder
    tiggerID?: SortOrder
  }

  export type TriggerMinOrderByAggregateInput = {
    id?: SortOrder
    ZapID?: SortOrder
    tiggerID?: SortOrder
  }

  export type AvalibleActionsScalarRelationFilter = {
    is?: AvalibleActionsWhereInput
    isNot?: AvalibleActionsWhereInput
  }

  export type ActionsCountOrderByAggregateInput = {
    id?: SortOrder
    ZapID?: SortOrder
    actionID?: SortOrder
  }

  export type ActionsMaxOrderByAggregateInput = {
    id?: SortOrder
    ZapID?: SortOrder
    actionID?: SortOrder
  }

  export type ActionsMinOrderByAggregateInput = {
    id?: SortOrder
    ZapID?: SortOrder
    actionID?: SortOrder
  }

  export type AvalibleActionsCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
  }

  export type AvalibleActionsMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
  }

  export type AvalibleActionsMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
  }

  export type TriggerListRelationFilter = {
    every?: TriggerWhereInput
    some?: TriggerWhereInput
    none?: TriggerWhereInput
  }

  export type TriggerOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type TriggerTypeCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
  }

  export type TriggerTypeMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
  }

  export type TriggerTypeMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
  }
  export type JsonFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonFilterBase<$PrismaModel>>, 'path'>>

  export type JsonFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type ZapRunOutBoxNullableScalarRelationFilter = {
    is?: ZapRunOutBoxWhereInput | null
    isNot?: ZapRunOutBoxWhereInput | null
  }

  export type ZapRunCountOrderByAggregateInput = {
    id?: SortOrder
    zapId?: SortOrder
    meatdata?: SortOrder
  }

  export type ZapRunMaxOrderByAggregateInput = {
    id?: SortOrder
    zapId?: SortOrder
  }

  export type ZapRunMinOrderByAggregateInput = {
    id?: SortOrder
    zapId?: SortOrder
  }
  export type JsonWithAggregatesFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonWithAggregatesFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonWithAggregatesFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonWithAggregatesFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonWithAggregatesFilterBase<$PrismaModel>>, 'path'>>

  export type JsonWithAggregatesFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedJsonFilter<$PrismaModel>
    _max?: NestedJsonFilter<$PrismaModel>
  }

  export type ZapRunScalarRelationFilter = {
    is?: ZapRunWhereInput
    isNot?: ZapRunWhereInput
  }

  export type ZapRunOutBoxCountOrderByAggregateInput = {
    id?: SortOrder
    zaprunid?: SortOrder
  }

  export type ZapRunOutBoxMaxOrderByAggregateInput = {
    id?: SortOrder
    zaprunid?: SortOrder
  }

  export type ZapRunOutBoxMinOrderByAggregateInput = {
    id?: SortOrder
    zaprunid?: SortOrder
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type TriggerCreateNestedOneWithoutZapInput = {
    create?: XOR<TriggerCreateWithoutZapInput, TriggerUncheckedCreateWithoutZapInput>
    connectOrCreate?: TriggerCreateOrConnectWithoutZapInput
    connect?: TriggerWhereUniqueInput
  }

  export type ActionsCreateNestedManyWithoutZapInput = {
    create?: XOR<ActionsCreateWithoutZapInput, ActionsUncheckedCreateWithoutZapInput> | ActionsCreateWithoutZapInput[] | ActionsUncheckedCreateWithoutZapInput[]
    connectOrCreate?: ActionsCreateOrConnectWithoutZapInput | ActionsCreateOrConnectWithoutZapInput[]
    createMany?: ActionsCreateManyZapInputEnvelope
    connect?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
  }

  export type ZapRunCreateNestedManyWithoutZapInput = {
    create?: XOR<ZapRunCreateWithoutZapInput, ZapRunUncheckedCreateWithoutZapInput> | ZapRunCreateWithoutZapInput[] | ZapRunUncheckedCreateWithoutZapInput[]
    connectOrCreate?: ZapRunCreateOrConnectWithoutZapInput | ZapRunCreateOrConnectWithoutZapInput[]
    createMany?: ZapRunCreateManyZapInputEnvelope
    connect?: ZapRunWhereUniqueInput | ZapRunWhereUniqueInput[]
  }

  export type TriggerUncheckedCreateNestedOneWithoutZapInput = {
    create?: XOR<TriggerCreateWithoutZapInput, TriggerUncheckedCreateWithoutZapInput>
    connectOrCreate?: TriggerCreateOrConnectWithoutZapInput
    connect?: TriggerWhereUniqueInput
  }

  export type ActionsUncheckedCreateNestedManyWithoutZapInput = {
    create?: XOR<ActionsCreateWithoutZapInput, ActionsUncheckedCreateWithoutZapInput> | ActionsCreateWithoutZapInput[] | ActionsUncheckedCreateWithoutZapInput[]
    connectOrCreate?: ActionsCreateOrConnectWithoutZapInput | ActionsCreateOrConnectWithoutZapInput[]
    createMany?: ActionsCreateManyZapInputEnvelope
    connect?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
  }

  export type ZapRunUncheckedCreateNestedManyWithoutZapInput = {
    create?: XOR<ZapRunCreateWithoutZapInput, ZapRunUncheckedCreateWithoutZapInput> | ZapRunCreateWithoutZapInput[] | ZapRunUncheckedCreateWithoutZapInput[]
    connectOrCreate?: ZapRunCreateOrConnectWithoutZapInput | ZapRunCreateOrConnectWithoutZapInput[]
    createMany?: ZapRunCreateManyZapInputEnvelope
    connect?: ZapRunWhereUniqueInput | ZapRunWhereUniqueInput[]
  }

  export type TriggerUpdateOneWithoutZapNestedInput = {
    create?: XOR<TriggerCreateWithoutZapInput, TriggerUncheckedCreateWithoutZapInput>
    connectOrCreate?: TriggerCreateOrConnectWithoutZapInput
    upsert?: TriggerUpsertWithoutZapInput
    disconnect?: TriggerWhereInput | boolean
    delete?: TriggerWhereInput | boolean
    connect?: TriggerWhereUniqueInput
    update?: XOR<XOR<TriggerUpdateToOneWithWhereWithoutZapInput, TriggerUpdateWithoutZapInput>, TriggerUncheckedUpdateWithoutZapInput>
  }

  export type ActionsUpdateManyWithoutZapNestedInput = {
    create?: XOR<ActionsCreateWithoutZapInput, ActionsUncheckedCreateWithoutZapInput> | ActionsCreateWithoutZapInput[] | ActionsUncheckedCreateWithoutZapInput[]
    connectOrCreate?: ActionsCreateOrConnectWithoutZapInput | ActionsCreateOrConnectWithoutZapInput[]
    upsert?: ActionsUpsertWithWhereUniqueWithoutZapInput | ActionsUpsertWithWhereUniqueWithoutZapInput[]
    createMany?: ActionsCreateManyZapInputEnvelope
    set?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    disconnect?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    delete?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    connect?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    update?: ActionsUpdateWithWhereUniqueWithoutZapInput | ActionsUpdateWithWhereUniqueWithoutZapInput[]
    updateMany?: ActionsUpdateManyWithWhereWithoutZapInput | ActionsUpdateManyWithWhereWithoutZapInput[]
    deleteMany?: ActionsScalarWhereInput | ActionsScalarWhereInput[]
  }

  export type ZapRunUpdateManyWithoutZapNestedInput = {
    create?: XOR<ZapRunCreateWithoutZapInput, ZapRunUncheckedCreateWithoutZapInput> | ZapRunCreateWithoutZapInput[] | ZapRunUncheckedCreateWithoutZapInput[]
    connectOrCreate?: ZapRunCreateOrConnectWithoutZapInput | ZapRunCreateOrConnectWithoutZapInput[]
    upsert?: ZapRunUpsertWithWhereUniqueWithoutZapInput | ZapRunUpsertWithWhereUniqueWithoutZapInput[]
    createMany?: ZapRunCreateManyZapInputEnvelope
    set?: ZapRunWhereUniqueInput | ZapRunWhereUniqueInput[]
    disconnect?: ZapRunWhereUniqueInput | ZapRunWhereUniqueInput[]
    delete?: ZapRunWhereUniqueInput | ZapRunWhereUniqueInput[]
    connect?: ZapRunWhereUniqueInput | ZapRunWhereUniqueInput[]
    update?: ZapRunUpdateWithWhereUniqueWithoutZapInput | ZapRunUpdateWithWhereUniqueWithoutZapInput[]
    updateMany?: ZapRunUpdateManyWithWhereWithoutZapInput | ZapRunUpdateManyWithWhereWithoutZapInput[]
    deleteMany?: ZapRunScalarWhereInput | ZapRunScalarWhereInput[]
  }

  export type TriggerUncheckedUpdateOneWithoutZapNestedInput = {
    create?: XOR<TriggerCreateWithoutZapInput, TriggerUncheckedCreateWithoutZapInput>
    connectOrCreate?: TriggerCreateOrConnectWithoutZapInput
    upsert?: TriggerUpsertWithoutZapInput
    disconnect?: TriggerWhereInput | boolean
    delete?: TriggerWhereInput | boolean
    connect?: TriggerWhereUniqueInput
    update?: XOR<XOR<TriggerUpdateToOneWithWhereWithoutZapInput, TriggerUpdateWithoutZapInput>, TriggerUncheckedUpdateWithoutZapInput>
  }

  export type ActionsUncheckedUpdateManyWithoutZapNestedInput = {
    create?: XOR<ActionsCreateWithoutZapInput, ActionsUncheckedCreateWithoutZapInput> | ActionsCreateWithoutZapInput[] | ActionsUncheckedCreateWithoutZapInput[]
    connectOrCreate?: ActionsCreateOrConnectWithoutZapInput | ActionsCreateOrConnectWithoutZapInput[]
    upsert?: ActionsUpsertWithWhereUniqueWithoutZapInput | ActionsUpsertWithWhereUniqueWithoutZapInput[]
    createMany?: ActionsCreateManyZapInputEnvelope
    set?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    disconnect?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    delete?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    connect?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    update?: ActionsUpdateWithWhereUniqueWithoutZapInput | ActionsUpdateWithWhereUniqueWithoutZapInput[]
    updateMany?: ActionsUpdateManyWithWhereWithoutZapInput | ActionsUpdateManyWithWhereWithoutZapInput[]
    deleteMany?: ActionsScalarWhereInput | ActionsScalarWhereInput[]
  }

  export type ZapRunUncheckedUpdateManyWithoutZapNestedInput = {
    create?: XOR<ZapRunCreateWithoutZapInput, ZapRunUncheckedCreateWithoutZapInput> | ZapRunCreateWithoutZapInput[] | ZapRunUncheckedCreateWithoutZapInput[]
    connectOrCreate?: ZapRunCreateOrConnectWithoutZapInput | ZapRunCreateOrConnectWithoutZapInput[]
    upsert?: ZapRunUpsertWithWhereUniqueWithoutZapInput | ZapRunUpsertWithWhereUniqueWithoutZapInput[]
    createMany?: ZapRunCreateManyZapInputEnvelope
    set?: ZapRunWhereUniqueInput | ZapRunWhereUniqueInput[]
    disconnect?: ZapRunWhereUniqueInput | ZapRunWhereUniqueInput[]
    delete?: ZapRunWhereUniqueInput | ZapRunWhereUniqueInput[]
    connect?: ZapRunWhereUniqueInput | ZapRunWhereUniqueInput[]
    update?: ZapRunUpdateWithWhereUniqueWithoutZapInput | ZapRunUpdateWithWhereUniqueWithoutZapInput[]
    updateMany?: ZapRunUpdateManyWithWhereWithoutZapInput | ZapRunUpdateManyWithWhereWithoutZapInput[]
    deleteMany?: ZapRunScalarWhereInput | ZapRunScalarWhereInput[]
  }

  export type TriggerTypeCreateNestedOneWithoutTriggrInput = {
    create?: XOR<TriggerTypeCreateWithoutTriggrInput, TriggerTypeUncheckedCreateWithoutTriggrInput>
    connectOrCreate?: TriggerTypeCreateOrConnectWithoutTriggrInput
    connect?: TriggerTypeWhereUniqueInput
  }

  export type ZapCreateNestedOneWithoutTriggerInput = {
    create?: XOR<ZapCreateWithoutTriggerInput, ZapUncheckedCreateWithoutTriggerInput>
    connectOrCreate?: ZapCreateOrConnectWithoutTriggerInput
    connect?: ZapWhereUniqueInput
  }

  export type TriggerTypeUpdateOneRequiredWithoutTriggrNestedInput = {
    create?: XOR<TriggerTypeCreateWithoutTriggrInput, TriggerTypeUncheckedCreateWithoutTriggrInput>
    connectOrCreate?: TriggerTypeCreateOrConnectWithoutTriggrInput
    upsert?: TriggerTypeUpsertWithoutTriggrInput
    connect?: TriggerTypeWhereUniqueInput
    update?: XOR<XOR<TriggerTypeUpdateToOneWithWhereWithoutTriggrInput, TriggerTypeUpdateWithoutTriggrInput>, TriggerTypeUncheckedUpdateWithoutTriggrInput>
  }

  export type ZapUpdateOneRequiredWithoutTriggerNestedInput = {
    create?: XOR<ZapCreateWithoutTriggerInput, ZapUncheckedCreateWithoutTriggerInput>
    connectOrCreate?: ZapCreateOrConnectWithoutTriggerInput
    upsert?: ZapUpsertWithoutTriggerInput
    connect?: ZapWhereUniqueInput
    update?: XOR<XOR<ZapUpdateToOneWithWhereWithoutTriggerInput, ZapUpdateWithoutTriggerInput>, ZapUncheckedUpdateWithoutTriggerInput>
  }

  export type ZapCreateNestedOneWithoutActionsInput = {
    create?: XOR<ZapCreateWithoutActionsInput, ZapUncheckedCreateWithoutActionsInput>
    connectOrCreate?: ZapCreateOrConnectWithoutActionsInput
    connect?: ZapWhereUniqueInput
  }

  export type AvalibleActionsCreateNestedOneWithoutActionInput = {
    create?: XOR<AvalibleActionsCreateWithoutActionInput, AvalibleActionsUncheckedCreateWithoutActionInput>
    connectOrCreate?: AvalibleActionsCreateOrConnectWithoutActionInput
    connect?: AvalibleActionsWhereUniqueInput
  }

  export type ZapUpdateOneRequiredWithoutActionsNestedInput = {
    create?: XOR<ZapCreateWithoutActionsInput, ZapUncheckedCreateWithoutActionsInput>
    connectOrCreate?: ZapCreateOrConnectWithoutActionsInput
    upsert?: ZapUpsertWithoutActionsInput
    connect?: ZapWhereUniqueInput
    update?: XOR<XOR<ZapUpdateToOneWithWhereWithoutActionsInput, ZapUpdateWithoutActionsInput>, ZapUncheckedUpdateWithoutActionsInput>
  }

  export type AvalibleActionsUpdateOneRequiredWithoutActionNestedInput = {
    create?: XOR<AvalibleActionsCreateWithoutActionInput, AvalibleActionsUncheckedCreateWithoutActionInput>
    connectOrCreate?: AvalibleActionsCreateOrConnectWithoutActionInput
    upsert?: AvalibleActionsUpsertWithoutActionInput
    connect?: AvalibleActionsWhereUniqueInput
    update?: XOR<XOR<AvalibleActionsUpdateToOneWithWhereWithoutActionInput, AvalibleActionsUpdateWithoutActionInput>, AvalibleActionsUncheckedUpdateWithoutActionInput>
  }

  export type ActionsCreateNestedManyWithoutActionTypeInput = {
    create?: XOR<ActionsCreateWithoutActionTypeInput, ActionsUncheckedCreateWithoutActionTypeInput> | ActionsCreateWithoutActionTypeInput[] | ActionsUncheckedCreateWithoutActionTypeInput[]
    connectOrCreate?: ActionsCreateOrConnectWithoutActionTypeInput | ActionsCreateOrConnectWithoutActionTypeInput[]
    createMany?: ActionsCreateManyActionTypeInputEnvelope
    connect?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
  }

  export type ActionsUncheckedCreateNestedManyWithoutActionTypeInput = {
    create?: XOR<ActionsCreateWithoutActionTypeInput, ActionsUncheckedCreateWithoutActionTypeInput> | ActionsCreateWithoutActionTypeInput[] | ActionsUncheckedCreateWithoutActionTypeInput[]
    connectOrCreate?: ActionsCreateOrConnectWithoutActionTypeInput | ActionsCreateOrConnectWithoutActionTypeInput[]
    createMany?: ActionsCreateManyActionTypeInputEnvelope
    connect?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
  }

  export type ActionsUpdateManyWithoutActionTypeNestedInput = {
    create?: XOR<ActionsCreateWithoutActionTypeInput, ActionsUncheckedCreateWithoutActionTypeInput> | ActionsCreateWithoutActionTypeInput[] | ActionsUncheckedCreateWithoutActionTypeInput[]
    connectOrCreate?: ActionsCreateOrConnectWithoutActionTypeInput | ActionsCreateOrConnectWithoutActionTypeInput[]
    upsert?: ActionsUpsertWithWhereUniqueWithoutActionTypeInput | ActionsUpsertWithWhereUniqueWithoutActionTypeInput[]
    createMany?: ActionsCreateManyActionTypeInputEnvelope
    set?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    disconnect?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    delete?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    connect?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    update?: ActionsUpdateWithWhereUniqueWithoutActionTypeInput | ActionsUpdateWithWhereUniqueWithoutActionTypeInput[]
    updateMany?: ActionsUpdateManyWithWhereWithoutActionTypeInput | ActionsUpdateManyWithWhereWithoutActionTypeInput[]
    deleteMany?: ActionsScalarWhereInput | ActionsScalarWhereInput[]
  }

  export type ActionsUncheckedUpdateManyWithoutActionTypeNestedInput = {
    create?: XOR<ActionsCreateWithoutActionTypeInput, ActionsUncheckedCreateWithoutActionTypeInput> | ActionsCreateWithoutActionTypeInput[] | ActionsUncheckedCreateWithoutActionTypeInput[]
    connectOrCreate?: ActionsCreateOrConnectWithoutActionTypeInput | ActionsCreateOrConnectWithoutActionTypeInput[]
    upsert?: ActionsUpsertWithWhereUniqueWithoutActionTypeInput | ActionsUpsertWithWhereUniqueWithoutActionTypeInput[]
    createMany?: ActionsCreateManyActionTypeInputEnvelope
    set?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    disconnect?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    delete?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    connect?: ActionsWhereUniqueInput | ActionsWhereUniqueInput[]
    update?: ActionsUpdateWithWhereUniqueWithoutActionTypeInput | ActionsUpdateWithWhereUniqueWithoutActionTypeInput[]
    updateMany?: ActionsUpdateManyWithWhereWithoutActionTypeInput | ActionsUpdateManyWithWhereWithoutActionTypeInput[]
    deleteMany?: ActionsScalarWhereInput | ActionsScalarWhereInput[]
  }

  export type TriggerCreateNestedManyWithoutTypeInput = {
    create?: XOR<TriggerCreateWithoutTypeInput, TriggerUncheckedCreateWithoutTypeInput> | TriggerCreateWithoutTypeInput[] | TriggerUncheckedCreateWithoutTypeInput[]
    connectOrCreate?: TriggerCreateOrConnectWithoutTypeInput | TriggerCreateOrConnectWithoutTypeInput[]
    createMany?: TriggerCreateManyTypeInputEnvelope
    connect?: TriggerWhereUniqueInput | TriggerWhereUniqueInput[]
  }

  export type TriggerUncheckedCreateNestedManyWithoutTypeInput = {
    create?: XOR<TriggerCreateWithoutTypeInput, TriggerUncheckedCreateWithoutTypeInput> | TriggerCreateWithoutTypeInput[] | TriggerUncheckedCreateWithoutTypeInput[]
    connectOrCreate?: TriggerCreateOrConnectWithoutTypeInput | TriggerCreateOrConnectWithoutTypeInput[]
    createMany?: TriggerCreateManyTypeInputEnvelope
    connect?: TriggerWhereUniqueInput | TriggerWhereUniqueInput[]
  }

  export type TriggerUpdateManyWithoutTypeNestedInput = {
    create?: XOR<TriggerCreateWithoutTypeInput, TriggerUncheckedCreateWithoutTypeInput> | TriggerCreateWithoutTypeInput[] | TriggerUncheckedCreateWithoutTypeInput[]
    connectOrCreate?: TriggerCreateOrConnectWithoutTypeInput | TriggerCreateOrConnectWithoutTypeInput[]
    upsert?: TriggerUpsertWithWhereUniqueWithoutTypeInput | TriggerUpsertWithWhereUniqueWithoutTypeInput[]
    createMany?: TriggerCreateManyTypeInputEnvelope
    set?: TriggerWhereUniqueInput | TriggerWhereUniqueInput[]
    disconnect?: TriggerWhereUniqueInput | TriggerWhereUniqueInput[]
    delete?: TriggerWhereUniqueInput | TriggerWhereUniqueInput[]
    connect?: TriggerWhereUniqueInput | TriggerWhereUniqueInput[]
    update?: TriggerUpdateWithWhereUniqueWithoutTypeInput | TriggerUpdateWithWhereUniqueWithoutTypeInput[]
    updateMany?: TriggerUpdateManyWithWhereWithoutTypeInput | TriggerUpdateManyWithWhereWithoutTypeInput[]
    deleteMany?: TriggerScalarWhereInput | TriggerScalarWhereInput[]
  }

  export type TriggerUncheckedUpdateManyWithoutTypeNestedInput = {
    create?: XOR<TriggerCreateWithoutTypeInput, TriggerUncheckedCreateWithoutTypeInput> | TriggerCreateWithoutTypeInput[] | TriggerUncheckedCreateWithoutTypeInput[]
    connectOrCreate?: TriggerCreateOrConnectWithoutTypeInput | TriggerCreateOrConnectWithoutTypeInput[]
    upsert?: TriggerUpsertWithWhereUniqueWithoutTypeInput | TriggerUpsertWithWhereUniqueWithoutTypeInput[]
    createMany?: TriggerCreateManyTypeInputEnvelope
    set?: TriggerWhereUniqueInput | TriggerWhereUniqueInput[]
    disconnect?: TriggerWhereUniqueInput | TriggerWhereUniqueInput[]
    delete?: TriggerWhereUniqueInput | TriggerWhereUniqueInput[]
    connect?: TriggerWhereUniqueInput | TriggerWhereUniqueInput[]
    update?: TriggerUpdateWithWhereUniqueWithoutTypeInput | TriggerUpdateWithWhereUniqueWithoutTypeInput[]
    updateMany?: TriggerUpdateManyWithWhereWithoutTypeInput | TriggerUpdateManyWithWhereWithoutTypeInput[]
    deleteMany?: TriggerScalarWhereInput | TriggerScalarWhereInput[]
  }

  export type ZapCreateNestedOneWithoutZaprunInput = {
    create?: XOR<ZapCreateWithoutZaprunInput, ZapUncheckedCreateWithoutZaprunInput>
    connectOrCreate?: ZapCreateOrConnectWithoutZaprunInput
    connect?: ZapWhereUniqueInput
  }

  export type ZapRunOutBoxCreateNestedOneWithoutZaprunInput = {
    create?: XOR<ZapRunOutBoxCreateWithoutZaprunInput, ZapRunOutBoxUncheckedCreateWithoutZaprunInput>
    connectOrCreate?: ZapRunOutBoxCreateOrConnectWithoutZaprunInput
    connect?: ZapRunOutBoxWhereUniqueInput
  }

  export type ZapRunOutBoxUncheckedCreateNestedOneWithoutZaprunInput = {
    create?: XOR<ZapRunOutBoxCreateWithoutZaprunInput, ZapRunOutBoxUncheckedCreateWithoutZaprunInput>
    connectOrCreate?: ZapRunOutBoxCreateOrConnectWithoutZaprunInput
    connect?: ZapRunOutBoxWhereUniqueInput
  }

  export type ZapUpdateOneRequiredWithoutZaprunNestedInput = {
    create?: XOR<ZapCreateWithoutZaprunInput, ZapUncheckedCreateWithoutZaprunInput>
    connectOrCreate?: ZapCreateOrConnectWithoutZaprunInput
    upsert?: ZapUpsertWithoutZaprunInput
    connect?: ZapWhereUniqueInput
    update?: XOR<XOR<ZapUpdateToOneWithWhereWithoutZaprunInput, ZapUpdateWithoutZaprunInput>, ZapUncheckedUpdateWithoutZaprunInput>
  }

  export type ZapRunOutBoxUpdateOneWithoutZaprunNestedInput = {
    create?: XOR<ZapRunOutBoxCreateWithoutZaprunInput, ZapRunOutBoxUncheckedCreateWithoutZaprunInput>
    connectOrCreate?: ZapRunOutBoxCreateOrConnectWithoutZaprunInput
    upsert?: ZapRunOutBoxUpsertWithoutZaprunInput
    disconnect?: ZapRunOutBoxWhereInput | boolean
    delete?: ZapRunOutBoxWhereInput | boolean
    connect?: ZapRunOutBoxWhereUniqueInput
    update?: XOR<XOR<ZapRunOutBoxUpdateToOneWithWhereWithoutZaprunInput, ZapRunOutBoxUpdateWithoutZaprunInput>, ZapRunOutBoxUncheckedUpdateWithoutZaprunInput>
  }

  export type ZapRunOutBoxUncheckedUpdateOneWithoutZaprunNestedInput = {
    create?: XOR<ZapRunOutBoxCreateWithoutZaprunInput, ZapRunOutBoxUncheckedCreateWithoutZaprunInput>
    connectOrCreate?: ZapRunOutBoxCreateOrConnectWithoutZaprunInput
    upsert?: ZapRunOutBoxUpsertWithoutZaprunInput
    disconnect?: ZapRunOutBoxWhereInput | boolean
    delete?: ZapRunOutBoxWhereInput | boolean
    connect?: ZapRunOutBoxWhereUniqueInput
    update?: XOR<XOR<ZapRunOutBoxUpdateToOneWithWhereWithoutZaprunInput, ZapRunOutBoxUpdateWithoutZaprunInput>, ZapRunOutBoxUncheckedUpdateWithoutZaprunInput>
  }

  export type ZapRunCreateNestedOneWithoutZaprunoutboxInput = {
    create?: XOR<ZapRunCreateWithoutZaprunoutboxInput, ZapRunUncheckedCreateWithoutZaprunoutboxInput>
    connectOrCreate?: ZapRunCreateOrConnectWithoutZaprunoutboxInput
    connect?: ZapRunWhereUniqueInput
  }

  export type ZapRunUpdateOneRequiredWithoutZaprunoutboxNestedInput = {
    create?: XOR<ZapRunCreateWithoutZaprunoutboxInput, ZapRunUncheckedCreateWithoutZaprunoutboxInput>
    connectOrCreate?: ZapRunCreateOrConnectWithoutZaprunoutboxInput
    upsert?: ZapRunUpsertWithoutZaprunoutboxInput
    connect?: ZapRunWhereUniqueInput
    update?: XOR<XOR<ZapRunUpdateToOneWithWhereWithoutZaprunoutboxInput, ZapRunUpdateWithoutZaprunoutboxInput>, ZapRunUncheckedUpdateWithoutZaprunoutboxInput>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }
  export type NestedJsonFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<NestedJsonFilterBase<$PrismaModel>>, Exclude<keyof Required<NestedJsonFilterBase<$PrismaModel>>, 'path'>>,
        Required<NestedJsonFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<NestedJsonFilterBase<$PrismaModel>>, 'path'>>

  export type NestedJsonFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type TriggerCreateWithoutZapInput = {
    id?: string
    type: TriggerTypeCreateNestedOneWithoutTriggrInput
  }

  export type TriggerUncheckedCreateWithoutZapInput = {
    id?: string
    tiggerID: string
  }

  export type TriggerCreateOrConnectWithoutZapInput = {
    where: TriggerWhereUniqueInput
    create: XOR<TriggerCreateWithoutZapInput, TriggerUncheckedCreateWithoutZapInput>
  }

  export type ActionsCreateWithoutZapInput = {
    id?: string
    ActionType: AvalibleActionsCreateNestedOneWithoutActionInput
  }

  export type ActionsUncheckedCreateWithoutZapInput = {
    id?: string
    actionID: string
  }

  export type ActionsCreateOrConnectWithoutZapInput = {
    where: ActionsWhereUniqueInput
    create: XOR<ActionsCreateWithoutZapInput, ActionsUncheckedCreateWithoutZapInput>
  }

  export type ActionsCreateManyZapInputEnvelope = {
    data: ActionsCreateManyZapInput | ActionsCreateManyZapInput[]
    skipDuplicates?: boolean
  }

  export type ZapRunCreateWithoutZapInput = {
    id?: string
    meatdata: JsonNullValueInput | InputJsonValue
    zaprunoutbox?: ZapRunOutBoxCreateNestedOneWithoutZaprunInput
  }

  export type ZapRunUncheckedCreateWithoutZapInput = {
    id?: string
    meatdata: JsonNullValueInput | InputJsonValue
    zaprunoutbox?: ZapRunOutBoxUncheckedCreateNestedOneWithoutZaprunInput
  }

  export type ZapRunCreateOrConnectWithoutZapInput = {
    where: ZapRunWhereUniqueInput
    create: XOR<ZapRunCreateWithoutZapInput, ZapRunUncheckedCreateWithoutZapInput>
  }

  export type ZapRunCreateManyZapInputEnvelope = {
    data: ZapRunCreateManyZapInput | ZapRunCreateManyZapInput[]
    skipDuplicates?: boolean
  }

  export type TriggerUpsertWithoutZapInput = {
    update: XOR<TriggerUpdateWithoutZapInput, TriggerUncheckedUpdateWithoutZapInput>
    create: XOR<TriggerCreateWithoutZapInput, TriggerUncheckedCreateWithoutZapInput>
    where?: TriggerWhereInput
  }

  export type TriggerUpdateToOneWithWhereWithoutZapInput = {
    where?: TriggerWhereInput
    data: XOR<TriggerUpdateWithoutZapInput, TriggerUncheckedUpdateWithoutZapInput>
  }

  export type TriggerUpdateWithoutZapInput = {
    id?: StringFieldUpdateOperationsInput | string
    type?: TriggerTypeUpdateOneRequiredWithoutTriggrNestedInput
  }

  export type TriggerUncheckedUpdateWithoutZapInput = {
    id?: StringFieldUpdateOperationsInput | string
    tiggerID?: StringFieldUpdateOperationsInput | string
  }

  export type ActionsUpsertWithWhereUniqueWithoutZapInput = {
    where: ActionsWhereUniqueInput
    update: XOR<ActionsUpdateWithoutZapInput, ActionsUncheckedUpdateWithoutZapInput>
    create: XOR<ActionsCreateWithoutZapInput, ActionsUncheckedCreateWithoutZapInput>
  }

  export type ActionsUpdateWithWhereUniqueWithoutZapInput = {
    where: ActionsWhereUniqueInput
    data: XOR<ActionsUpdateWithoutZapInput, ActionsUncheckedUpdateWithoutZapInput>
  }

  export type ActionsUpdateManyWithWhereWithoutZapInput = {
    where: ActionsScalarWhereInput
    data: XOR<ActionsUpdateManyMutationInput, ActionsUncheckedUpdateManyWithoutZapInput>
  }

  export type ActionsScalarWhereInput = {
    AND?: ActionsScalarWhereInput | ActionsScalarWhereInput[]
    OR?: ActionsScalarWhereInput[]
    NOT?: ActionsScalarWhereInput | ActionsScalarWhereInput[]
    id?: StringFilter<"Actions"> | string
    ZapID?: StringFilter<"Actions"> | string
    actionID?: StringFilter<"Actions"> | string
  }

  export type ZapRunUpsertWithWhereUniqueWithoutZapInput = {
    where: ZapRunWhereUniqueInput
    update: XOR<ZapRunUpdateWithoutZapInput, ZapRunUncheckedUpdateWithoutZapInput>
    create: XOR<ZapRunCreateWithoutZapInput, ZapRunUncheckedCreateWithoutZapInput>
  }

  export type ZapRunUpdateWithWhereUniqueWithoutZapInput = {
    where: ZapRunWhereUniqueInput
    data: XOR<ZapRunUpdateWithoutZapInput, ZapRunUncheckedUpdateWithoutZapInput>
  }

  export type ZapRunUpdateManyWithWhereWithoutZapInput = {
    where: ZapRunScalarWhereInput
    data: XOR<ZapRunUpdateManyMutationInput, ZapRunUncheckedUpdateManyWithoutZapInput>
  }

  export type ZapRunScalarWhereInput = {
    AND?: ZapRunScalarWhereInput | ZapRunScalarWhereInput[]
    OR?: ZapRunScalarWhereInput[]
    NOT?: ZapRunScalarWhereInput | ZapRunScalarWhereInput[]
    id?: StringFilter<"ZapRun"> | string
    zapId?: StringFilter<"ZapRun"> | string
    meatdata?: JsonFilter<"ZapRun">
  }

  export type TriggerTypeCreateWithoutTriggrInput = {
    id?: string
    name: string
  }

  export type TriggerTypeUncheckedCreateWithoutTriggrInput = {
    id?: string
    name: string
  }

  export type TriggerTypeCreateOrConnectWithoutTriggrInput = {
    where: TriggerTypeWhereUniqueInput
    create: XOR<TriggerTypeCreateWithoutTriggrInput, TriggerTypeUncheckedCreateWithoutTriggrInput>
  }

  export type ZapCreateWithoutTriggerInput = {
    id?: string
    actions?: ActionsCreateNestedManyWithoutZapInput
    zaprun?: ZapRunCreateNestedManyWithoutZapInput
  }

  export type ZapUncheckedCreateWithoutTriggerInput = {
    id?: string
    actions?: ActionsUncheckedCreateNestedManyWithoutZapInput
    zaprun?: ZapRunUncheckedCreateNestedManyWithoutZapInput
  }

  export type ZapCreateOrConnectWithoutTriggerInput = {
    where: ZapWhereUniqueInput
    create: XOR<ZapCreateWithoutTriggerInput, ZapUncheckedCreateWithoutTriggerInput>
  }

  export type TriggerTypeUpsertWithoutTriggrInput = {
    update: XOR<TriggerTypeUpdateWithoutTriggrInput, TriggerTypeUncheckedUpdateWithoutTriggrInput>
    create: XOR<TriggerTypeCreateWithoutTriggrInput, TriggerTypeUncheckedCreateWithoutTriggrInput>
    where?: TriggerTypeWhereInput
  }

  export type TriggerTypeUpdateToOneWithWhereWithoutTriggrInput = {
    where?: TriggerTypeWhereInput
    data: XOR<TriggerTypeUpdateWithoutTriggrInput, TriggerTypeUncheckedUpdateWithoutTriggrInput>
  }

  export type TriggerTypeUpdateWithoutTriggrInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
  }

  export type TriggerTypeUncheckedUpdateWithoutTriggrInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
  }

  export type ZapUpsertWithoutTriggerInput = {
    update: XOR<ZapUpdateWithoutTriggerInput, ZapUncheckedUpdateWithoutTriggerInput>
    create: XOR<ZapCreateWithoutTriggerInput, ZapUncheckedCreateWithoutTriggerInput>
    where?: ZapWhereInput
  }

  export type ZapUpdateToOneWithWhereWithoutTriggerInput = {
    where?: ZapWhereInput
    data: XOR<ZapUpdateWithoutTriggerInput, ZapUncheckedUpdateWithoutTriggerInput>
  }

  export type ZapUpdateWithoutTriggerInput = {
    id?: StringFieldUpdateOperationsInput | string
    actions?: ActionsUpdateManyWithoutZapNestedInput
    zaprun?: ZapRunUpdateManyWithoutZapNestedInput
  }

  export type ZapUncheckedUpdateWithoutTriggerInput = {
    id?: StringFieldUpdateOperationsInput | string
    actions?: ActionsUncheckedUpdateManyWithoutZapNestedInput
    zaprun?: ZapRunUncheckedUpdateManyWithoutZapNestedInput
  }

  export type ZapCreateWithoutActionsInput = {
    id?: string
    trigger?: TriggerCreateNestedOneWithoutZapInput
    zaprun?: ZapRunCreateNestedManyWithoutZapInput
  }

  export type ZapUncheckedCreateWithoutActionsInput = {
    id?: string
    trigger?: TriggerUncheckedCreateNestedOneWithoutZapInput
    zaprun?: ZapRunUncheckedCreateNestedManyWithoutZapInput
  }

  export type ZapCreateOrConnectWithoutActionsInput = {
    where: ZapWhereUniqueInput
    create: XOR<ZapCreateWithoutActionsInput, ZapUncheckedCreateWithoutActionsInput>
  }

  export type AvalibleActionsCreateWithoutActionInput = {
    id?: string
    name: string
  }

  export type AvalibleActionsUncheckedCreateWithoutActionInput = {
    id?: string
    name: string
  }

  export type AvalibleActionsCreateOrConnectWithoutActionInput = {
    where: AvalibleActionsWhereUniqueInput
    create: XOR<AvalibleActionsCreateWithoutActionInput, AvalibleActionsUncheckedCreateWithoutActionInput>
  }

  export type ZapUpsertWithoutActionsInput = {
    update: XOR<ZapUpdateWithoutActionsInput, ZapUncheckedUpdateWithoutActionsInput>
    create: XOR<ZapCreateWithoutActionsInput, ZapUncheckedCreateWithoutActionsInput>
    where?: ZapWhereInput
  }

  export type ZapUpdateToOneWithWhereWithoutActionsInput = {
    where?: ZapWhereInput
    data: XOR<ZapUpdateWithoutActionsInput, ZapUncheckedUpdateWithoutActionsInput>
  }

  export type ZapUpdateWithoutActionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    trigger?: TriggerUpdateOneWithoutZapNestedInput
    zaprun?: ZapRunUpdateManyWithoutZapNestedInput
  }

  export type ZapUncheckedUpdateWithoutActionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    trigger?: TriggerUncheckedUpdateOneWithoutZapNestedInput
    zaprun?: ZapRunUncheckedUpdateManyWithoutZapNestedInput
  }

  export type AvalibleActionsUpsertWithoutActionInput = {
    update: XOR<AvalibleActionsUpdateWithoutActionInput, AvalibleActionsUncheckedUpdateWithoutActionInput>
    create: XOR<AvalibleActionsCreateWithoutActionInput, AvalibleActionsUncheckedCreateWithoutActionInput>
    where?: AvalibleActionsWhereInput
  }

  export type AvalibleActionsUpdateToOneWithWhereWithoutActionInput = {
    where?: AvalibleActionsWhereInput
    data: XOR<AvalibleActionsUpdateWithoutActionInput, AvalibleActionsUncheckedUpdateWithoutActionInput>
  }

  export type AvalibleActionsUpdateWithoutActionInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
  }

  export type AvalibleActionsUncheckedUpdateWithoutActionInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
  }

  export type ActionsCreateWithoutActionTypeInput = {
    id?: string
    zap: ZapCreateNestedOneWithoutActionsInput
  }

  export type ActionsUncheckedCreateWithoutActionTypeInput = {
    id?: string
    ZapID: string
  }

  export type ActionsCreateOrConnectWithoutActionTypeInput = {
    where: ActionsWhereUniqueInput
    create: XOR<ActionsCreateWithoutActionTypeInput, ActionsUncheckedCreateWithoutActionTypeInput>
  }

  export type ActionsCreateManyActionTypeInputEnvelope = {
    data: ActionsCreateManyActionTypeInput | ActionsCreateManyActionTypeInput[]
    skipDuplicates?: boolean
  }

  export type ActionsUpsertWithWhereUniqueWithoutActionTypeInput = {
    where: ActionsWhereUniqueInput
    update: XOR<ActionsUpdateWithoutActionTypeInput, ActionsUncheckedUpdateWithoutActionTypeInput>
    create: XOR<ActionsCreateWithoutActionTypeInput, ActionsUncheckedCreateWithoutActionTypeInput>
  }

  export type ActionsUpdateWithWhereUniqueWithoutActionTypeInput = {
    where: ActionsWhereUniqueInput
    data: XOR<ActionsUpdateWithoutActionTypeInput, ActionsUncheckedUpdateWithoutActionTypeInput>
  }

  export type ActionsUpdateManyWithWhereWithoutActionTypeInput = {
    where: ActionsScalarWhereInput
    data: XOR<ActionsUpdateManyMutationInput, ActionsUncheckedUpdateManyWithoutActionTypeInput>
  }

  export type TriggerCreateWithoutTypeInput = {
    id?: string
    zap: ZapCreateNestedOneWithoutTriggerInput
  }

  export type TriggerUncheckedCreateWithoutTypeInput = {
    id?: string
    ZapID: string
  }

  export type TriggerCreateOrConnectWithoutTypeInput = {
    where: TriggerWhereUniqueInput
    create: XOR<TriggerCreateWithoutTypeInput, TriggerUncheckedCreateWithoutTypeInput>
  }

  export type TriggerCreateManyTypeInputEnvelope = {
    data: TriggerCreateManyTypeInput | TriggerCreateManyTypeInput[]
    skipDuplicates?: boolean
  }

  export type TriggerUpsertWithWhereUniqueWithoutTypeInput = {
    where: TriggerWhereUniqueInput
    update: XOR<TriggerUpdateWithoutTypeInput, TriggerUncheckedUpdateWithoutTypeInput>
    create: XOR<TriggerCreateWithoutTypeInput, TriggerUncheckedCreateWithoutTypeInput>
  }

  export type TriggerUpdateWithWhereUniqueWithoutTypeInput = {
    where: TriggerWhereUniqueInput
    data: XOR<TriggerUpdateWithoutTypeInput, TriggerUncheckedUpdateWithoutTypeInput>
  }

  export type TriggerUpdateManyWithWhereWithoutTypeInput = {
    where: TriggerScalarWhereInput
    data: XOR<TriggerUpdateManyMutationInput, TriggerUncheckedUpdateManyWithoutTypeInput>
  }

  export type TriggerScalarWhereInput = {
    AND?: TriggerScalarWhereInput | TriggerScalarWhereInput[]
    OR?: TriggerScalarWhereInput[]
    NOT?: TriggerScalarWhereInput | TriggerScalarWhereInput[]
    id?: StringFilter<"Trigger"> | string
    ZapID?: StringFilter<"Trigger"> | string
    tiggerID?: StringFilter<"Trigger"> | string
  }

  export type ZapCreateWithoutZaprunInput = {
    id?: string
    trigger?: TriggerCreateNestedOneWithoutZapInput
    actions?: ActionsCreateNestedManyWithoutZapInput
  }

  export type ZapUncheckedCreateWithoutZaprunInput = {
    id?: string
    trigger?: TriggerUncheckedCreateNestedOneWithoutZapInput
    actions?: ActionsUncheckedCreateNestedManyWithoutZapInput
  }

  export type ZapCreateOrConnectWithoutZaprunInput = {
    where: ZapWhereUniqueInput
    create: XOR<ZapCreateWithoutZaprunInput, ZapUncheckedCreateWithoutZaprunInput>
  }

  export type ZapRunOutBoxCreateWithoutZaprunInput = {
    id?: string
  }

  export type ZapRunOutBoxUncheckedCreateWithoutZaprunInput = {
    id?: string
  }

  export type ZapRunOutBoxCreateOrConnectWithoutZaprunInput = {
    where: ZapRunOutBoxWhereUniqueInput
    create: XOR<ZapRunOutBoxCreateWithoutZaprunInput, ZapRunOutBoxUncheckedCreateWithoutZaprunInput>
  }

  export type ZapUpsertWithoutZaprunInput = {
    update: XOR<ZapUpdateWithoutZaprunInput, ZapUncheckedUpdateWithoutZaprunInput>
    create: XOR<ZapCreateWithoutZaprunInput, ZapUncheckedCreateWithoutZaprunInput>
    where?: ZapWhereInput
  }

  export type ZapUpdateToOneWithWhereWithoutZaprunInput = {
    where?: ZapWhereInput
    data: XOR<ZapUpdateWithoutZaprunInput, ZapUncheckedUpdateWithoutZaprunInput>
  }

  export type ZapUpdateWithoutZaprunInput = {
    id?: StringFieldUpdateOperationsInput | string
    trigger?: TriggerUpdateOneWithoutZapNestedInput
    actions?: ActionsUpdateManyWithoutZapNestedInput
  }

  export type ZapUncheckedUpdateWithoutZaprunInput = {
    id?: StringFieldUpdateOperationsInput | string
    trigger?: TriggerUncheckedUpdateOneWithoutZapNestedInput
    actions?: ActionsUncheckedUpdateManyWithoutZapNestedInput
  }

  export type ZapRunOutBoxUpsertWithoutZaprunInput = {
    update: XOR<ZapRunOutBoxUpdateWithoutZaprunInput, ZapRunOutBoxUncheckedUpdateWithoutZaprunInput>
    create: XOR<ZapRunOutBoxCreateWithoutZaprunInput, ZapRunOutBoxUncheckedCreateWithoutZaprunInput>
    where?: ZapRunOutBoxWhereInput
  }

  export type ZapRunOutBoxUpdateToOneWithWhereWithoutZaprunInput = {
    where?: ZapRunOutBoxWhereInput
    data: XOR<ZapRunOutBoxUpdateWithoutZaprunInput, ZapRunOutBoxUncheckedUpdateWithoutZaprunInput>
  }

  export type ZapRunOutBoxUpdateWithoutZaprunInput = {
    id?: StringFieldUpdateOperationsInput | string
  }

  export type ZapRunOutBoxUncheckedUpdateWithoutZaprunInput = {
    id?: StringFieldUpdateOperationsInput | string
  }

  export type ZapRunCreateWithoutZaprunoutboxInput = {
    id?: string
    meatdata: JsonNullValueInput | InputJsonValue
    zap: ZapCreateNestedOneWithoutZaprunInput
  }

  export type ZapRunUncheckedCreateWithoutZaprunoutboxInput = {
    id?: string
    zapId: string
    meatdata: JsonNullValueInput | InputJsonValue
  }

  export type ZapRunCreateOrConnectWithoutZaprunoutboxInput = {
    where: ZapRunWhereUniqueInput
    create: XOR<ZapRunCreateWithoutZaprunoutboxInput, ZapRunUncheckedCreateWithoutZaprunoutboxInput>
  }

  export type ZapRunUpsertWithoutZaprunoutboxInput = {
    update: XOR<ZapRunUpdateWithoutZaprunoutboxInput, ZapRunUncheckedUpdateWithoutZaprunoutboxInput>
    create: XOR<ZapRunCreateWithoutZaprunoutboxInput, ZapRunUncheckedCreateWithoutZaprunoutboxInput>
    where?: ZapRunWhereInput
  }

  export type ZapRunUpdateToOneWithWhereWithoutZaprunoutboxInput = {
    where?: ZapRunWhereInput
    data: XOR<ZapRunUpdateWithoutZaprunoutboxInput, ZapRunUncheckedUpdateWithoutZaprunoutboxInput>
  }

  export type ZapRunUpdateWithoutZaprunoutboxInput = {
    id?: StringFieldUpdateOperationsInput | string
    meatdata?: JsonNullValueInput | InputJsonValue
    zap?: ZapUpdateOneRequiredWithoutZaprunNestedInput
  }

  export type ZapRunUncheckedUpdateWithoutZaprunoutboxInput = {
    id?: StringFieldUpdateOperationsInput | string
    zapId?: StringFieldUpdateOperationsInput | string
    meatdata?: JsonNullValueInput | InputJsonValue
  }

  export type ActionsCreateManyZapInput = {
    id?: string
    actionID: string
  }

  export type ZapRunCreateManyZapInput = {
    id?: string
    meatdata: JsonNullValueInput | InputJsonValue
  }

  export type ActionsUpdateWithoutZapInput = {
    id?: StringFieldUpdateOperationsInput | string
    ActionType?: AvalibleActionsUpdateOneRequiredWithoutActionNestedInput
  }

  export type ActionsUncheckedUpdateWithoutZapInput = {
    id?: StringFieldUpdateOperationsInput | string
    actionID?: StringFieldUpdateOperationsInput | string
  }

  export type ActionsUncheckedUpdateManyWithoutZapInput = {
    id?: StringFieldUpdateOperationsInput | string
    actionID?: StringFieldUpdateOperationsInput | string
  }

  export type ZapRunUpdateWithoutZapInput = {
    id?: StringFieldUpdateOperationsInput | string
    meatdata?: JsonNullValueInput | InputJsonValue
    zaprunoutbox?: ZapRunOutBoxUpdateOneWithoutZaprunNestedInput
  }

  export type ZapRunUncheckedUpdateWithoutZapInput = {
    id?: StringFieldUpdateOperationsInput | string
    meatdata?: JsonNullValueInput | InputJsonValue
    zaprunoutbox?: ZapRunOutBoxUncheckedUpdateOneWithoutZaprunNestedInput
  }

  export type ZapRunUncheckedUpdateManyWithoutZapInput = {
    id?: StringFieldUpdateOperationsInput | string
    meatdata?: JsonNullValueInput | InputJsonValue
  }

  export type ActionsCreateManyActionTypeInput = {
    id?: string
    ZapID: string
  }

  export type ActionsUpdateWithoutActionTypeInput = {
    id?: StringFieldUpdateOperationsInput | string
    zap?: ZapUpdateOneRequiredWithoutActionsNestedInput
  }

  export type ActionsUncheckedUpdateWithoutActionTypeInput = {
    id?: StringFieldUpdateOperationsInput | string
    ZapID?: StringFieldUpdateOperationsInput | string
  }

  export type ActionsUncheckedUpdateManyWithoutActionTypeInput = {
    id?: StringFieldUpdateOperationsInput | string
    ZapID?: StringFieldUpdateOperationsInput | string
  }

  export type TriggerCreateManyTypeInput = {
    id?: string
    ZapID: string
  }

  export type TriggerUpdateWithoutTypeInput = {
    id?: StringFieldUpdateOperationsInput | string
    zap?: ZapUpdateOneRequiredWithoutTriggerNestedInput
  }

  export type TriggerUncheckedUpdateWithoutTypeInput = {
    id?: StringFieldUpdateOperationsInput | string
    ZapID?: StringFieldUpdateOperationsInput | string
  }

  export type TriggerUncheckedUpdateManyWithoutTypeInput = {
    id?: StringFieldUpdateOperationsInput | string
    ZapID?: StringFieldUpdateOperationsInput | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}