-- AlterTable
ALTER TABLE "Actions" ADD COLUMN     "sortingOrder" INTEGER NOT NULL DEFAULT 0;
